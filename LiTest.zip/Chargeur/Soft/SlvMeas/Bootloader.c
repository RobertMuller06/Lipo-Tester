/* ****************************************************** */

#pragma codepage 3
#pragma origin 0x1C00
/********************************************************
     BOOTLOADER ROUTINES
 **********************************************************/
#include "InlineBoot.h"

/* ********** FLASH WRITE P16F*********** */

#pragma rambank 3

void bootprocess (void)
{
// *** main bootloader

	char rcvdata, i, j, BCC; 
	uns16 boot_fadr,btloop;
	char tp;
	bit OutRng;
	char kflash;
	
	bInitialize();
	GIE = 0;		// no interrupt, polling only
//  host synch
	bi = 0;
	OutRng = 0;
	boot_tp=0;
	kflash = FLASHCAPACITY / 2;
	while (bi == 0)
	{
				rxdata = boot_waitsrl();
		if (rxdata == 'R')
		{
			nop();
			nop();
			rxdata = boot_waitsrl();

			if (rxdata == 'M')
			{
				nop();
				nop();
				rxdata = boot_waitsrl();
				if (rxdata == 'b')
				{
					nop();
					nop();
					rxdata = boot_waitsrl();
					if (rxdata == 't')
					{
						boot_outsrl ('b');			// Device reply with c to complete handshake
						boot_outsrl ('t');
						boot_outsrl (FLASHCAPACITY);
						bi = 1;
					}	
				}
			}
		} 
	}

// tfr data 
	boot_fadr = 0;

// transfer format is :
// 27 as sart of block
// address high, address low, in hex.
// then 64 bytes follows, then check caracter
// When address is 0xff00: stop

	while (boot_fadr != 0xFF00)	// must complete with address FF00 to stop tfr
	{
		rxdata = boot_waitsrl();
		while (rxdata != 27)		// start of block 
		{
			if (rxdata == 28)	// verif loop
			{
				if (verif (boot_fadr) == 1)
				{
					boot_outsrl (6);
				}
				else
				{
					boot_outsrl(8);		// for test, must be 8
				}		
			}
			rxdata = boot_waitsrl();
		}
		rcvdata = boot_waitsrl();
		BCC = rcvdata;
		boot_fadr.high8 = rcvdata;
		rcvdata = boot_waitsrl();
		BCC += rcvdata;
		boot_fadr.low8 = rcvdata;
		if (boot_fadr == 0xFF00) break;
		for (i = 0;i!=64;i++)
		{
			rcvdata = boot_waitsrl();
			BCC += rcvdata;
			boot_bufflash[i] = rcvdata;
		}
#ifdef LED
		boot_tp++;
		if (boot_tp == 5)
		{
			boot_tp=0;
		}
#endif	
		rcvdata = boot_waitsrl();	// BCC caracter
		if (rcvdata == BCC)  
		{
			boot_OK=1;
			if (OutRng == 0)
			{		
				boot_writeflash (boot_fadr);
				if (boot_OK == 1)
				{
					boot_outsrl (6);		// check is ok, reply ack
				}
				else
				{
					boot_outsrl (8);		// reply 8 for error write
					boot_outsrl (dmpadrh);
					boot_outsrl(dmpadrl);
					boot_outsrl(dmpdathrd);
					boot_outsrl(dmpdatlrd);
					boot_outsrl(dmpdathwr);
					boot_outsrl(dmpdatlwr);

				}
			}
			else 
			{
				boot_outsrl(9);
			}			
	
		}	
		else
		{
				boot_outsrl (7);	// reply nack, comm error
		}
	}
}

void boot_writeflash (uns16 fadr) // 64 bytes at once in bufflash
 {
	char i,j,k,l,m,n,pointr;
	uns16 svfadr;
	uns16 locadr;
	
	svfadr = fadr;
	locadr = fadr;
	boot_OK = 1;
	GIE = 0;		// should be already at 0, for standardizi	
	EEIE = 0;
	if (fadr < 0x1C00-64)	// protect booloader zone
	{
		// *** first erase block
		EEADRH = locadr.high8;
		EEADRL = locadr.low8;
		EEIF = 0;
		CFGS = 0;
		EEPGD = 1;
		FREE = 1;
		WREN = 1;
		EECON2 = 0x55;
		EECON2 = 0xAA;
		WR = 1;
		nop();
		nop();
		FREE = 0;
		
		//  ***  then write data
		EEADRH = locadr.high8;
		EEADRL = locadr.low8;
		EEPGD = 1;
		CFGS = 0;
		WREN = 1;
		LWLO = 1;	// select latches
		EEIF =0;
		// write latches loop
		for (k = 0; k != 32; k++)
		{
			EEIF = 0;
			svfadr = locadr + k;
			pointr = k * 2;
			boot_bufflash[pointr+1] &= 0x3F;
			EEDATL = boot_bufflash[pointr];
			EEDATH = boot_bufflash[pointr+1];
			EECON2 = 0x55;
			EECON2 = 0xAA;
			WR = 1;
			nop();
			nop();
			EEADRL++;
		}
			// write flash now
		EEIF = 0;
		LWLO = 0;		// select flash
		EEADRL = locadr.low8;
		EEDATL = boot_bufflash[0];
		EEDATH = boot_bufflash[1];		
		EECON2 = 0x55;
		EECON2 = 0xAA;
		WR = 1;
		nop();
		nop();
		nop();
		nop();
		nop();
		nop();
		nop();
		nop();
		WREN = 0;
	}
	else boot_OK = 1;
}

bit verif (uns16 fadr)	
{
	char i,j,k,l,m,n,pointr;
	uns16 svfadr;
	uns16 locadr;
	
	boot_OK = 1;
// Method 2 read flash inprogramming mode
	if (fadr < 0x1800)	// ignore booloader zone
	{
		EEIF = 0;
		CFGS = 0;
		EEPGD = 1;
		for (n = 0; n != 32; n++)
		{
			svfadr = fadr + n;
			EEIF = 0;
			CFGS = 0;
			EEPGD = 1;
			EEADRL = svfadr.low8;
			EEADRH = svfadr.high8;
			pointr = n * 2;		
			RD = 1;
			nop();
			nop();
			nop();
			nop();
			k = EEDATL;
			j = EEDATH;
			j = j & 0x3F;
			l = boot_bufflash[pointr] & 0x3F;
			m = boot_bufflash[pointr+1];
			if (j !=l)	boot_OK = 0;
			if (k != m) boot_OK = 0;
		}
	}
	return boot_OK;
}
	
#pragma rambank 3
//  *** serial port routines
void boot_outsrl (char outcar)
	{
	while (TRMT == 0);
	TXREG = outcar;
	}

char boot_waitsrl (void)
{
while (RCIF == 0)
	{nop();
	nop();
	}
return RCREG;
}


void bInitialize(void)
{
	INTCON = 0;		//  disable all interrupts /
	STATUS = 0;
	PORTA = 0; 
	PORTC = 0;  
	TRISA = bin(111111);
	TRISC = bin(11111111);
// init periph interrupts 
	PIE1 = bin(00000000); // disabled int adc, usart, all polled
	PIR1 = 0;
	GIE = 0;			// no interrupt, polling hrdw
	clearRAM();
// init USART 19.2 Kbps / 8 bits
	//config USART
	TXSTA = 0b00100110;
	RCSTA = 0b10010000;
	BAUDCON = 0b00001000;
	SPBRGL = (char)b_BAUDGEN;
	SPBRGH = 0;
	#if (b_BAUDGEN) > (255)
	SPBRGH = b_BAUDGEN / 256;
	#endif
	TRISC.4 = 1;
	TRISC.5 = 1;
	TRISC.3 = 0;
	nop();
	bi = RCREG;		// dummy read to clear buffer
	nop();
	bi = RCREG;
}	

