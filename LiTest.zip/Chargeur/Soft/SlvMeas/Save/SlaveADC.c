/* Processor accessory for relays */

#include "int16Cxx.h"
#include "SlaveADC.h"

#pragma origin 4
interrupt IntRtg(void)
{
	int_save_registers
// I2C interrupt
	if (SSP1IF == 1)	//i2c rcv data
	{
		uns16 svfsr = FSR0;
		I2CSlaveInt();	
		FSR0 =svfsr;
	}
// ADC result
	if (ADIF)	// ADC result		
	{
		ADIF = 0;
		ADRes.high8= ADRESH;
		ADRes.low8 = ADRESL;
		if (NextANP == 0) ANLICHRG = ADRes;
		else if (NextANP == 1) TempADC = ADRes;
		else if (NextANP == 2) ANLVchrg = ADRes;
	}
// real time 1ms clk
	if (TMR2IF)
	{
		// clock
		TMR2IF = 0;
		msflg = 1;
		// tempo 
		if (timer1 == 1)	//for general use
		{
			tempoms--;
			if (tempoms == 0)
			{
				timer1 = 0;
			}
		}
		if (timer2 == 1)	//primary used for i2c timeout protection
		{
			tempoms2--;
			if (tempoms2 == 0)
			{
				timer2 = 0;
				
			}
		}
		if (timer3 == 1)
		{
			tempoms3--;
			if (tempoms3 == 0)
			{
				timer3 = 0;
				//CCP3CON = 0b00000000;	//turn off beeper pwm
			}
		}				
	}

//	int_restore_registers
}

void tempo (uns16 durationms,bit locked)		// max 65 sec but no validity check on param
{
	tempoms = durationms + 1; 
	timer1 = 1;
	if (locked)
	while (timer1);
}

void tempoI2C (uns16 durationms)		// max 65 sec but no validity check on param
{
	tempoms2 = durationms + 1; 
	timer2 = 1;
}
	
#include "I2CSlave.c"

#pragma codepage 0

void Housekeeping (bit opms)
{
	char action,dato,dati,delay1,i;
	static char tempadc;
	bit ch,validadc;
	uns16 dat16;
	static uns16 delay2;
	
	if (inpcompl)		// all data received in msg
	{
		inpcompl=0;
		// processing of i2c data rcvd
		action = I2Cbufin[1];	// 2nd char in buffer indicate which action
		switch (action)
		{
			case 0:		// check pic ready
			{
				I2Cbufout[0] = 3; 
				I2Cbufout[1] = 'O';
				I2Cbufout[2] = 'K';
				i2csend (3);	
				break;
			}	
			case 1:		// Get ADC values
			{
				I2Cbufout[0] = 3;
				if (I2Cbufin[2] == 0)
				{
					dat16 = ANLICHRG;		
				}
				else if (I2Cbufin[2] == 1)	
				{
					dat16 = TempADC;
				}
				else if(I2Cbufin[2] == 2)
				{
					dat16 = ANLVchrg;
				}
				I2Cbufout[1] = dat16.high8;
				I2Cbufout[2] = dat16.low8;
				i2csend(3);	
				break;
			}
			case 2:		// LED on/off
			{
				if (I2Cbufin[2] == 0)
				LED = 0;
				else LED = 1;
				break;
			}
			case 3:		// Action Beeper
			{
				beepfreq.high8 = I2Cbufin[2];
				beepfreq.low8 = I2Cbufin[3];
				beeptime.high8 = I2Cbufin[4];
				beeptime.low8 = I2Cbufin[5];
				Beeper(I2Cbufin[6]);
				break;
			}
			case 4:		// active/deact fan
			{
				if (I2Cbufin[2] == 1) FAN = 1;
				else FAN = 0;
				break;
			}
			case 5:		//get temperature
			{
				I2Cbufout[0] = 3;
				I2Cbufout[1] = TempDegC.high8;
				I2Cbufout[2] = TempDegC.low8;
				i2csend(3);
				break;
			}		
		}	
	}

	if (opms)
	{
		clrwdt();
		delay1++;
		delay2++;
		if (delay1 == 100)
		{
			validadc = 0;
			delay1 = 0;
			NextANP++;
			if (NextANP == 3) NextANP = 0;
			switch (NextANP)
			{
				case 0:
				{
					ADCON0 = 0b00000001;
					validadc = 1;
					break;
				}	
				case 1:
				{
					ADCON0 = 0b00000101;
					validadc = 1;
					break;
				}	
					case 2:
				{
					ADCON0 = 0b00011001;
					validadc = 1;
					break;
				}
			}
			for (i = 0;i!=5;i++)	//acquisition time
			{	
				nop();
				nop();
			}		
			if (validadc) GO = 1;
		}
		if (delay2 == 50)
		{
			delay2 = 0;
			CalcDegC();
		}	
	}			
}
#pragma codepage 0

void Init(void)
{
	//Beeper (5);
	LED = 0;
}	
	
void HardInit (void)
{
	OSCCON = 0b01111010;	// switch to 16MHz intnl oscilator
	OSCSTAT = 1;
	PCON = 0;
	INTCON = 0;		//  disable all interrupts /
	STATUS = 0;
	PIE1 = 0;
	PIE2 = 0;
	LATA = 0b00000000;
	LATC = 0b00000000;
	TRISA = 0b11101011;
	TRISC = 0b11110111;
	OPTION_REG = 0b00000100;		//tmr0 presc 32
/* init periph interrupts */
	clearRAM();
/* init USART */
//de-config USART
	SPEN = 0;
	TXEN = 0;
	CREN = 0;
// config timer2 intrupt each ms
	T2CON = 0b00000110;			//no postscaler, /16 prescaler
	PR2 = 249;					//for 1ms period
	TMR2IE = 1;	
// config timer 4 for PWM CCP3
	T4CON = 0b00000111;
	PR4 = 256;
	TMR4IE = 0;
// config adc
	ANSELA = 3;
	ANSELC = 4;
	WPUA = 0;
	WPUC = 0;
	ADCON0 = 0b00000001;		// adc on 
	ADCON1 = 0b10100011;		// fosc/32/right justif/vref is intnl
	FVRCON = 0b10000011;		//vref = 4.096V
	ADIE = 1;					// intrpt mode
// config PWM fort buzzer
	CCP3CON = 0b00000000;
	CCPTMRS = 0b00010000;	//timer4
// start int
	PIR1 = 0;	// clear all int
	PIR2 = 0;
	GIE = 1;
	PEIE = 1;
	I2CSInit();
	SSP1MSK = 0xFE;	
	WDTCON = 0b00010011;
}		
void main (void)
{
	uns16 loop;
	char i;
	
	STKPTR = 0;
	OSCCON = 0b01101010;	// 4MHz intnl oscilator
	OSCSTAT = 1;
	ADCON0 = 0;		// All analog ports as digital
	ANSELA = 0;
	MDCON = 0;
	nop();
	TRISA.5 = 1;
	TRISC.3 = 0;
	i = PORTA;
	i = PORTA;
//	for (loop=0;loop!=10000;loop++);	//stabilize Q5 inp res (approx 1us per loop) 	
	if (i.5 == 0)		// ***BootLoder mode***
	{
#asm
		MOVLP 0x1C
		call bootprocess
		MOVLP 0 
#endasm
	}
	HardInit();
	Init();
	while (1)
	{
		if (msflg == 1) 
		{
			msops = 1;
			msflg = 0;
		}	
		Housekeeping(msops);
		msops = 0;
	}

}

/* *******************************************************
************************************************************ */
#include "SlvAdcModules.c"

#include "Bootloader.c"
