/* MesSelf Header file  */

/* *********************************************
CONFIG WORDS
01 = 09 C4
02 = 36 03
************************************************* */

/********************************************
		HARDWARE DEFINITIONS
********************************************/
// Define the switch port that will trigger bootloading
// switch activation must be 0 if switch makes 0 when pressed
// otherwise must be 1
#define SWITCH PORTC.3
#define TrisSw TRISC.3
#define SwitchActivation 0
#define LED LATC.3
#define PWMMask 0b00001100
#define BUZZER LATC.2
#define FAN	LATA.4

#define CoefA	2.9014247E-3
#define CoefB	-1.8081413E-4
#define CoefC	2.09088E-6


/* ******** Global Variable ************ */
uns16 ms;
bit msflg,msops;
char sec,min,hour;
char Priority;
uns16 tempoms,tempoms2,tempoms3;
bit timer1,timer2,timer3;
uns16 beepfreq,beeptime;
uns16 ANLICHRG,TempADC,ANLVchrg,ADRes;
uns16 TempDegC;
char NextANP;


/* ***** Procerdures Prototypes ****** */
void bootprocess (void);
void I2CSlaveInt(void);
void Beeper (char mode);
void CalcDegC (void);
// --