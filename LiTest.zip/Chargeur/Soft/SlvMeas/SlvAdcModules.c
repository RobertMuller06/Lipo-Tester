/* ****** modules ******/
void tempobeep (uns16 durationms,bit locked)		// max 65 sec but no validity check on param
{
	tempoms3 = durationms + 1; 
	timer3 = 1;
	if (locked)
	while (timer3);
}
void setfreq (uns16 freq)
{
	uns16 calc,calc2;
	char dat;
	
	calc = 62500 / freq;
	PR4 = calc.low8;
	calc2 = 2*calc;
	CCP3CON = PWMMask;
	CCP3CON.5 = calc2.1;
	CCP3CON.4 = calc2.0;
	dat = calc2 / 4;
	CCPR3L = dat;
}
	
void Beeper (char mode)
{
	char i;
	uns16 frq;
	
	if (mode == 0)	// freq,duration 
	{
	}	
	else
	switch (mode)
	{
		case 1:		//1sec 1000hz
		{
			setfreq(500);
			tempobeep(1000,1);
			break;
		}
		case 2:
		{
			frq = 200;
			for (i=0;i!=100;i++)
			{
				setfreq(frq);
				tempobeep(20,1);
				frq += 18;
			}			
			break;
		}
		case 3:
		{
			for (i=0;i!=5;i++)
			{
					setfreq(500);
					tempobeep(500,1);
					setfreq(1000);
					tempobeep(500,1);
			}
			break;	
		}
		case 4:
		{
			for (i=0;i!=5;i++)
			{
				setfreq(2000);
				tempobeep(500,1);
				setfreq(3000);
				tempobeep(500,1);
			}
			break;
		}
		case 5:		//1sec 1000hz
		{
			setfreq(1500);
			tempobeep(25,1);
			break;
		}				
	}
	CCP3CON = 0;
	BUZZER = 0;	
}

#pragma codepage 1

#include "MATH24F.H"
#include "MATH24LB.H"

#pragma codepage 1
		
void CalcDegC (void)
{
	#pragma rambank 1

	float24 calc,calc1,calc2,ValCTN,dsp;
	// process value of temperature
	// first calculate value of voltage in mV
	calc = TempADC;
	calc = calc / 1023;
	calc = calc * 4.096;	//calc in Volt
	// then value of resitor in ohms : R = (Vs * R1) / (Ve - Vs)
	calc2 = calc;		// calc2 = vs  0..5v
	calc1 = calc2 * 15000;		// Vs * r1  r1 = 15K
	calc2 = V5V - calc2; 		//ve - vs
	ValCTN = calc1 / calc2;		// val r ctn
	// apply formula of SteinHart-Hart
	calc1 = log(ValCTN);	//log R
	calc = CoefC * calc1;	//+ (C *(log R)^3)
	calc = calc * calc1;
	calc = calc * calc1;
	calc2 = CoefB * calc1;	//+ (B * log R)
	calc += calc2;
	calc += CoefA;			//+A
	calc2 = calc;
	calc1 = 1;
	calc = calc1/calc2;			// 1/T completes formula
	dsp = calc - 273.15;			// convert deg K to deg C
	//then convert to integer and assign value for return
	if (dsp < 0) dsp = 0;
	TempDegC = (int)dsp;
	if (TempDegC < 10) TempDegC = 10;
	validtp = 1;
}
