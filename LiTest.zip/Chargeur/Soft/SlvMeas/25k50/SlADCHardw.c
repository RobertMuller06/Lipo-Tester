/* Harware routine */
// eeprom rtgs
char readprom (char eadr)
{

	EEADR = eadr;
	EECON1.2 = 0;		//WREN
	EECON1.7 = 0;		//EEPGD
	EECON1.6 = 0; 		// CFGS
	EECON1.0 = 1;

	return EEDATA;
}

void writeprom (char eadr , char edata)
{	while (EECON1.1 == 1);
	EEADR = eadr;
	EEDATA = edata;	
	STATUS.05 = 1;
	EECON1.07 = 0;
	GIE = 0;
	EECON1.02 = 1;
	EECON2 = 0x55;
	EECON2 = 0xAA;
	EECON1.1 = 1;
	STATUS.05 = 0;
	EECON1.02 = 0;
	GIE = 1;
} 