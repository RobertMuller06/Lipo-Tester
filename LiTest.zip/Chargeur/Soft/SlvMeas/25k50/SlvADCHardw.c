/* Harware routine */
// eeprom rtgs
char readprom (char eadr)
{

	EEADR = eadr;
	EECON1.2 = 0;		//WREN
	EECON1.7 = 0;		//EEPGD
	EECON1.6 = 0; 		// CFGS
	EECON1.0 = 1;

	return EEDATA;
}

void writeprom (char eadr , char edata)
{	while (EECON1.1 == 1);
	EEADR = eadr;
	EEDATA = edata;	
	STATUS.05 = 1;
	EECON1.07 = 0;
	GIE = 0;
	EECON1.02 = 1;
	EECON2 = 0x55;
	EECON2 = 0xAA;
	EECON1.1 = 1;
	STATUS.05 = 0;
	EECON1.02 = 0;
	GIE = 1;
}

uns16 PICADC (void)
{
	GO = 1;
	while (GO == 1);
	ADCTemper.high8 = ADRESH;
	ADCTemper.low8 = ADRESL;
	return ADCTemper;	
} 

void GETADC (char chanel)
{
	char i;
	uns16 j;

	if (chanel < 4)
	{

		j.high8 = 0;
		j.low8 = chanel;
		ADC[chanel] = j;
	}

/*	else
	{
		ADC2_RC = 1;		
		for (i=0;i!=10;i++);
		if (chanel.2 == 0) A0 = 0; else A0 =1;
		if (chanel.3 == 0) A1 = 1; else A1 = 0;
		nop();
		ADC2_RC = 0;
		ADC_BYTE = 1;
		nop();
		ADC2_RC = 1;
		nop();
		j.high8 = PORTA;
//		ADC_BYTE = 0;
		j.low8 = PORTA;
		ADC[chanel] = j;
		ADC2_RC = 0;
		ADC1_RC = 0;
	}		
*/		
}	