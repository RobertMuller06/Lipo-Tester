/*  ACTION MODULE  */
void Code0 (void)
{
	LED = LEDoff;
	I2Cbufout[0] = 3; 
	I2Cbufout[1] = 'O';
	I2Cbufout[2] = 'K';
	i2csend (3);
	I2CBusy = 0;	
}	
void Code1 (void)		//Return ADC value
{

	char dati,i;
	uns16 j;
	
	I2Cbufout[0] = 3;
	i = I2Cbufin[2];
	if (i == 8)
	{
		I2Cbufout[1] = ADCTemper.high8;
		I2Cbufout[2] = ADCTemper.low8;
	

	}
	else if (I2Cbufin[2] < 8)
	{
		j = ADC[i];
		I2Cbufout[1] = j.high8;
		I2Cbufout[2] = j.low8;
	}
	else
	{
	 	I2Cbufout[1] = 0;
	 	I2Cbufout[2] = 0;
	} 
	i2csend(3);	

}

void Code2(void)	// led
{
	if (I2Cbufin[2] == 1)
	LED = LEDon;
	else 
	LED = LEDoff;
}		