/* Lipo Tester Slave for Measure */
#pragma sharedAllocation
#include "SlvADC.h"
#include "int18XXX.H"

/* *****************************************************
*           CODE                                       *
****************************************************** */
#pragma origin 8
interrupt High_int_server( void)
{
	#pragma fastMode
	High_Int();
}

#pragma origin 0x18
interrupt Low_int (void)
{
	int_save_registers
	if (TMR2IF)
	{
	// clock
		TMR2IF = 0;
		ms = ms + 1;
		msflg = 1;
		if (ms == 1000)
		{
			sec = sec + 1;
			ms = 0;
			if (sec == 60)
			{
				min = min + 1;
				sec = 0;	
				if (min == 60)
				{
					hour = hour + 1;
					min = 0;
				}
			}
		}
		// tempo 
		if (timer1 == 1)	//for general use
		{
			tempoms--;
			if (tempoms == 0)
			{
				timer1 = 0;
			}
		}
		if (timer2 == 1)	//primary used for i2c timeout protection
		{
			tempoms2--;
			if (tempoms2 == 0)
			{
				timer2 = 0;
			}
		}		
	}
	if (SSPIF == 1)	//i2c rcv data
	{
		uns16 svfsr = FSR0;
		I2CSlaveInt();	
		FSR0 =svfsr;
	}	
	int_restore_registers
}

void High_Int(void)
{
	
}

#include "SlvADCHardw.c"
#include "I2CSlave.c"
#include "Actions.c"

// tempo, handled by real time interrupt
void tempo (uns16 durationms,bit locked)		// max 65 sec but no validity check on param
{
	tempoms = durationms + 1; 
	timer1 = 1;
	if (locked)
	while (timer1);
}

void tempoI2C (uns16 durationms)		// max 65 sec but no validity check on param
{
	tempoms2 = durationms + 1; 
	timer2 = 1;
}

void I2CAnalyse (void)
{
	char action;
	char indata;
	char nbrchar,i;
	uns24 val24;
	

	if (inpcompl)		// all data received in msg
	{
		inpcompl=0;
		// processing of i2c data rcvd
		action = I2Cbufin[1];	// 2nd char in buffer indicate which action
		switch (action)
		{
			case 0:
			{
				Code0();
				break;
			}	
			case 1:		// action code 1 return ADC
			{
				Code1();
				break;
			}
			case 2:		// action code 2
			{
				Code2();
				break;
			}
			case 3:		// action code 3
			{
				break;
			}
		}	
	}
}

void GetNextADC (bit ams)
{
	static char timecnt;
	static char adccnt;
		
	timecnt ++;
	if (timecnt == 50)
	{
		timecnt = 0;
;
		if (adccnt == 5) adccnt = 0;
		if (adccnt == 4)	//picadc
		{
			ADCTemper = PICADC ();
		}

		else 		// external adc
		{
			GETADC(adccnt);
		}
			adccnt++;	
	}

}		

void Housekeeping(bit hms)
{
	I2CAnalyse();
 	if (I2CBusy == 0) GetNextADC(hms);
}
	 
void RunInit(void)
{
	LED = LEDoff;
	I2CBusy = 1;
}	

void InitHard(void)
{
// init clocking system for internal clock
	OSCTUNE = 0x80; //3X PLL ratio mode selected
	OSCCON = 0x70;  //Switch to 16MHz HFINTOSC
	ACTCON = 0;  //disable active clock tuning
// turn power off on all periph, must be indivually turned on
	PMD0 = 0x0;	//ACTMD on
	PMD1 = 0x0;
	CMP1MD = 1;
	TBLPTRU = 0;
	ADCON1 = 0x0F;		// Default all pins to digital
	WDTCON = 0;
	RBPU = 0;
// all ports as digital at reset
	ANSELA = 0;		
	ANSELB = 0b00000100;	//PORTB 2 as analog
	ANSELC = 0;
// init ram
 	clearRAM(); 
// init intrpt
	INTCON = 0;
	INTCON2 = 0;
	INTCON3 = 0;
	PIR1 = 0;
	PIR2 = 0;
	PIE1 = 0;	
	PIE2 = 0;
	IPEN = 1;
// init ports
	LATA = 0;
	LATB = 0;
	LATC = 0;
	TRISA = 0xFF;
	TRISB = 0b11110111;
	TRISC = 0b00111000;
	ADC2_RC = 0;
	ADC1_RC = 0;
// init real time clk
	TMR2MD = 0;			//power up tmr
	nop();
	nop();
	PR2 = 74;
	T2CON = 0b01001110;
	TMR2IP = 0;			// low prior
	TMR2IE = 1;			// timer 2 can start now	
// init I2C
	I2CSInit ();
// init ADC for b2, temperature
	ADCMD = 0;
	nop();
	nop();
	ADCON0 = 0b00100001;		// adc on chn8
	ADCON1 = 0b10000000;		// vref =  vcc
	ADCON2 = 0b10111110;		// right just, tad8, fosc/16
	ADIE = 0;
// init IOC for busy's
	IOCIE = 0;
// turn on interrupts
	INTCON = 0b00100000;
	USBIE = 0;
	GIEH = 1;			// interrupts started
	GIEL = 1;
}	
void main(void)
{
	InitHard();
	RunInit();
	while (1)
	{
		if (msflg == 1) 
		{
			msops = 1;
			msflg = 0;
		}	
		Housekeeping(msops);
		msops = 0;
	}	
}