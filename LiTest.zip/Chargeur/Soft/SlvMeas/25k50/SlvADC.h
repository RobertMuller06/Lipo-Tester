/* Slave ADC controler */
#define Version "V:0.00 "

#define Date __DATE2__
#define Hardware "HARD:V1.0"

/****************************************************
           CONFIG (If needed, may be commented)
*****************************************************/

//  CONFIG bits  >> clock intr 16mhz pll x 3

#pragma config [0]  = 0x23	//LS48MHZ=1(48mhz sys clk), CPUDIV =00 (no),CFGPLLEN=0 (oscillator direct),PLLSEL=1(pll x 3)
#pragma config [1]  = 0x08	//IESO=0(no osc switchover),FCMEN=0(no clk failsafe),PCLKEN=0(primary clk can be dis),FOSC=1000(internal)
#pragma config [2]  = 0x0A	//LPBOR=0(BRO rst enab),BORV=01(2.5v),BOREN=01(bro crtrld by soft),PWRTEN=0(pwr up tmr ena)
#pragma config [3]  = 0x3E	//WDTPS=1111(max32768),WDTEN=10(soft ctrld)
#pragma config [4]  = 0		//NU
#pragma config [5]  = 0x91	//MCLRE=1(ext reset),SDOMX=0(SDO on RC7),T3CM=1(T3CKI on RC0),PBADEN=0(ANSELB),CCP2MX=1(CCP2 on RC1)
#pragma config [6]  = 0x81	//DEBUG=1(disable),XINST=0(extended instr dis),ICPRT=0(ICPORT dis),LPV=0(low volt ICSP dis),STRVEN=1(stack ovflow reset)
#pragma config [7]  = 0		//NU
// next part is code protection. No protection used.
#pragma config [8]  = 0x0F	//
#pragma config [9]  = 0xC0	//
#pragma config [10] = 0x0F	//
#pragma config [11] = 0xE0	//
#pragma config [12] = 0x0F	//
#pragma config [13] = 0x40	//


/* hardware definitions */

#define DATAREAD PORTA;
#define ADC1_RC LATB.3
#define ADC2_BUSY PORTB.4
#define ADC1_BUSY PORTB.5
#define SW3	PORTB.7 
#define ADC_BYTE LATC.0
#define ADC2_RC LATC.1
#define A1 LATC.2
#define LED LATC.6
#define A0 LATC.7
#define LEDon 0
#define LEDoff 1

/* global variables */
uns16 ms;
bit msflg,msops;
char sec,min,hour;
uns16 tempoms,tempoms2;
bit timer1,timer2;
bit LEDBlink;
char LEDTime;
bit I2CBusy;

#pragma rambank 1	//other variables
uns16 ADC[9];
uns16 ADCTemper;


/* prototypes */

void High_Int(void);
void tempo (uns16 durationms,bit locked);
void tempoI2C (uns16 durationms);
void I2CSInit (void);
void I2CSlaveInt (void);

/* EEPROM */

#define CDATA_START 0xF00000
#pragma cdata[CDATA_START]

#pragma cdata[] = 0

#pragma cdata[0xF000B0]
// ofs 176
#pragma cdata[] = "(c)Robert ","MULLER"," 2022 "//22 car
// ofs 198
#pragma cdata[] = "ANALYSER LI-XX" 	// 14 car
// ofs 212
#pragma cdata[] = Version	// 7 car
#pragma cdata[] = Hardware	// 9 car
#pragma cdata[] = Date		// 12 car
