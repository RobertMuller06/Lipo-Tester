/* Header Test Switches */

// Config bytes not possible with test compiler version
//#pragma config =    0b00100110001100
//#pragma config+2 = 0b00110110000011
//#pragma CDATA_END
// Clocking
#define b_CPUCLK					4L	// in Mhz
//#define b_CYCLK					CPUCLK / 4000L	// Instruction cycle (cpu div by 4)

// process value of USART BRG VALUE, BRGH = 1, BRG16 = 1
#define b_BAUDR			57600L			// value of baud rate needed
#define b_CONSTBR1		b_CPUCLK * 1000000L
#define b_CONSTBR2		b_CONSTBR1 / 4
#define b_CONSTBR3		b_CONSTBR2 / b_BAUDR
#define b_BAUDGEN		b_CONSTBR3 - 1

#if (b_BAUDGEN) > (255)
	#error BootLD Baud rate value not possible with BRDH=1  
#endif
/* **************** FLASH PROGRAM CAPACITY ***************/
// capacity of pgm memory in bytes (2 times number of 14bits words)
// 16 for 8k pgm words
#define FLASHCAPACITY 250		// ex 16 k for 16f876

/********************************************
		GLOBAL VARIABLES
********************************************/
#pragma rambank 3
bit boot_OK, boot_Verif;
char rxdata, bi, boot_tp;
// dump values sent to pc in case or error
char dmpadrh,dmpadrl,dmpdathrd,dmpdatlrd,dmpdathwr,dmpdatlwr;
#pragma rambank 4
char boot_bufflash[64];
#pragma rambank 3

/* Procedures Prototypes */
void boot_writeflash (uns16 fadr);
bit verif (uns16 fadr);
void boot_outsrl (char outcar);
char boot_waitsrl (void);
void bInitialize(void);