/* MesSelf Header file  */

/* *********************************************
CONFIG WORDS
01 = 09 C4
02 = 36 03
************************************************* */

/********************************************
		HARDWARE DEFINITIONS
********************************************/
// Define the switch port that will trigger bootloading
// switch activation must be 0 if switch makes 0 when pressed
// otherwise must be 1
#define SWITCH PORTC.3
#define TrisSw TRISC.3
#define SwitchActivation 0

// If a led is available for status info, define it here
// #define LED LATX.X

/* ******** Global Variable ************ */
uns16 ms;
bit msflg,msops;
char sec,min,hour;
uns16 tempoms,tempoms2;
bit timer1,timer2;

/* ***** Procerdures Prototypes ****** */
void bootprocess (void);
void I2CSlaveInt(void);