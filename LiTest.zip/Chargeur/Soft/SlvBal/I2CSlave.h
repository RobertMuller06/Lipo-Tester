#ifndef I2CSlave_h
#define I2CSlave_h

#pragma rambank 2
bit locki2c,tfrflg,mdrw,inpcompl,WaitTX;
char statedrvr,gdata,ptrtb,bufptrin,tpstate;
char limin,nbrout,i2cerrout,bufptrout;
  
char I2Cbufout[16];
char I2Cbufin[16]; 

#pragma rambank 0

#define I2CBaseAdr 2
#define I2CAddress I2CBaseAdr*2	
#endif