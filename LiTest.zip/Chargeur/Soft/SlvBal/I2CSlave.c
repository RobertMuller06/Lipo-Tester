/**************************************************
			I2C SLAVE MODE RTGS
*****************************************************/
#include "I2CSlave.h"
/**********************************************
    I2C Slave initialization
***********************************************/
void I2CSInit (void)
{
	char i;
	
	TRISC.0 = 1;
	TRISC.1 = 1;
	LATC.0 =1;
	LATC.1 =1;
	SSP1STAT = 0b00000000;
	SSP1CON1 = 0b00110110;		// i2c slave 7b adr
	SSP1CON2 = 0b00000000;
	SSP1ADD= 4; // address 2 
	SSP1CON3 = 0b01100000;
	i = SSP1BUF;  // dummy read to clear buffe
	SSP1IF = 0;
	SSP1IE = 1;
}	


/********* Interrupt handler ***********************
	This rtg must be called from interrupt process
	-First caracter received must be the number of data bytes
	 to be received
*******************************************************/
void I2CSlaveInt (void)
{

	SSP1IF = 0;
//		if (locki2c == 0)
	statedrvr = SSP1STAT;

	statedrvr = statedrvr & 0b00100101;
	if (statedrvr == 0b00000001) // rcvd read adress
			{

				gdata = SSP1BUF & 0xFE;
				if (gdata == I2CAddress)		// my i2c adress is ok
				{
					tfrflg=1;
					mdrw = 0;			// assess read mode
					bufptrin = 0;
				
				}
			}	
			if (statedrvr == 0b00000101) // rcvd write adress 
			{
	// clock locked auto				
				gdata = SSP1BUF & 0xFE;
				if (gdata == I2CAddress)
				{		
					tfrflg=0;
					SSP1IE = 0;	// next done in polling mode
					mdrw = 1;
					WaitTX=1;
					SSP1IF = 0;
				}
			}

			if (statedrvr == 0b00100001 && mdrw == 0) // rcvd read data
			{

				I2Cbufin [bufptrin]=SSP1BUF;
				bufptrin = bufptrin + 1;
				if (bufptrin == 1) 
				{
					limin = I2Cbufin [0];			
				}
				SSP1IF = 0;
				if (limin == bufptrin)		// All char rcvd ?	
				{
					inpcompl = 1;
					tfrflg = 0;
				}
			}
}



/************ I2C SLAVE SENDING ********************
Polling mode 
***************************************************/

void i2csend (char nbrsent)

{
	char count,statssp;

	while (WaitTX == 0);	//we are here before write rqst recvd
	WaitTX = 0;
	i2cerrout = 0;
	tempoI2C(50);		//timeout protection
	count = 1;
	SSP1BUF = I2Cbufout[0];
	CKP = 1;	//enable clk again
	while (timer2 && ACKSTAT == 0)
	{
		if (SSP1IF == 1)
		{
			statssp = SSP1STAT & 0b00000000;
			if (!timer2)
			{
				i2cerrout = 1;
			}
			if (statssp == 0b00000000) // next write data
			{
				SSP1IF = 0;
				SSP1BUF = I2Cbufout [count];
				CKP = 1;		//clk for next byte

				count++;
				nbrsent--;
			}
			else
			{
				i2cerrout = 2;
			}
		}
	}
	SSP1IF = 0;
	SSP1IE = 1;		// ready for next receive
	mdrw = 0;
	CKP = 1;	
	inpcompl = 0;
	bufptrin = 0;
	tfrflg = 0;
	locki2c = 0;
}
	