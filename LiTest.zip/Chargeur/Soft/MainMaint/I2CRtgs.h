#ifndef I2C_h
#define I2C_h

/**** I2C DEFINES *****/

// baud factor
#define I2CSPEED	600L			// 400L for 400Khz
#define TVAL1		(CYCLK*1000L)	// CYCLK in khz!
#define I2C_BAUD 	TVAL1 / I2CSPEED

#define I2CbuffersizeOut	21
#define I2CbuffersizeIn		21

// slave Address
//#define I2CAddress 2	// bit 0 reserved, val 2 is adrs 1 

/******* I2C Variables ********/
#pragma rambank 3
// below not used, only for compat.
char I2CTmr;
char i2cerrout;
char i2cerrin;
char i2cstate;

//  Specific Slave variables
#ifdef I2CSlave

bit locki2c,tfrflg,mdrw,inpcompl,bufptrou,tflg1;
char I2C_SlvStatus,gdata,ptrtb,bufptrin;
char I2C_State;
char limin,nbrout,i2cerr,bufptrout;

#endif

//  Specific Master polled variables 
#ifdef I2CMaster

bit wr_plus_rd;
char iadr, I2C_State;
char bufptrin;
char i2cerr;
#endif

//  Specific Master Interrupt  variables 
#ifdef I2CMastInt

bit wr_plus_rd;
char iadr, I2C_State,idati;
char bufptrin,I2Cidx,I2CcntO,I2CcntI;
char i2cerr;
#endif

/** In + out buffers, length to be adapted as needed  */
#pragma rambank 3
char I2Cbufout[I2CbuffersizeOut];
char I2Cbufin[I2CbuffersizeIn];
#pragma rambank 3 
char flbuf[I2CbuffersizeIn];

#pragma rambank 0

#endif
