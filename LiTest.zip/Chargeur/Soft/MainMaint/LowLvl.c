/************ LOW LEVEL ROUTINES *****************/
// tempo, handled by real time interrupt
void tempo (uns16 durationms,bit locked)		// max 65 sec but no validity check on param
{
	tempoms = durationms + 1; 
	timer1 = 1;
	if (locked)
	while (timer1);
} 

/* *****Small delay   ***** 
  around 60us
***************************** */
/*
void delay(void)
 {
	 char i;
	 
	 for (i=0; i!=120;i++);

} 

*/
// prepare a 16 bit value for display in ascii
void cvhexbcd (uns16 valcnv)
{
	uns16 tmpv;
	
	dmil = valcnv / 10000;
	tmpv = (long)dmil * 10000;
	valcnv = valcnv - tmpv;
	mil = valcnv / 1000;
	tmpv = (long)mil * 1000;
	valcnv = valcnv - tmpv;
	cent = valcnv / 100;
	tmpv = (long)cent * 100;
	valcnv = valcnv - tmpv;
	dix = valcnv / 10;
	tmpv = (long)dix * 10;
	un = valcnv - tmpv;	
	dmil = dmil + 0x30;
	mil = mil + 0x30;
	cent = cent + 0x30;
	dix = dix + 0x30;
	un = un + 0x30;
}

// prepare a 24 bit value for display in ascii

void cvhexbcdL (uns24 valcnv)
{
	uns24 tmpv;
	
	dmillion = valcnv /10000000;
	tmpv = dmillion * 10000000;
	valcnv = valcnv - tmpv;
	million = valcnv / 1000000;
	tmpv = million * 1000000;
	valcnv = valcnv - tmpv;	
	cmil = valcnv / 100000;
	tmpv = (uns24)cmil * 100000;
	valcnv = valcnv - tmpv;
	dmil = valcnv / 10000;
	tmpv = (uns24)dmil * 10000;
	valcnv = valcnv - tmpv;
	mil = valcnv / 1000;
	tmpv = (uns24)mil * 1000;
	valcnv = valcnv - tmpv;
	cent = valcnv / 100;
	tmpv = (uns24)cent * 100;
	valcnv = valcnv - tmpv;
	dix = valcnv / 10;
	tmpv = (uns24)dix * 10;
	un = valcnv - tmpv;
	dmillion = dmillion + 0x30;
	million = million + 0x30;
	cmil = cmil + 0x30;
	dmil = dmil + 0x30;
	mil = mil + 0x30;
	cent = cent + 0x30;
	dix = dix + 0x30;
	un = un + 0x30;
}


/*  display value char in ascii hex 0-9,A-F */
/*
void cvhexascii (char valcnv)
{
	un = valcnv & 0x0F;
	un += 0x30;
	if (un > 0x39) un += 7;
	dix = valcnv / 16;
	dix += 0x30;
	if (dix > 0x39) dix += 7;  
}
*/	
// ***  display a value on screen ****
// input param are 
// character position x, line position y
// nmuber of digits to display, position of coma (or 0)
// font to used

void dispval (char xx,char yy, char nbdigits,char virgule,char font)
{
	char cntr;
	
	cntr = 0;
	switch (nbdigits)
	{
		case 1:
		{
			txt[0] = un;
			txt[1] = 0;
			break;
		}
		case 2:
		{
			txt[cntr] = dix;
			cntr ++;
			if (virgule == 1)
			{
				txt[cntr] = ',';
				cntr++;
			}
			txt[cntr] = un;
			cntr++;
			txt[cntr] = 0;
			break;
		}
		case 3:
		{
			txt[cntr] = cent;
			cntr ++;
			if (virgule == 1)
			{
				txt[cntr] = ',';
				cntr++;
			}
			txt[cntr] = dix;
			cntr++;
			if (virgule == 2)
			{
				txt[cntr] = ',';
				cntr++;
			}
			txt[cntr] = un;
			cntr ++;
			txt[cntr] = 0;
			break;
		}		
		case 4:
		{
			txt[cntr] = mil;
			cntr++;
			if (virgule == 1)
			{
				txt[cntr] = ',';
				cntr++;
			}
			txt[cntr] = cent;
			cntr++;
			if (virgule == 2)
			{
				txt[cntr] = ',';
				cntr++;
			}
			txt[cntr] = dix;
			cntr++;
			if (virgule == 3)
			{
				txt[cntr] = ',';
				cntr++;
			}
			txt[cntr] = un;
			cntr++;
			txt[cntr] = 0;
			break;
		}
		case 5:
		{
			txt[cntr] = dmil;
			cntr++;
			if (virgule == 1)
			{
				txt[cntr] = ',';
				cntr++;
			}
			txt[cntr] = mil;
			cntr++;
			if (virgule == 2)
			{
				txt[cntr] = ',';
				cntr++;
			}
			txt[cntr] = cent;
			cntr++;
			if (virgule == 3)
			{
				txt[cntr] = ',';
				cntr++;
			}
			txt[cntr] = dix;
			cntr++;
			if (virgule == 4)
			{
				txt[cntr] = ',';
				cntr++;
			}
			txt[cntr] = un;
			cntr++;
			txt[cntr] = 0;
			break;
		}			
	}		
	LCDK_PrintLine(font,xx,yy,0);
}	

/************** Upper Case conversion ************
return upper case value of char in param if alpha 
*************************************************/ 
char UpCase (char dati)
{
	if ((dati > 0x60) && (dati < 0x7B)) dati -= 0x20;
	return dati;
	
}	

// eeprom rtgs

char readprom (char eadr)
{

	EEADR = eadr;
	EECON1.2 = 0;		//WREN
	EECON1.7 = 0;		//EEPGD
	EECON1.6 = 0; 		// CFGS
	EECON1.0 = 1;

	return EEDATA;
}

void writeprom (char eadr , char edata)
{	while (EECON1.1 == 1);
	EEADR = eadr;
	EEDATA = edata;	
	STATUS.05 = 1;
	EECON1.07 = 0;
	GIE = 0;
	EECON1.02 = 1;
	EECON2 = 0x55;
	EECON2 = 0xAA;
	EECON1.1 = 1;
	STATUS.05 = 0;
	EECON1.02 = 0;
	GIE = 1;
	tempo(5,1);
}

// *** rotary switch  ***
// rotary switch changes are recorded in upcntr
// push button changed to push is recorded in RselSWchg 
void HandelRotary (void)
{
	SELA = CpyPC.0;
	SELB = CpyPC.1;
	SELSW = CpyPB.7;
	if(RotaryDebounce == 0)
	{
	if (oldselA != SELA)
	{
		rochg = 1;
		oldselA = SELA;
		RotaryDebounce = RotDebounceTmr; 
	}
	if (oldselB != SELB)
	{
		rochg = 1;
		oldselB = SELB;
		RotaryDebounce = RotDebounceTmr;
	}
	if (oldselSW != SELSW)
	{
		
		oldselSW = SELSW;
		if (oldselSW == 0) RselSWchg = 1;
		if (oldselSW == 1) ReslSWup = 1;
		RotaryDebounce = RotDebounceTmr;	
	}


	if (rochg != 0)
	{
		Rselchg = 1;
		rochg = 0;
		newsel.1 = oldselB;
		newsel.0 = oldselA ;	
	
		switch (Roldsel)
		{
			case (0b00):
			{
				if (newsel == 0b10)
				{
					 if (upcntr < upplus) upcntr++;
				}	
				if (newsel == 0b01)
				{
					 if (upcntr > upmoins) upcntr--;
				}	 
				break;
			}

		}
		Roldsel = newsel;
//		if (SlowRot == 1) upcntr /= 2;
	}
	}
}
void InitRotary (void)
{

	oldselA = SELA;
	oldselB = SELB;
	Roldsel = 3;
	upcntr = 0;
	dwncntr = 0;
}

// *** look for a key pressed with debouncing ***
// change reported in SW1, SW2 or SW3
/*
void HandelKeys(void)
{
	//turn off led to show any key pressed
	if ((PORTSW1 == 0) || (PORTSW2 == 0) || (PORTSW3 == 0))
	{
		FlashFg = 0;	
		LED = 0;
	}
	else 
	{
		if (FlashFg == 0)
		{
			FlashFg = 1;
			LED = 1;
		}
	}		
		
	if (SwDebounce == 0) 
	{ 
		if (PORTSW1 == 0) 
		{
			if (StatSw1 == 0)
			{
				StatSw1 = 1;
				SwDebounce = KDebounceTmr;
			}	
		}
		else
		{
			if (StatSw1 == 1)
			{
				SW1 = 1;
				StatSw1 = 0;
				SwDebounce = KDebounceTmr;
			}
		}
		if (PORTSW2 == 0)
		{
			if (StatSw2 == 0)
			{
				StatSw2 = 1;
				SwDebounce = KDebounceTmr;
			}	
		}
		else
		{
			if (StatSw2 == 1)
			{
				SW2 = 1;
				StatSw2 = 0;
				SwDebounce = KDebounceTmr;
			}
		}
		if (PORTSW3 == 0)
		{
			if (StatSw3 == 0)
			{
				StatSw3 = 1;
				SwDebounce = KDebounceTmr;
			}	
		}
		else
		{
			if (StatSw3 == 1)
			{
				SW3 = 1;
				StatSw3 = 0;
				SwDebounce = KDebounceTmr;
			}
		}		 		 		 
	}	
}
*/
	

/* send data to electronic pot ************/
void SrlTfr (char dato)
{
	char i;
	
	for (i=0;i!=8;i++)
	{
		SDOUT = dato.7;
		dato *= 2 ;
		SCKL = 1;
		nop();
		nop();
		SCKL = 0;
		
	}	 
	
}

// **** prepare data for setting pot ****
// parameter is pot number	
void LoadPot (char Branch)
{
	char dati,dato;
	
	if (Branch < 2 )CSPOT1 = 0;
	else CSPOT2 = 0;
	switch (Branch)
	{
		case 0:
		{
			dato = 0b00010001;
			SrlTfr(dato);
			dato = VPot[0];
			SrlTfr(dato);
			nop();
			nop();
			nop();
			nop();
			nop();
			nop();
			CSPOT1 = 1;	
			SDOUT = 0;
			SCKL = 0;
			break;
		}
		case 1:
		{
			dato = 0b00010010;
			SrlTfr(dato);
			dato = VPot[1];
			SrlTfr(dato);
			nop();
			nop();
			nop();
			nop();
			nop();
			nop();
			SDOUT = 0;
			SCKL = 0;
			break;
		}
		case 2:
		{
			dato = 0b00010001;
			SrlTfr(dato);
			dato = VPot[2];
			SrlTfr(dato);
			nop();
			nop();
			nop();
			nop();
			nop();
			nop();
			SDOUT = 0;
			SCKL = 0;
			break;
		}
		case 3:
		{
			dato = 0b00010010;
			SrlTfr(dato);
			dato = VPot[3];
			SrlTfr(dato);
			nop();
			nop();
			nop();
			nop();
			nop();
			nop();
			SDOUT = 0;
			SCKL = 0;					
			break;
		}				
	}
	CSPOT1 = 1;
	CSPOT2 = 1;
		
}	


/********************************************************
Sequencialy read each analog port. Result updated by interrupt
(values of current)
if mode bit is set, read also voltage values from slave processor. 
**********************************************************/


void ADCModule (void)
{
	
	while (GO != 0);			// adc is ready 
	ADIF = 0;
	NextANP++;	
	if (NextANP == 2) NextANP = 0;
	if (NextANP == 0) ADCON0 = 1;
	else ADCON0 = 0b101;
	nop();
	nop();
	nop();
	nop();
	nop();
	nop();
	nop();
	nop();
	nop();
	GO = 1;			// start AD	conversion
}


/*********** GET TEXT *******************
read nbrchar text bytes from external flash memory
input : txtid is index of msg in flash
	nbrchar needed also for address offset calculation
output : text in I2Cbufin buffer
***********************************************/

char GetText (char TxtId,char StartPos, char nbrchar,bit upper)
{
	uns16 ad1,ad2,ad3;
	char i,j,k,dati,ptr;

	if (nbrchar > 25) nbrchar = 25;
	ad1 = (uns16)TxtId * 2;
	readflash (ad1,4);
	ad1.high8 = I2Cbufin[0];
	ad1.low8 = I2Cbufin[1];
	ad2.high8 = I2Cbufin[2];
	ad2.low8 = I2Cbufin[3];
	ad2 = ad2-ad1;		
	//actual length of data
	for (i=0;i!=20;i++)txt[i] = ' ';
	ptr = ad2.low8 ;
	ad3 = ad1 + StartPos;
	readflash (ad3,ptr);
	for (i = 0; i!= ptr; i++)
	{
		j = I2Cbufin[i];
		if (upper) j = UpCase (j);
		txt[i] = j;
	}
//	i++;
	txt[i] = 0;
	return ptr;
}


/********************* DISPLAY TEXT *******
	- See doc DialogueI2C for protocol details
- Input : Text to display is in I2Cbufin after GetText
    position of text : col (0-39), raw (0-1)
	number of char to display : number
	flag upper set forces displayed char in uppercase
- all sent to the display unit in I2C, adr 2  	
************************************************/
/*
void DisplayText (char col,char raw,char number,bit upper)
{
	uns16 adrs=0;
	char i,j;
	char tp;
	
	if (upper)
	{
		for (i=0;i!=number;i++)
		{
			j = TextBuf[i];
			if (upper) j = UpCase (j);
			txt[i] = j;
		}
	}
	number++;
	txt[i] = 0;

}
*/
void USBget ()
{
	char *inpc,*outc;
	char USBnbr;
	KeyPressed = 0;

	LED = 1;
	inpc = &input_buffer[0];
	USBnbr = getsUSBUSART (inpc,32); // if nothing rcvd, USBnbr = 0		
	if (USBnbr != 0)
	{
		if ((input_buffer[0] == 'R') && (input_buffer[1] == 'M') && (input_buffer[2] == 'b') && (input_buffer[3] == 't'))
		{
			con_up = 1;
			output_buffer[0] = 'b';
			output_buffer[1] = 't';
			while (cdc_trf_state != CDC_TX_READY);
			outc = &output_buffer[0];
			putBinUSBUSART (outc,2);	//effective tx when ProcessIO is run 
			//USBCheckBusStatus();
			CDCTxService();	
			tempo (200,1);
		}
	}
	endtfr = 0;
}

void USBTfr()
{
	char *inpc,*outc;
	char i,USBnbr,bcc,dati,tp,ctr;
	uns16 fadr = 0;
	bit abort;

	tp=0;
	ctr=0;
	abort = 0;
	KeyPressed = 0;
	
	while ((fadr !=0xff00) && (!abort))
	{
		inpc = &input_buffer[0];
		USBnbr = getsUSBUSART (inpc,20); // if nothing rcvd, USBnbr = 0		

		if (USBnbr != 0)
		{
			ctr++;
			if (input_buffer[0] == 27)
			{
				fadr.high8 = input_buffer[1];
				bcc = input_buffer[1];
				fadr.low8 = input_buffer[2];
				bcc += input_buffer[2];
				if (fadr == 0xff00) break;
				for (i = 0; i!= 16;i++)
				{
					dati = input_buffer[i+3];
					bcc += dati;
					flbuf[i] = dati;
				}
				if (fadr == 0xff00) break;
				if (bcc == input_buffer[19])
				{
					writeflash(fadr,16);
					output_buffer[0] = 27;
					output_buffer[1] = 6;
					outc = &output_buffer[0];
					putBinUSBUSART (outc,2);	//effective tx when ProcessIO is run 
					while (cdc_trf_state != CDC_TX_READY)
					{
						CDCTxService();
					}
				}
				else
				{
					output_buffer[0] = 27;
					output_buffer[1] = 7;
					while (cdc_trf_state != CDC_TX_READY)
					{
						CDCTxService();
					}
					outc = &output_buffer[0];
					putBinUSBUSART (outc,2);	//effective tx when ProcessIO is run 
					USBCheckBusStatus();
				}
			}
			if (fadr == 0xff00) break;
		}	
	input_buffer[0] = 0;
	}
	endtfr = 1;

}

uns16 ConvertV (uns16 VAdc,float32 Coef,int CfB)
{
	uns16 ValV;
	float32 calc,calc2;
	
	calc = (float32)VAdc;
	calc = calc * Coef;
	calc2 = (float32) CfB;
	calc += calc2;
	ValV = calc;
	return ValV;
}	

void GetCalibr()
{
	char i;
	uns16 k;
	float32 calc32;
	int calc16;
	
	VContrast = readprom(0);
	for (i=0;i!=12;i++)
	{
		k = i*6;
		k++;
		calc32.high8 = readprom(k);
		k++;
		calc32.midH8 = readprom(k);
		k++;
		calc32.midL8 = readprom(k);
		k++;
		calc32.low8 = readprom(k);
		CoefA[i] = calc32;
		k++;
		calc16.high8 = readprom(k);
		k++;
		calc16.low8 = readprom(k);
		CoefB[i] = calc16;
	}		
}	

void SetADC (char Channel)
{
	char dat;
	
	dat = Channel * 32;
	I2Cbufout[0]  = 0b10001000 | dat;
	I2Cbufout[1] = 0;
	I2Cbufout[2] = 0;
	I2CLenCtrl = 0;
	if (Channel < 4) iadr = 0xD0;  	
	else iadr = 0xD8;
	I2Cout(1,3);
}

uns16 ReadADC (char Channel)
{
	char dat;
	uns16 val;
	
	dat = Channel * 32;
	I2Cbufout[0]  = 0b00001000 | dat;
	if (Channel < 4) iadr = 0xD0;	
	else iadr = 0xD8;
	I2Cbufin[0] = 0;
	I2Cbufin[1] = 0;  
	I2Cout(1,3);			
	val.high8 = I2Cbufin[0];
	val.low8 = I2Cbufin[1];
	cvhexbcd(val);
	txt[0] = dmil;
	txt[1] = mil;
	txt[2] = cent;
	txt[3] = dix;
	txt[4] = un;
	txt[5] = 0;
	return val;
}

void ResetRot (void)
{
	upplus = 255;
	upmoins = 0;
	upcntr = 0;
}		