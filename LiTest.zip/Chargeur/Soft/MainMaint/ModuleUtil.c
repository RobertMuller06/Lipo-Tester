/* ******************************************************
      utilities for modules
 ******************************************************* */
#ifndef MdUt 
#define MdUt

void Help (char IdxMsg, char NbrLn)
{
	char i;
	

	LCDK_Cls(0);
	for (i=0;i!=NbrLn;i++)
	{
		MnuPrtLn(IdxMsg+i,255,0,i,0);
	}
	MnuPrtLn(53,16,0,7,0);
	while (SW1 == 1);
	tempo(10,1);
	LED = 1;
	while (SW1 == 0);
	tempo(50,1);
	LED = 0;
	LCDK_Cls(0);
}	

uns16 moddgt (char dgt, uns16 valin, bit Rev)
{
	switch (dgt)
	{
		case 0:
		{
			if (Rev) valin += 1;
			else  if (valin != 0) valin -= 1;
			break;
		}
		case 1:
		{
			if (Rev) valin += 10;
			else  
			{
				 if (valin > 9) valin -= 10;
			} 
			break;
		}
		case 2:
		{
			if (Rev) valin += 100;
			else if (valin > 99) valin -= 100;
			break;
		}
		case 3:
		{
			if (Rev) valin += 1000;
			else if (valin > 999) valin -= 1000;
			break;
		}
		case 4:
		{
			if (Rev) valin += 10000;
			else if (valin > 9999) valin -= 10000;
			break;
		}	
	}
	return valin;	
}	

void Backup (void)
{
	uns16 BaseAdr,calc16;
	char i,j,k,dati;
	
	tempo(30,1);
	BaseAdr = 0x3f00;
	i=0;
	j=0;
	k=0;
	while (i<=240)
	{
		dati = readprom(i);
		flbuf[j] = dati;
		j++;
		if (j == 16)
		{
			j = 0;
			calc16 = BaseAdr + k;
			writeflash (calc16,16);
			k+=16;
		}
		i++;	
	}	
}

void Restore (void)
{
	uns16 BaseAdr,calc16;
	char i,j,dati,er,PromAdr;
	
	i = 0;
	j = 0;
	PromAdr = 0;
	BaseAdr =0x3f00;
	while (i < 176)		//no restore of version infos
	{	
		calc16 = BaseAdr + i;
		er = readflash (calc16,16);
		if (er == 0)
		{
			for (j=0;j!= 16;j++)
			{
				dati = I2Cbufin[j];
				writeprom(PromAdr,dati);
				PromAdr++;
			}
			i += 16;	
		}	
		else i = 176;	
	}
}		

#endif