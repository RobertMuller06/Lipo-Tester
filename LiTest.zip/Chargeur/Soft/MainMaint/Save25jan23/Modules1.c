
void UpdateEEprom (void)
{
	LED = 1;
	LCDK_Cls(0);
	MnuPrtLn(28,13,0,2,0);
	MnuPrtLn(29,17,0,6,0);
	con_up = 0;
	endtfr = 0;
	USB_Hdwr_Init();
	FlgUSB = 0;
	USBIF = 0;
	USBIE = 1;		// as from now usb is handled in interrupt mode
	USBCheckBusStatus();
	tempo(10,1);
	USBCheckBusStatus();
	LED = 0;
	tempo(200,1);
	while (endtfr == 0)
	{
		if (!con_up)
		{
			USBget();	// handshake with pc 
			if (SW1 == 0)
			{
				endtfr = 1;
			}
		}	
		else
		{
			LCDK_Cls(0);
			MnuPrtLn(30,12,0,2,0);
			tempo(50,1);
			if (endtfr == 0)USBTfr();	//transfer datas in eeprom
			endtfr  = 1;
		}
	}
	USBModuleDisable();
	KeyPressed = 0;
	
}

void DispAdc (void)
{
	char dat,tctr;
	uns16 val;
	static char cline;
	static uns16 k;
	
	cline = 7;
	LCDK_Cls(0);
	tp = 0;
	k = 0;
	while (SW1 == 1)
	{
		if (MSFlg == 1)
		{
			MSFlg = 0;
			tctr++;
			if (tctr == 200)
			{
				tctr = 0;		
				cline ++;
				if (cline == 8) 
				{
					cline = 0;
				}	
				dat = cline * 32;
				I2Cbufout[0]  = 0b10001000 | dat;
				I2Cbufout[1] = 0;
				I2Cbufout[2] = 0;
				I2CLenCtrl = 0;
				if (cline < 4) iadr = 0xD0;  	
				else iadr = 0xD8;
				I2Cout(1,3);
				tempo(80,1);	//wait adc result (80 for 16 bits)
				dat = I2Cbufout[0];
				dat = dat & 0x7F;
				I2Cbufout[0] = dat;
				if (cline < 4) iadr = 0xD0;	
				else iadr = 0xD8;
				I2Cbufin[0] = 0;
				I2Cbufin[1] = 0;  
				I2Cout(1,3);			
				val.high8 = I2Cbufin[0];
				val.low8 = I2Cbufin[1];
				cvhexbcd (val);
				txt[0] = dmil;
				txt[1] = mil;
				txt[2] = cent;
				txt[3] = dix;
				txt[4] = un;
				txt[5] = ':';
				if (cline < 6)
				{
					val = I2Cbufin[2];
					cvhexbcd((uns16)cline+1);
					txt[6] = 'B';
					txt[7] = 'L';
					txt[8] = un;
				}
				else 
				{
					if (cline == 6)
					{
						txt[6] = 'I';
						txt[7] = 'D';
						txt[8] = 'c';
					}
					else
					{
						txt[6] = 'V';
						txt[7] = 'B';
						txt[8] = 'a';
					}		
				}	
				txt[9] = 0;
				LCDK_PrintLine(FONT6X8,0,cline,0);
				txt[4] = ':';
				txt[7] = 0;
				if (cline < 3)
				{
					I2Cbufout[0] = 3;
					I2Cbufout[1] = 1;
					if (cline == 0)
					{
						I2Cbufout[2] = 0;
						txt[5] = 'I';
						txt[6] = 'c';
					}
					else if (cline == 1)
					{
						I2Cbufout[1] = 5;
						I2Cbufout[2] = 0;
						txt[5] = 'T';
						txt[6] = 'p';
					}
					else if (cline == 2)
					{
						I2Cbufout[2] = 2;
						txt[5] = 'V';
						txt[6] = 'c';
					}		
					iadr = 6;
					I2Cout(3,3);
					val.high8 = I2Cbufin[1];
					val.low8 = I2Cbufin[2];
					cvhexbcd(val);
					txt[0] = mil;
					txt[1] = cent;
					txt[2] = dix;
					txt[3] = un;
					LCDK_PrintLine(FONT6X8,10,cline,0);	
				}
				else if (cline == 4)
				{
					cvhexbcd(INVBAT);
					txt[0] = mil;
					txt[1] = cent;
					txt[2] = dix;
					txt[3] = un;
					txt[5] = 'I';
					txt[6] = 'v';
					LCDK_PrintLine(FONT6X8,10,cline,0);	
				}
				else if (cline == 5)
				{
					cvhexbcd(MESVIN);
					txt[0] = mil;
					txt[1] = cent;
					txt[2] = dix;
					txt[3] = un;
					txt[5] = 'V';
					txt[6] = 'i';
					LCDK_PrintLine(FONT6X8,10,cline,0);	
				} 
				if (cline  == 7)
				{		
					k++;
					LED2 = !LED2;
					cvhexbcd(k);
					txt[0] = mil;
					txt[1] = cent;
					txt[2] = dix;
					txt[3] = un;
					txt[4] = 0;
					LCDK_PrintLine(FONT6X8,10,7,0);
				}
			}
		}
	}
	LED2 = 1;
}

void TestAlim (void)
{
	char invpot;
	uns16 val,dati;
	char oldup,tmp;
	bit ms,KeepV;
	
	LCDK_Cls(0);
	LED2 = 1;
	VPot [0] = 150;
	LoadPot(0);
	MnuPrtLn(24,18,0,0,0);
	MnuPrtLn(25,18,0,3,0);
	upmoins = 0;
	upcntr = 180;
	upplus = 255;
	oldup = 0;
	KeepV = 0;
	
	while (SW1 == 1)
	{
		if (SW2 == 0)
		{
			KeepV = 1;
			LED2 = 0;
		}	
		if (MSFlg == 1)
		{
			MSFlg = 0;
			ms = 1;
		}	
		if (oldup != upcntr)
		{
			oldup = upcntr;
			invpot = 255-upcntr;
			cvhexbcd(upcntr);
			dispval (0,1,3,0,FONT6X8);
			cvhexbcd (invpot);
			dispval (11,1,3,0,FONT6X8);
			VPot[0] = invpot;
			LoadPot(0); 
		}
		if (ms == 1)
		{
			tmp++;
			if (tmp == 200) tmp = 0;
		}	
		if (tmp == 0)
		{	
			I2Cbufout[0] = 3;
			I2Cbufout[1] = 1;
			I2Cbufout[2] = 2;
			iadr = 6;
			I2Cout(3,3);
			val.high8 = I2Cbufin[1];
			val.low8 = I2Cbufin[2];
			cvhexbcd(val);
			txt[0] = mil;
			txt[1] = cent;
			txt[2] = dix;
			txt[3] = un;
			txt[4] = 0;	
			LCDK_PrintLine(FONT6X8,11,4,0);	
			dati = ConvertV(val,58.836,0);
			dati += 316;
			cvhexbcd(dati);
			txt[0] = dmil;
			txt[1] = mil;	
			txt[2] = ',';
			txt[3] = cent;
			txt[4] = dix;
			txt[5] = un;
			txt[6] = 'V';
			txt[7] = 0;
			LCDK_PrintLine(FONT6X8,0,4,0);	
		}
	}
	if (KeepV == 0)
	{
		VPot [0] = 250;
		LoadPot(0);
		LED2 = 1;
	}	
		
}	


void TestCh (void)
{
	char oldup,tmp;
	uns16 val,dati;
	uns24 calci;
	
	LCDK_Cls(0);
	VPot [2] = 0;
	LoadPot(2);
	ResetRot();
	oldup = 1;
	upplus = 255;
	upmoins = 0;
	MnuPrtLn(26,17,0,0,0);
	MnuPrtLn(27,18,0,3,0);
	if (INVBAT > 400)			//no inversion of bat
	{
		BLOKICH = 0;
		RELAY = 1;
		while (SW1 == 1)
		{
			BLOKICH = !SW2;
			if (oldup != upcntr)
			{
				oldup = upcntr;
				cvhexbcd(upcntr);	
				dispval (0,1,3,0,FONT6X8);
				VPot[2] = upcntr;
				LoadPot(2);
			}
			if (MSFlg == 1)
			{
				MSFlg = 0;
				tmp++;
				if (tmp == 200) tmp = 0;
			}	
			if (tmp == 0)
			{	
				I2Cbufout[0] = 3;
				I2Cbufout[1] = 1;
				I2Cbufout[2] = 0;
				iadr = 6;
				I2Cout(3,3);
				val.high8 = I2Cbufin[1];
				val.low8 = I2Cbufin[2];
				cvhexbcd(val);
				dispval(11,4,4,0,Font6x8);
				cvhexbcd(INVBAT);
				dispval(11,1,4,0,Font6x8);
				val -= 44;
				calci = (uns24)val * 1000;
				calci /= 139;
				val = (uns16)calci;
				cvhexbcd(val);
				txt[0] = mil;
				txt[1] = ',';
				txt[2] = cent;
				txt[3] = dix;
				txt[4] = un;
				txt[0] = 'A';
				txt[6] = 0;
				LCDK_PrintLine(FONT6X8,0,4,0);
				I2Cbufout[0] = 3;
				I2Cbufout[1] = 1;
				I2Cbufout[2] = 2;
				iadr = 6;
				I2Cout(3,3);
				val.high8 = I2Cbufin[1];
				val.low8 = I2Cbufin[2];
				dati = ConvertV(val,62480,0);
				dati -= 3545;
				cvhexbcd(dati);
				txt[0] = dmil;
				txt[1] = mil;	
				txt[2] = ',';
				txt[3] = cent;
				txt[4] = dix;
				txt[5] = un;
				txt[6] = 'V';
				txt[7] = 0;
				LCDK_PrintLine(FONT6X8,7,6,0);		
			}				 
		}
	}
	else 
	{
		LCDK_Cls(0);
		MnuPrtLn(28,17,0,4,0);
		BLOKICH = 1;
		while (SW1 == 1);	
	}	
	BLOKICH = 1;
	RELAY = 0;	
}

void TestDeCh (void)
{
	char oldup;
	uns16 val;
	
	LCDK_Cls(0);
	VPot [3] = 0;
	LoadPot(3);
	ResetRot();
	upplus = 255;
	upmoins = 0;
	oldup = 1;
	BLOKIDC = 0;
	while (SW1 == 1)
	{
		if (oldup != upcntr)
		{
			oldup = upcntr;
			cvhexbcd(upcntr);
			dispval (0,1,3,0,FONT6X8);
			VPot[3] = upcntr;
			LoadPot(3);
			I2Cbufout[0] = 3;
			I2Cbufout[1] = 1;
			I2Cbufout[2] = 1;
			iadr = 6;
			I2Cout(3,3);
			val.high8 = I2Cbufin[1];
			val.low8 = I2Cbufin[2];
			cvhexbcd(val);
			dispval (11,1,4,0,FONT6X8);	
		}	 
	}
	BLOKIDC = 1;	
}

void Contrast (void)
{
	char i,oldup;
	
	LCDK_Cls(0);
	for (i=0;i!=18;i++)
	{
		txt[i] = 'A';
	}
	txt[18] = 0;
	LCDK_PrintLine(FONT6X8,0,1,0);
	LCDK_PrintLine(FONT6X8,0,3,1);
	upcntr = 207;
	MnuPrtLn(42,17,0,7,0);	
	while (SW1 == 1)
	{
		upplus = 255;
		upmoins = 180;
		if (oldup != upcntr)	
		{
			VPot [1] = upcntr;
			LoadPot(1);
			VContrast = upcntr;
			cvhexbcd (upcntr);
			dispval (0,6,3,0,FONT6X8);	
		}
		if (SW2 == 0)
		{
			tempo(10,1); 
			LED2 = 0;
			while (SW2 == 0);
			tempo (10,1);
			LED2 = 1;
			writeprom(0,upcntr);
			tempo(30,1);
			Backup();
		}		
	}
	ResetRot();
	upcntr = 1;		
	MnuMaintInit();
}

void CheckBeep (void)
{
	char mode,oldup;
	bit chmode,olds2,olds3;
	char tp2,tp3,tp4,tp5,tp6;
	
	LCDK_Cls(0);
	mode = 0;
	chmode = 1;
	olds2 = SW2;
	olds3 = SW3;
	MnuPrtLn(34,17,0,6,0);
	MnuPrtLn(36,17,0,7,0);
	I2Cbufout[0] = 7;
	I2Cbufout[1] = 3;
	iadr = 6;
	ResetRot();
	while (SW1 != 0)
	{

		if (mode == 0)	
		{
			if (chmode == 1)
			{
				chmode = 0;
				MnuPrtLn(32,14,0,0,1);
				MnuPrtLn(35,13,0,2,0);
				MnuPrtLn(34,17,0,6,0);
				MnuPrtLn(36,17,0,7,0);
				upcntr = 1;
				oldup = 0;
				tp6 = 1;
			}
			if (upcntr == 0) upcntr = 1;
			if (upcntr > MaxTones) upcntr = MaxTones;
			if (oldup != upcntr) 
			{
				oldup = upcntr;
				cvhexbcd(upcntr);
				dispval (14,2,2,0,FONT6X8);
				tp6 = upcntr;				
			}	 	
		}


		else
		{
			if (chmode == 1)
			{
				chmode = 0;
				LCDK_Cls(0);
				MnuPrtLn(33,17,0,0,0);
				MnuPrtLn(34,17,0,6,0);
				MnuPrtLn(36,17,0,7,0);
				upcntr = 1;
				oldup = 1;
				I2Cbufout[6] = 0;
			}	
			// test
			tp2 = 1;
			tp3 = 90;
			tp4 = 4;
			tp5 = 0;
			tp6 = 0;
			// end test

		}

		if ((SW2 == 0) && (olds2 == 1))
		{
			tempo(500,1);
			//olds2 = 0;
			mode = !mode;
			chmode = 1;
		}
		else olds2 = 1;

		if ((SW3 == 0) && (olds3 == 1))
		{
			//I2Cbufout[6] = 1;
			I2Cbufout[0] = 7;
			I2Cbufout[1] = 3;
			I2Cbufout[2] = tp2;
			I2Cbufout[3] = tp3;
			I2Cbufout[4] = tp4;
			I2Cbufout[5] = tp5;
			I2Cbufout[6] = tp6;
			iadr = 6;
			I2Cout (7,0);
			LED2 = 0;
			tempo(500,1);	
			//olds3 = 0;
			LED2 = 1;
		}
		else olds3 = 1;		
	}
	LED2 = 1;	
	LED3_Off;
}

void TestBal(void)
{
	LCDK_Cls(0);
	MnuPrtLn(71,14,2,3,1);
	while (SW1 != 0)
	{
	}	
}					

