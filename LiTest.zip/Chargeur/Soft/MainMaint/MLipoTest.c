

#include "int18XXX.H"
#pragma unlockISR
#pragma sharedAllocation
#include "LipoTest.h"
/***************************************************************
*              CODE
*****************************************************************/

/** V E C T O R  R E M A P P I N G *******************************************/

#pragma origin ResetVector		// specific PICdem with bootloader@ org 0

void dummy (void)
{
#asm
	call main
#endasm
}
#pragma origin HIntVector

interrupt High_int_server( void)
{
	#pragma fastMode
	High_Int();
}

#pragma origin LIntVector

interrupt Low_Int_Server(void)
{
	int_save_registers
	// real time clock
	if (TMR2IF)
	{
		TMR2IF = 0;
		MSFlg = 1;
		ms = ms + 1;
		loctmr++;
		if (loctmr == 100)
		{
			loctmr = 0;
			ADCModule();
		}	
		if (ms == 1000)
		{
			ms = 0;
			sec++;
			SecFlg=1;
			if (sec == 60)
			{
				sec = 0;

				min++;
				if (min == 60)
				{
					hour++;
					min = 0;
				}
			}	
		}
	// scan keys
	
	// rotary debounce
		if (RotaryDebounce != 0)
		{
			RotaryDebounce--;
		}


// timer1 handling				 
		if (timer1 == 1)
		{
			tempoms--;
			if (tempoms == 0)
			{
				timer1 = 0;
			}
		}
	}
// int on chg for rotary
	if (IOCIF)
	{
		CpyPC = PORTC;
		CpyPB = PORTB;
		HandelRotary();	
		IOCIF = 0;
	}

// int adc
	if (ADIF)		// ADC result		
	{
		ADIF = 0;
		ADRes.high8 = ADRESH;
		ADRes.low8 = ADRESL;
		if (NextANP == 0) INVBAT = ADRes;
		if (NextANP == 1) MESVIN = ADRes;
	}	

// int for USB
	if (USBIF == 1)
	{
	//save  context
		uns16 sv_FSR0 = FSR0;
		uns8 sv_PCLATH = PCLATH;
		uns8 sv_PCLATU = PCLATU;		
		uns8 sv_PRODL = PRODL;
		uns8 sv_PRODH = PRODH;
		uns8 sv_TBLPTRH = TBLPTRH; 
		uns8 sv_TBLPTRL = TBLPTRL;
		uns8 sv_TABLAT = TABLAT;
	// process intrpt
		if (FlgUSB == 1)
		USBDriverService();
		USBIF = 0;
	// restore context
		FSR0 = sv_FSR0;
		PCLATH = sv_PCLATH;
		PCLATU = sv_PCLATU;
		PRODL = sv_PRODL;
		PRODH = sv_PRODH;
		TBLPTRH = sv_TBLPTRH;
		TBLPTRL = sv_TBLPTRL;
		TABLAT = sv_TABLAT;
	}		
	int_restore_registers
}

void High_Int (void)
{
		
// int for I2C
	if (SSPIF == 1)
	{
		uns16  sv_FSR0 = FSR0; 		
		I2CInt();
		FSR0 = sv_FSR0;
	}

}
#include "I2CRtgs.c"	
#include "128x64_LCD.c"
#include "USB_CDC_RTGS.c"
#include "MATH32F.h"
#include "LowLvl.c"
#include "Menus.c"
#include "ModuleUtil.c"
#include "Modules1.c"
#include "Modules2.c"


void MainRtg (bit mms, bit msec)
{
	static char tp;
	static char lgtmr;

	char dat;;;
	Menu();
	
//	if (FlgUSB == 1) CDCTxService();
	if (OpsCode < 10)
	{

	}
	else if (OpsCode < 20)
	{
		if (OpsCode == 11)		//Cal I chrg
		{
			CalV(3);
			OpsCode = 0;
			ResetRot();
			MnuMaintInit();
		}
		if (OpsCode == 12)		//cal I Dechrg
		{
			CalV(4);
			OpsCode = 0;
			ResetRot();
			MnuMaintInit();
		}		
	}
	else if (OpsCode < 30)
	{
		
	}	
	else if (OpsCode < 40)
	{
		if (OpsCode == 30)
		{
			UpdateEEprom();
			OpsCode = 0;
			ResetRot();
			MenuInit();
		}
		if (OpsCode == 31)
		{
			Contrast();
			ResetRot();
			OpsCode = 0;
		}	
		if (OpsCode == 34)
		{
			DispAdc();
			OpsCode = 0;
			ReslSWup = 1;
			MPg.0 = 1;
			ResetRot();
			upcntr = 3;
		}		
		
	}
	else if (OpsCode < 50)
	{
		if (OpsCode == 40)
		{
			TestAlim();
			OpsCode = 0;
			ResetRot();
			MnuMaintInit();
		}
		if (OpsCode == 41)	//test charge
		{
			TestCh();
			OpsCode = 0;
			ResetRot();
			MnuMaintInit();
		}
		if (OpsCode == 42)	//test discharge
		{
			TestDeCh();
			OpsCode = 0;
			ResetRot();
			MnuMaintInit();
		}
		if (OpsCode == 43)	//test balancer
		{
			TestBal();
			OpsCode = 0;
			ResetRot();
			MnuMaintInit();
		} 
		if (OpsCode == 44)	//test beeper
		{
			CheckBeep();
			OpsCode = 0;
			ResetRot();
			MnuMaintInit();
		}
	}	
	else if (OpsCode < 60)
	{
		if (OpsCode == 51)
		{
			CalBal();
			OpsCode = 0;
			ResetRot();
			MnuMaintInit();
		}
		if (OpsCode == 52)	//test charge
		{
			CalV(0);
			OpsCode = 0;
			ResetRot();
			MnuMaintInit();
		}
		if (OpsCode == 53)	//test discharge
		{
			CalV(1);
			OpsCode = 0;
			ResetRot();
			MnuMaintInit();
		}
		if (OpsCode == 54)	//test balancer
		{
			CalV(2);
			OpsCode = 0;
			ResetRot();
			MnuMaintInit();
		} 
	}
	if (msec)
	{

	}	 	

}
void SoftInit (void)
{
	char dat,i,k;
	float32 calc32;
	int calc16;
	VPot [0] = 255;
	LoadPot(0);	
	LCDK_Cls(0);
	tempo(10,1);
	iadr = 0;		//reset adc's with general call
	I2Cbufout[0] = 6;
	I2Cout(1,0);
	i = readprom(0);
	if ((i == 0) || (i == 0xff)) Restore();
	VPot [1] = 205;	//contrast
	LoadPot(1);
	VPot[2] = 0;
	LoadPot(2);
	VPot[3] = 0;
	LoadPot(3);
	BLOKICH = 1;
	BLOKIDC = 1;
	ResetRot();
	//UpdateEEprom();		//emergency only if no menus

	txt[0] = 'C';
	txt[1] = 'o';
	txt[2] = 'n';
	txt[3] = 'x';
	txt[4] = ' ';
	txt[5] = 'F';
	txt[6] = 'l';
	txt[7] = 'a';
	txt[8] = 's';
	txt[9] = 'h';
	txt[10] = ' ';
	txt[11] = ' ';
	txt[12] = '?';	//x = 12
	txt[13] = 0;
	LCDK_PrintLine(FONT6X8,0,0,0);
	I2Cbufin[0] = 0;
	tempo(250,1);
	dat = GetText(4,0,2,0);
	if (txt[0] != 'O')
	{
		txt[0] = 'E';
		txt[1] = 'r';
		txt[2] = 0;
	}
	else GetText (4,0,2,0);
	LCDK_PrintLine(FONT6X8,12,0,0);
	LED = 1;
	tempo (1000,1);
	dat = GetText(0,0,10,0);
	txt[13] = ' ';
	txt[14] = '?';
	txt[15] = 0;
	LCDK_PrintLine(FONT6X8,0,1,0);
	tempo (200,1);

	iadr = 0x3*2;
	I2Cbufout[0] = 2;
	I2Cbufout[1] = 0;
	I2CLenCtrl = 0;	
	I2Cout(2,3);
	LED = 0;
	while (I2C_State !=1);
	LED = 0;
	txt[0] = I2Cbufin[1];
	txt[1] = I2Cbufin[2];
	txt[2] = 0;
	LCDK_PrintLine(FONT6X8,12,1,0);

	dat = GetText(1,0,10,0);
	txt[13] = ' ';
	txt[14] = '?';
	txt[15] = 0;
	LCDK_PrintLine(FONT6X8,0,2,0);
	iadr = 0x02*2;
	I2Cbufout[0] = 2;
	I2Cbufout[1] = 0;	
	I2Cout(2,3);
	while (I2C_State !=1);
	txt[0] = I2Cbufin[1];
	txt[1] = I2Cbufin[2];
	txt[2] = 0;	
	LCDK_PrintLine(FONT6X8,12,2,0);
	
	dat = GetText(2,0,9,0);
	txt[13] = ' ';
	txt[14] = '?';
	txt[15] = 0;
	LCDK_PrintLine(FONT6X8,0,3,0);
	iadr = 0xD0;
	I2Cbufout[0] = 0b00001000;	
	I2Cout(1,3);
	while (I2C_State !=1);
	if (i2cerr == 0x30)
	{
		txt[0] = 'o';
		txt[1] = 'k';
		txt[2] = 0;	
	}
	else
	{
		cvhexbcd (I2Cbufin[0]);
		txt[0] = cent;
		txt[1] = dix;
		txt[2] = un;
		txt[3] = ';';
		txt[4] = i2cerr;
		txt[5] = 0;
	}
	LCDK_PrintLine(FONT6X8,12,3,0);	
	dat = GetText(3,0,9,0);
	txt[13] = ' ';
	txt[14] = '?';
	txt[15] = 0;
	LCDK_PrintLine(FONT6X8,0,4,0);
	iadr = 0xD8;
	I2Cbufout[0] = 0b00000000;	
	I2Cout(1,3);
	while (I2C_State !=1);
	if (i2cerr == 0x30)
	{
		txt[0] = 'o';
		txt[1] = 'k';
		txt[2] = 0;	
	}
	else
	{
		cvhexbcd (I2Cbufin[0]);
		txt[0] = cent;
		txt[1] = dix;
		txt[2] = un;
		txt[3] = ';';
		txt[4] = i2cerr;
		txt[5] = 0;
	}
		
	LCDK_PrintLine(FONT6X8,12,4,0);
	tempo(2000,1);
	MenuInit();
	oldselSW = 1;
	LED2 = 1;
	GetCalibr();
	VPot [1] = VContrast;	//contrast
	LoadPot(1);
	VPot[2] = 0;
	LoadPot(2);
	VPot[3] = 0;
	LoadPot(3);
	iadr = 4;
	I2Cbufout[0] = 3;
	I2Cbufout[1] = 1;
	I2Cbufout[2] = 0;	
	I2Cout(3,0);
	

	
}
		
void HardInit (void)
{
	OSCTUNE = 0x80; //3X PLL ratio mode selected
	OSCCON = 0x70;  //Switch to 16MHz HFINTOSC
	OSCCON2 = 0x10; //Enable PLL, SOSC, PRI OSC drivers turned off
	while(PLLRDY != 1);   //Wait for PLL lock
	ACTCON = 0x90;  //Enable active clock tuning for USB operation
// all ports as digital at reset
	ANSELA = 0;
	ANSELB = 0;
	ANSELC = 0;
	ANSELD = 0;
	ANSELE = 0;
// turn power on all periph, must be indivually turned on
	PMD0 = 0;
	PMD1 = 0;
	ACTMD = 0;
 	TBLPTRU = 0;
//	ADCON1 = 0x0F;		// Default all pins to digital
	WDTCON = 0;
// init intrpt
	IPEN = 1;			// priority intrp as needed
	INTCON = 0;
	INTCON2 = 0;
	INTCON3 = 0;
	PIR1 = 0;
	PIR2 = 0;
	PIE1 = 0;	
	PIE2 = 0;
// set ports
	PORTA = 4; 
	PORTB = 0;
	PORTC = 0;
	PORTD = 0;
	PORTE = 0;
	CSPOT1 = 1;
	CSPOT2 = 1;	
	SW2 = 1;			
	// init ports  
	TRISA = bin(00001011);	// A0-A3 analog, A4-A7 ctl out
	TRISB = bin(10000011);	// 0-1 i2c, 2-3 srl intf, 4-6 ctl out, 7 rotary sw
	TRISC = bin(11111011);	// only buz out
	TRISD = bin(0);			// data for lcd
	TRISE = bin (0);		// ctl for lcd
	RELAY = 0;
// init timers
 	TMR2MD = 0;		// pwr up tmr2, real time clk 1ms
// For fcy = 12 mhz :
// prescal = 16 -> 750khz, pr2 = 75 (-1) -> 10khz, postscale = 10 -> 1khz
	PR2 = 74;
	T2CON = 0b01001110;
	TMR2IP = 0;
//init ram
	clearRAM();
// turn on interrupts
	TMR2IE = 1;
	USBIE = 0;
	GIEH = 1;			// interrupts started
	GIEL = 1;;		
// init lcd
	LCD_Initialize();
	VPot [1] = 207;	//contrast
	LoadPot(1);
	LCDK_Cls(0);
// init I2C
	MSSPMD = 0;
	I2CInit();
//init ADC
	ANSELA = 3;
	ADCON0 = 0b00000001;		// adc on 
	ADCON1 = 0b0;		// fosc/64/right justif
	ADCON2 = 0b10110110;
	ADIP = 0;					// intrpt mode
	ADIE = 1;
// init IOC / rotary
	InitRotary();
	IOCB = 0b10000000;
	IOCC = 0b00000011;
	CpyPC = PORTC;
	CpyPB = PORTB;
	IOCIF = 0;
	IOCIP = 0;
	IOCIE = 1;

}	
void main (void)
{
	uns16 i;
	HardInit();
	SoftInit();
	RELAY = 0;
	LED = 0;
	while (1)
	{
		if (MSFlg == 1)
		{
			OpsMs = 1;
			MSFlg = 0;
		}
		if (SecFlg == 1)
		{
			OpsSec = 1;
			SecFlg = 0;
		}	
		
		MainRtg	(OpsMs,OpsSec);
		OpsMs = 0;
		OpsSec = 0;
	}	
	
}
