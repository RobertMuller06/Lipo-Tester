
/**************************************************************
routines for dislays 128x64 controled by a k01008
************************************************************/
	

#include "128x64_LCD.h"
#include "Font6x8.h"
#include "Font8x8F.h"
//#include "Font5x8.h"
//#include "Graph.h"

//#define FONT5X8 0
#define FONT6X8 1
#define FONT8X8 2
/**********************************************************************
 LCDK_ChkRdy
 Poll the status register until ready status.
 No read or write can take place during busy condition
************************************************************************/
void LCDK_ChkRdy(void)
{
	
	bit LCD_busy,svdi;
	char i;

	LCD_busy = 1;
	svdi = LCDKR_DI;		// used by cmd and data, so need restore di
	LCDK_DI_LOW;		// command mode
	LATD = 0;
	LCDK_RW_READ;		//read
	LCD_TrisDataPort=0xff;	
#if defined LCD_Large
	if ((LCDKR_CS1==0) && (LCDKR_CS2 == 0))	// force one responding chip
	{
		LCDKW_CS1 = 1;	
		LCDKW_CS2 = 0;
	}
#else
	if ((LCDKR_CS1==1) && (LCDKR_CS2 == 1))	// force one responding chip
	{
		LCDKW_CS1 = 0;	
		LCDKW_CS2 = 1;
	}
#endif
// need at least one reponding port otherwise pgm locked
	LCDK_DI_LOW;		// command mode
	while (LCD_busy)
	{
		LCDK_E_LOW;
		nop();
		nop();
		nop();
		nop();
		nop();
		nop();
		nop();
		nop();
		nop();
		nop();
		LCDK_E_HIGH;
		nop();
		nop();
		nop();
		nop();
		nop();
		nop();
		nop();
		nop();
		nop();
		nop();

		LCDK_Status = PORTD;
		LCD_busy = LCDK_Status.7;
	}
	LCDK_RW_WRITE;	// default mode, to avoid out data both sides
	LCD_TrisDataPort = 0;
	nop();
	LCDKW_DI = svdi;	// restore mode

}

/******************************************************************************
 * Function:        void LCDK_CLK
	Generate a low pulse to validate datas
 *****************************************************************************/
void LCDK_CLK(void)
 {
	nop();
	nop();
	nop();
	nop();
	nop();
	nop();
	nop();
	nop();
	nop();
	nop();
	LCDK_E_LOW;
	nop();
	nop();
	nop();
	nop();
	nop();
	nop();
	nop();
	nop();
	nop();
	nop();

}	

/******************************************************************************
 * Function:        void LCD_Initalize(void)
Initialize the lcd
 *****************************************************************************/
void LCD_Initialize(void)
{
	char i;

	LCDK_WriteCMD(0x3F,3);  	// Turn Display 3F = on, 3E off
	tempo (2,1);
	LCDK_WriteCMD(0xC0,3);  	// Start Line at TOP of screen
	LCDK_WriteCMD(0xB8,3); 		// start column 0
}


/******************************************************************************
 * Function:        LCD_GetTrueY(char *data, char y)
 * PreCondition:    None
 * Author:          JCP  20/03/05 09:52
 * Input:           None
 * Output:          None
 * Side Effects:    None
 * Overview:        the LCD Y location is mapped out 0-7 however we need Y from 0-63
 *
 * Note:            None
 *****************************************************************************/
void LCDK_GetTrueY(char *vdata, char y)
{
	char x;												//

	vdata[0]=1;                                          // start @ 1 then 2,4,8,10,20,40,80
 	for(x=0;x<8;x++)		// loop to find which actual Y(0-7) byte
	{           
	   	if(y < 8)			// for the LCD we are talking about
		{                           
	      	vdata[0] <<=y;	// search for the bit position on the true Y
			vdata[1]= x;	// location
			return; 
		}
		y -=8;
 	}
}


/******************************************************************************
 * Function:        LCD_PixelPut(char x, char y)
 * PreCondition:    None
 * Author:          JCP  20/03/05 09:52
 * Input:           None
 * Output:          None
 * Side Effects:    None
 * Overview:        turn on one pixel on the LCD
 *
 * Note:            None
 *****************************************************************************/
void LCDK_PixelPut(char x, char y)
{
	char value[2];
	char i,j;


	if( (x < 128) && (y < 64))
	{	
	// protect system ram from user
		LCDK_GetTrueY(&value[0],y);
		i = LCDK_ReadData(x,value[1]);
		i |= value[0];
		LCDK_WriteChar(x,value[1],(i));
	}
}

/******************************************************************************
 * Function:        LCD_PixelClr(char x, char y)
 * PreCondition:    None
 * Author:          JCP  20/03/05 09:52
 * Input:           None
 * Output:          None
 * Side Effects:    None
 * Overview:        turn off one pixel on the LCD
 *
 * Note:            None
 *****************************************************************************/
/*
void LCDK_PixelClr(char x, char y)
{
 	char value[2];
	char i;

	
	if( (x < 128) && (y < 64) )
	{					// protect system ram from user
		LCDK_GetTrueY(&value[0],y);
		LCDK_ReadData(x,&value[1]);	//dummy read
		i=LCDK_ReadData(x,value[1]);
		i = i & (value[0]);
		LCDK_WriteChar(x,value[1],(i));
	}
	
}
*/
/******************************************************************************
 * Function:        void LCD_WriteCMD(char Command, char DispSide)
 Write command byte to lcd.
 param 1= command byte
 param 2= chip used (0=right side, 1=left side, 3=bothe sides
 *****************************************************************************/
void LCDK_WriteCMD(char Command, char DispSide) {

	char stateCS;
	
	stateCS = PORTC & 0b00000101;   
	switch (DispSide) {
		
		case 0:	{LCDK_CS1_ACTV; break;}
		case 1: {LCDK_CS2_ACTV;break;} 
		case 3 :{LCDK_CS1_ACTV; LCDK_CS2_ACTV;break; }
	}
	LCDK_ChkRdy();	
	LCDK_DI_LOW;						// RS or DI LOW as Commmand
	LCD_DataPort = Command;			// Put the command on the DISP Port
	LCDK_CLK();
	LATC |= stateCS;
}	


/******************************************************************************
 * Function:        void LCD_GotoXY(char x, char y)
 Position address to x and y
 *****************************************************************************/
void LCDK_GotoXY(char x, char y) {

	if( (x < 128) && (y < 8) ) 
	{		// protect LCD from outboud ram access
		y |=0xB8;											// Set Page Register

		if(x > 0x3f)
		{  							// right side of screen ?
			LCDK_CS2_ACTV;
			LCDK_CS1_INACT;
	  	}  
		else
		{	// left side of screen
    		LCDK_CS1_ACTV ; 
    		LCDK_CS2_INACT ;	
 		}   
		x &= 0x3F;	// Mask the used bits and prevent x from being more than 64                                                //
		x |=0x40;	// Set Address Register Bit
		// direct write to cmd register, not using WriteCmd function
		LCDK_ChkRdy();
		LCDK_DI_LOW;
		LCD_DataPort= x;						// Write Address Register
		LCDK_CLK();
		LCDK_ChkRdy();	
	  	LCD_DataPort=y;   					// Write Page Register
		LCDK_CLK();

	}
	
}	



/******************************************************************************
 * Function:        LCDK_WriteChar(char x, char y, char dispdata)
put one byte at x,y position
 *****************************************************************************/
void LCDK_WriteChar(char x, char y, char dispdata)
{

	LCDK_GotoXY(x,y);
	LCDK_ChkRdy();		
	LCDK_DI_HIGH;
	LCDK_E_HIGH;
		// set display for data mode
	LCD_DataPort = dispdata;						// pixel data to put on screen
	LCDK_CLK();

}

/******************************************************************************
 * Function:        LCDK_WriteNextChar( char dispdata)
put one byte at next cursor position, faster without cursor positionnig
 *****************************************************************************/

void LCDK_WriteNextChar( char dispdata)
{

	LCDK_ChkRdy();			
	LCDK_DI_HIGH;
						// set display for data mode
	LCDK_E_HIGH;
	LCD_DataPort = dispdata;						// pixel data to put on screen
	LCDK_CLK();
}


/******************************************************************************
 * Function:        char LCD_ReadData(char x, char y)
 * Overview:        Read one byte of data on the LCD. 
 * Input:           Position x (1 of 128) and y (1 of 8 lines) on display.
 * Output:          data in position x,y
 *
 *****************************************************************************/
char LCDK_ReadData(char x, char y) {
	char dati;


	LCDK_GotoXY(x,y);
	LCDK_CLK();
	LCDK_CLK();
	LCDK_CLK();
	LCDK_DI_HIGH;							// set display for data mode
	LATD = 0;
	LCD_TrisDataPort = 0xFF;   // Display Data port as inputs
// first a dummy read
	LCDK_RW_READ;

	nop();
	nop();
	nop();
	nop();
	nop();
	nop();
	nop();
	nop();
	nop();
	nop();
	LCDK_E_HIGH;
	nop();
	nop();
	nop();
	nop();
	nop();
	nop();
	nop();
	nop();
	nop();
	nop();
	nop();
	nop();
	nop();
	nop();
	nop();

// effective read	
	LCDK_ChkRdy();
// now efefctive read
	LATD = 0;
	nop();
	LCD_TrisDataPort = 0xFF;   // Display Data port as inputs
	LCDK_RW_READ;
	nop();
	nop();	
	nop();
	nop();
	nop();
	nop();
	LCDK_E_HIGH;
	nop();
	nop();	
	nop();
	nop();
	nop();
	nop();
	nop();
	nop();
	dati = PORTD;
	nop();
	nop();
	nop();
	nop();	
	LCDK_E_LOW;
	LCDK_RW_WRITE;
	LCD_TrisDataPort = 0x00; // Port as output
	LCDK_CLK();
	return (dati);
}	

/******************************************************************************
 * Function:        void LCD_Cls(char fill)
Basically a clear screen (when fill has value 0).
Fills the display with the character received as an input
 *****************************************************************************/
void LCDK_Cls(char vfill)
{
	char x,y;
	
 	for (y=0;y<8;y++)
	{
		LCDK_WriteChar(0,y,vfill);	
		for (x=1;x!=64;x++)
		{
			LCDK_WriteNextChar(vfill);	
		}
		LCDK_WriteChar(64,y,vfill);	
		for (x=1;x!=64;x++)
		{
			LCDK_WriteNextChar(vfill);	
		}
	}	
}
/*
void LCDK_ClrTxtLine(char yline)
{ 
	char i,x;

	LCDK_WriteChar(0,yline,0);	
	for (i=1;i!=64;i++)
	{
		LCDK_WriteNextChar(0);	
	}
	LCDK_WriteChar(64,yline,0);	
	for (x=1;x!=64;x++)
	{
		LCDK_WriteNextChar(0);	
	}	
}	
*/
 /*****************************************************************************
  Name: 			LCD_PrintLine

  Description:      To Display a string in one of the 8 rows of the display.
  Usage:			LCD_PrintLine (param 1,param 2,param 3)

					text in a table txt[], string 0 terminated
					param 1: font table used (0,1,2 ..) 
					param 2: x location in character spaces. 
					param 3: y location in character spaces.  all fonts Y = 0 - 7
					param 4: if 1 display is in reverse video

*******************************************************************************/
void LCDK_PrintLine(char pfont_tbl,char location_x, char LCDLine,bit reverse)
{
	bit chgchip;
	char x,y,z,last,loop,pixel_step,x_size,max_x;
	char font_char,font_size;
	char i,idx;
	char car_pixel[16];	// load char pixels in ram to use pointers 
	uns16 car_loc;

// if Progm memory too short : 
//	if (pfont_tbl == 0) pfont_tbl = 1; // tbl 5x8 not to be used 
// also comment the include of font 5x8
	idx = 0; 
	i = txt[0]; 
	switch (pfont_tbl)
	{
		case 0:
		{
			font_size = 5;		//max 18 char per line
			break;	
		}
		case 1:
		{
			font_size = 6;
			break;
		}
		case 2:
		{
			font_size = 8;		// max 14 char per line
			break;
		}			
	}
	x = font_size + 1;
	pixel_step = location_x * x;	
	chgchip = 0;
	if (pixel_step>63) chgchip = 1;							// pixel spaces we need to increase by   	                                     //
	while (i != 0)    // until it finds NULL terminator string
	{
		i = i-32;
		car_loc = (uns16)font_size * (uns16)i;
		switch (pfont_tbl)
		{
			case 0:
			{		
				for (x=0;x!=font_size;x++)
				{
					y = FONT6x8[car_loc];
					if (!reverse)
					{
					car_pixel[x] = y;
					}
					else car_pixel[x] = y^0xff;
					car_loc++;
				}
				break;	
			}	
			case 1:
			{
				for (x=0;x!=font_size;x++)
				{
					y = FONT6x8[car_loc];
					if (!reverse)
					car_pixel[x] = y;
					else car_pixel[x] = y^0xff;
					car_loc++;
				}
				break;	
			}	
			case 2:
			{
				for (x=0;x!=font_size;x++)
				{
					y = FONT8x8F[car_loc];
					if (!reverse)
					car_pixel[x] = y;
					else car_pixel[x] = y^0xff;
					car_loc++;
				}
				break;	
			}	
		}
		font_char = car_pixel[0];						// take the x location of font
		LCDK_WriteChar(pixel_step,LCDLine,font_char);
		pixel_step++;
		if (pixel_step <128)
		{
			if ((pixel_step > 63) && (chgchip == 0))
			{
				LCDK_GotoXY(pixel_step,LCDLine);
				chgchip = 1;
			}			
			for(x=1;x < font_size;x++ )
			{
				font_char = car_pixel[x];						// take the x location of font
				LCDK_WriteNextChar(font_char);
				pixel_step++;
				if (pixel_step <128)
				{
					if ((pixel_step > 63) && (chgchip == 0))
					{
						LCDK_GotoXY(pixel_step,LCDLine);
						chgchip = 1;
					}				
 				}	
 			}
 		}				
 		pixel_step ++;
 		if (pixel_step < 128)
 		{
			if ((pixel_step > 63) && (chgchip == 0))
			{
				LCDK_GotoXY(pixel_step,LCDLine);
				chgchip = 1;
			}
		}	
		if (!reverse)			
 		LCDK_WriteNextChar(0);
 		else LCDK_WriteNextChar(0xff);
		idx++ ;
		i = txt[idx];
		
	}       
}

 /*****************************************************************************
  Name: 			LCD_Draw square

  Description:      To Display a square.
  Usage:			LCDK_DrawSqr (param1,param2,param3,param4,param5)

					param 1: char, pos x of left corner in pixels
					param 2: char, pos y of top corner in pixels 
					param 3: char, len in pixels
					param 4: char, high in pixels
					param 5: square is filled (1) or not (0) 
					
*******************************************************************************/

void LCDK_DrawSqr(char x,char y, char wide, char high,bit filled)
{
	char i,j;

	
	// first validate values. only inside screen
	if ((x < 128) && (y< 64))
	{
		i = x+wide;
		if (i > 127)
		{
			wide = 127 - x;
		}	
		j = y+high;
		if (j > 63)
		{
			high = 63 - y;
		}
		if (!filled)
		{
			for (j=y; j != y+high; j++)
			{
				LCDK_PixelPut(x,j);
				LCDK_PixelPut(x+wide,j);
			}
			for (i = x; i != x+wide; i++)
			{
				LCDK_PixelPut(i,y);
				LCDK_PixelPut(i,y+high);
			}				 
			LCDK_PixelPut(x+wide,y+high);
		}
		
		else
		{
			for (i = x; i != x+wide; i++) 
			{
				for (j=y; j != y+high; j++)
				{
					LCDK_PixelPut(i,j);	
				}
			}
		}			
	}	
}


 /*****************************************************************************
  Name: 			LCD_Draw circle

  Description:      To Display a circle or elipse
  Usage:			LCDK_DrawCircle (param1,param2,param3,param4)

					param 1: int, pos x of center in pixels
					param 2: int, pos y of center in pixels 
					param 3: int, radius x axis in pixels
					param 4: int, radius y axis in pixel, 0 for circle
					
*******************************************************************************/
/*
#define DISABLE_ROUNDING
#include "math24f.h"
#include "math24lb.h"
void LCDK_DrawCircle(int x,int y, int radiusx, int radiusy)
{
	float24 xf,yf,af,calcangl,rxf,ryf;
	int16 angle;
	int xx,yy;

	rxf = radiusx;
	if (radiusy == 0) ryf = rxf;
	else ryf = radiusy;
	for (angle = 0; angle != 628; angle ++)
	{
		af = angle;
		calcangl = af / 100;  // 0 to 2*pi
		xf = cos(calcangl);
		xf = xf * rxf;
		xx = xf;
		yf = sin(calcangl);
		yf = yf * ryf;
		yy = yf;
		LCDK_PixelPut(x+xx,y-yy);
		FpFlags = 0;
	}	
}
*/


void LCDK_DrawLine(int xstart, int ystart, int xend, int yend)
{
	uns16 calc,calc2;
	uns24 lgrow;
	bit directionx,directiony;
	char grow;
	char ystep,xstep;
		
	if ((xstart >=0) && (ystart >= 0) && (xend >= 0) && (yend >= 0))
	{

		if (ystart > yend)
		{
			grow = ystart - yend;
			directiony = 0;
		}
		else 
		{
			grow = yend - ystart;
			directiony = 1;
		}		
		lgrow = (uns24)grow * 204;
		if (xend > xstart)
		{
			calc = (uns16)xend - xstart;
			directionx = 0;
		}	
		else
		{
			calc = (uns16)xstart - xend;
			directionx = 1;
		}


		if (calc == 0)	// case simple vertical line
		{
			
			if (directiony == 1)
			{
				yend++;
				for (ystep = ystart; ystep != yend; ystep++)
				{
					LCDK_PixelPut(xstart,ystep);
				}		  
			}
			else
			{
				ystart++;
				for (ystep = yend; ystep != ystart; ystep++)
				{
					LCDK_PixelPut(xstart,ystep);
				}	
			}		
		}	 	
		else	// case of general line
		{
			if (directionx != 0)
			{
//				LCDK_PixelPut(xstart,ystart);
				xstep = xstart;
				xstart = xend;
				xend = xstep;
				ystep = ystart;
				ystart = yend;
				yend = ystep;
				directiony = !directiony;
			}
			else
			{
//				LCDK_PixelPut(xend,yend);
			}		
				
			lgrow = lgrow / calc;
				xend++;  // both ends included
				for (xstep = xstart; xstep != xend;xstep ++)
				{
					grow = xstep - xstart;
					calc = lgrow * grow;
					calc = calc / 200;
					ystep = calc.low8 ;
					if (directiony == 1)	ystep += ystart;
					else ystep = ystart - ystep;
					LCDK_PixelPut(xstep,ystep);
				}		
		}		
		
	}
}
/*
char Logo(uns16 adrs,char ofs)
{
	if (ofs == 0)
	{
		TxBuf[0] = 15;
		TxBuf[1] = adrs.high8;
		TxBuf[2] = adrs.low8;
		TxData();
		RcvData(15);
		return RxBuf[1];
	}
	else
	{
		ofs++;
		return RxBuf[ofs];
	}	
}	
*/
/******************************************************************************
 * Function:        Display Graphic Full Screen
Picture is in a constant table of 1024 char

*****************************************************************************/
//void LCDK_FullScreenGraph(size2 char *Pic)
/*

void LCDK_FullScreenGraph(void)
{
	char x,y,DChar;
	uns16 py,c,cx,cy;
//	size2 char *Logo;
	
//	Pic = Logo;
 	for (y=0;y<8;y++)
	{
		cy=y;
		py=cy;
		DChar = Logo(cy,0);
		LCDK_WriteChar(0,y,DChar);
		for (x=1;x!=64;x++)
		{
			cx = x;
			py=cx*8;
			py+=cy;
			DChar = Logo(py,0);
			LCDK_WriteNextChar(DChar);
		}
		py = cy;
		py += 512;
		DChar = Logo(py,0);
		LCDK_WriteChar(64,y,DChar);	
		for (x=1;x!=64;x++)
		{
			cx = x;
			py=cx*8;
			py += cy;
			py += 512;
			DChar = Logo(py,0);
			LCDK_WriteNextChar(DChar);	
		}
	}	
}
*/


		