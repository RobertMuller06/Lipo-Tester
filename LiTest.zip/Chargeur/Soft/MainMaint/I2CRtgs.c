/* Master/Slave  I2C routings
*/
#define I2CMastInt

#include "I2CRtgs.h"

/*****************************************************
			I2C Interrupts Handlers
*******************************************************/

void I2CInt (void)
{

	switch (I2C_State)
	{
		case 0:	// re-init i2c hrwr
		{
			SSPEN = 0;
			SSP1CON1 = 0b00001000;	// master mode
			SSP1STAT = 0b10000000;
			SSP1CON2 = 0;		// 0
			SSP1ADD = I2C_BAUD;	//I2C_SPEED;		//30;		// 400kbds, clock = 48M
			SSPEN = 1;
			I2C_State = 1;
			break;
		}		
		case 1:	// no action
		{
			break;
		}	
		case 2:			//  end SEN
		{
			SSP1BUF = iadr & 0xFE;	//tx address
			I2C_State = 3;
			I2Cidx = 0;
			break;
		}
		case 3:		// send data loop	
		{	
			while (RW_ == 1);
			if (ACKSTAT == 1)
			{
				if (I2Cidx == 0)	//Nack after address is usually a busy flag
				{
					i2cerr = 0x31;
					I2C_State = 10;	//abort tx and generate stop
				}
				else i2cerr = 32;
			}
			SSP1BUF = I2Cbufout[I2Cidx];
			I2Cidx++;	
			I2CcntO--;	
			if (I2CcntO == 0)
			{
				I2C_State = 4;
			}
			if (i2cerr == 0x32)
			{
				 I2C_State = 0;
			}	  						
			break;
		}	
		case 4:			// send stop or re-start
		{
			if (wr_plus_rd ==0)
			{
				I2C_State = 5;
				PEN = 1;
			}
			else
			{
				I2C_State = 6;
				RSEN = 1;
			}	
			break;
		}
		case 5:			// stop completed
		{
			I2C_State = 1;
			break;
		}
		case 6:			// end re-start, send iadr for read
		{
			SSP1BUF = iadr | 1;
			I2C_State = 7;
			I2Cidx = 0;
			break;
		}
		case 7:			// get ack for adrs
		{
			if (ACKSTAT == 1)
			{
				i2cerr = 0x33;
			}				
			RCEN = 1;
			I2C_State = 8;
			if (i2cerr == 0x33) I2C_State = 0; 	
			break;
		}	
		case 8:			// read loop
		{
			I2Cbufin[I2Cidx] = SSP1BUF;
			if (I2CLenCtrl)
			{
				I2CcntI = I2Cbufin[0];
				I2CLenCtrl = 0;
			}	
			I2CcntI--;
			I2Cidx++;
			I2C_State = 9;
			if (I2CcntI == 0)
			{
				ACKDT = 1;
				I2C_State = 10;
			}
			else ACKDT = 0;
			ACKEN = 1;
			break;
		}
		case 9:		// data acked, next byte
		{
			RCEN = 1;	
			I2C_State = 8;
			break;
		}	
		case 10:	// data rcvd complete and last byte nacked, send stop
		{
			I2C_State = 11;
			PEN = 1;
			break;
		}
		case 11:	// stop completed, rdy for next transfer
		{
			RCEN = 0;
			I2C_State = 1;
			break;
		}
//		default:
//		{
//			i2cerr = 0x30;
//			SSPEN = 0;
//			nop();
//			nop();
//			nop();
//			nop();
//			SSPEN = 1;
//			I2C_State = 1;
//			break;
//		}			
	}					
	SSPIF = 0;
	
}


/******************************************************
			I2C INIT Routines
*******************************************************/
void I2CInit (void)
{

	SSP1CON1 = 0b00001000;	// master mode
	SSP1STAT = 0b10000000;
	SSP1CON2 = 0;		// 0
	SSP1ADD = I2C_BAUD;		//30;//I2C_SPEED//400kbds
	SSPIP = 1;		//high priority
	SSPIF = 0;
	SSPIE = 1;
	SSPEN = 1;
	I2C_State = 1;		// cfgred and ready

}	

bit I2CRdy (void)
{

	if (I2C_State != 1) return 0;
	return 1;	
}	

void I2Cout(char nbrout, char nbin)
{

	if ((nbrout != 0) && (nbin != 0))
	{
		wr_plus_rd = 1;
	}
	else
	{
		wr_plus_rd = 0;
	}
	i2cerr = 0x30;
	I2CcntO = nbrout;
	I2CcntI = nbin;
	I2C_State = 2;
	SEN = 1;			// generating start signal start int mechanism	
	while (I2CRdy() != 1);
	tempo (20,1);
}	


/********* end I2C Slave management ***********/

/* ********** ACCESS External Flash ************ */



/*************************************************
External flash memory read
Input : uns16 for address of fisrt char, for 26lc16 only 1 address byte
nbrdata : number of char to read, max is capacity of I2Cbufin or 64, 
********************************************/ 

char readflash (uns16 rfaddr, char nbrdata)
{
	if (nbrdata > I2CbuffersizeIn) return 'O';
	while (I2C_State !=1);	// cannot change I2Cbufout if I2C busy
	iadr = 0xA0;
	I2Cbufout[0] = rfaddr.high8;		// necessary for type > 16k
	I2Cbufout[1] = rfaddr.low8;
	I2Cout(2,nbrdata);
	while (I2C_State !=1);	// cannot free I2C buffers before completion 
	if (i2cerr == 0x30)	return 0;
	else return i2cerr;
}


/************************************************
		WRITE TO I2C FLASH
- data buffer must be pointed to by *dptr (global var)
 - nbrdata does not include address 
 - so nbrdata must be 2 characters less than I2Cbufout capacity
 	--> for 32 bytes write, buffer must be 32 (in I2CRtgs.h)
**************************************************/

void writeflash ( uns16 faddr, char nbrdata)
{
	char i,j,dati,tmp;
	uns16 i16,j16;
	
	iadr = 0xA0;
	I2Cbufout[0] = faddr.high8;
	I2Cbufout[1] = faddr.low8;
	for (i=0;i!=nbrdata;i++)
	{
		j=i+2;
		dati = flbuf[i];
		I2Cbufout[j] = dati;
	}
	nbrdata += 2;
	I2Cout (nbrdata,0);	
	tmp = (nbrdata / 8); // 10 ms write time per block of 8 bytes
	tmp *= 10;
	tempo (tmp,1);
}