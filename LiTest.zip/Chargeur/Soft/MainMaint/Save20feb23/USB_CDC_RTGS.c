
#include "USB_CDC.h"
#include "DescrTblConst.h"

/****************************************************
*        UTILITIES
*****************************************************/
void disable_endpt (void)
{
UEP1 = 0;
UEP2 = 0;
UEP3 = 0;
UEP4 = 0;
UEP5 = 0;
UEP6 = 0;
UEP7 = 0;
UEP8 = 0;
UEP9 = 0;
UEP10 = 0;
UEP11 = 0;
UEP12 = 0;
UEP13 = 0;
UEP14 = 0;
UEP15 = 0;
}

void ClearArray(char *startAdr,char count)
{
	while (count)
	{
		*startAdr = 0;
		count--;
		startAdr++;
	}
}

/*****************************************************************
*        U S B  ROUTINES 
*************************************************************** */

void USB_Hdwr_Init (void)
{
#if ((defined _18F25K50) || (defined _18F45K50))
	USBMD = 0;
#endif
	UCFG = UCFG_VAL;               
	usb_device_state = DETACHED_STATE;    
   	usb_stat = 0;  
   	usb_active_cfg = 0;
	UEIR = 0;			// all errors cleared
	UEIE = 0xFF;		// all errors unmasked
	UIR = 0;			// all usb intrpt cleared
	UIE = 0;			// all interrupt masked, unmasked later
	USBIP = 0;			// high priority (if used)
}


/* >>>>>>>>>>>>>>> CDC Part >>>>>>>>>>>>>>>>>>>>>>>>>>  */
void USBCheckCDCRequest(void)
{
    if((SetupPkt.bmRequestType & 0b00011111) != RCPT_INTF) return;
    if((SetupPkt.bmRequestType & 0b01100000) != CLASS) return;
    if((SetupPkt.wIndex.low8 != CDC_COMM_INTF_ID)&&
       (SetupPkt.wIndex.low8 != CDC_DATA_INTF_ID)) return;
    switch(SetupPkt.bRequest)
    {
        case SEND_ENCAPSULATED_COMMAND:
            ctrl_trf_session_owner = MUID_CDC;
            pSrc_bRam = (char*) &dummy_encapsulated_cmd_response[0];
            usb_stat.ctrl_trf_mem = _RAM;
            wCount = dummy_length;
            break;
        case GET_ENCAPSULATED_RESPONSE:
            ctrl_trf_session_owner = MUID_CDC;
            // Populate dummy_encapsulated_cmd_response first.
            pDst_bRam = (char*)&dummy_encapsulated_cmd_response[0];
            break;
        case SET_COMM_FEATURE:                  // Optional
            break;
        case GET_COMM_FEATURE:                  // Optional
            break;
        case CLEAR_COMM_FEATURE:                // Optional
            break;
        case SET_LINE_CODING:
            ctrl_trf_session_owner = MUID_CDC;
            pDst_bRam = (char*)&line_coding;    // Set destination
            break;
        case GET_LINE_CODING:
            ctrl_trf_session_owner = MUID_CDC;
            pSrc_bRam = (char*)&line_coding;    // Set source
            usb_stat.ctrl_trf_mem = _RAM;       // Set memory type
            wCount = LINE_CODING_LENGTH;   // Set data count
            break;
        case SET_CONTROL_LINE_STATE:
            ctrl_trf_session_owner = MUID_CDC;
            control_signal_bitmap.DTE_PRESENT = (SetupPkt.wValue.low8);
            break;
        case SEND_BREAK:                        // Optional
            break;
        default:
            break;
    }//end switch(SetupPkt.bRequest)

}//end USBCheckCDCRequest

/** U S E R  A P I ***********************************************************/

void CDCInitEP(void)
{
    //Abstract line coding information
    line_coding.dwDTERateH = 0;		// free compiler compliance
    line_coding.dwDTERate = 19200;	// baud rate 19200		
    line_coding.bCharFormat = 0x00;		// 1 stop bit
    line_coding.bParityType = 0x00;		// None
    line_coding.bDataBits = 0x08;		// 5,6,7,8, or 16

    cdc_trf_state = CDC_TX_READY;
    cdc_rx_len = 0;
    
    CDC_COMM_UEP = EP_IN|HSHK_EN;               // Enable 1 Comm pipe
    CDC_DATA_UEP = EP_OUT_IN|HSHK_EN;           // Enable 2 data pipes

    CDC_INT_BD_IN.USB_ADR = &cdc_notice[0];     // Set buffer address
    CDC_INT_BD_IN.Stat = _UCPU|_DAT1;     // Set status

    CDC_BULK_BD_OUT.Cnt = sizeof(cdc_data_rx);  // Set buffer size
    CDC_BULK_BD_OUT.USB_ADR = &cdc_data_rx[0];  // Set buffer address
    CDC_BULK_BD_OUT.Stat = _USIE|_DAT0|_DTSEN;// Set status

    CDC_BULK_BD_IN.USB_ADR = &cdc_data_tx[0];   // Set buffer size
    CDC_BULK_BD_IN.Stat = _UCPU|_DAT1;    // Set buffer address

}

// Get up to len chararcters, returns actual number received.
char getsUSBUSART(char * buffer, char len)
{
	char dati;
    cdc_rx_len = 0;
    if(!CDC_BULK_BD_OUT.Stat.UOWN)
    {
		if(len > CDC_BULK_BD_OUT.Cnt)
            len = CDC_BULK_BD_OUT.Cnt;
		for(cdc_rx_len = 0; cdc_rx_len < len; cdc_rx_len++)
		{
			dati = cdc_data_rx[cdc_rx_len];
        	*buffer = dati;
			buffer ++;
		}
    CDC_BULK_BD_OUT.Cnt = sizeof(cdc_data_rx);
    CDC_BULK_BD_OUT.Stat &= _DTSMASK;          /* Save only DTS bit */    
    CDC_BULK_BD_OUT.Stat.DTS = !CDC_BULK_BD_OUT.Stat.DTS; /* Toggle DTS bit    */ 
    CDC_BULK_BD_OUT.Stat |= _USIE|_DTSEN;      /* Turn ownership to SIE */
    }
    return cdc_rx_len;
}
/*
// Prepare out to host a text string null terminated, limited to 255 charachers
void putsUSBUSART(char *data)
{
    char len;
    if(cdc_trf_state != CDC_TX_READY) return;
    len = 0;
    do
    {
        len++;
        if(len == 255) break;       // Break loop once max len is reached.
		data++;
    }while(*data);
	data -= len;
    pCDCSrc = data; 
    cdc_tx_len = len+1;		// one more to include the trailing null
    cdc_mem_type = _RAM;
    cdc_trf_state = CDC_TX_BUSY;
}
*/
// Preapre output of len bytes to the host. 
void putBinUSBUSART(char *indx, char len)
{
    if(cdc_trf_state != CDC_TX_READY) return;
    pCDCSrc = indx;
    cdc_tx_len = len;
    cdc_mem_type = _RAM;
    cdc_trf_state = CDC_TX_BUSY;    
}

// Output prepared buffer to host, must be polled by main application
void CDCTxService(void)
{
    char char_to_send, i;
    
    if(CDC_BULK_BD_IN.Stat.UOWN) return;
    if(cdc_trf_state == CDC_TX_COMPLETING)
        cdc_trf_state = CDC_TX_READY;
    if(cdc_trf_state == CDC_TX_READY) return;
    if(cdc_trf_state == CDC_TX_BUSY_ZLP)
    {
        CDC_BULK_BD_IN.Cnt = 0;
        cdc_trf_state = CDC_TX_COMPLETING;
    }
    else if(cdc_trf_state == CDC_TX_BUSY)
    {
    	if(cdc_tx_len > sizeof(cdc_data_tx))
    	    char_to_send = sizeof(cdc_data_tx);
    	else
    	    char_to_send = cdc_tx_len;
        CDC_BULK_BD_IN.Cnt = char_to_send;
    	cdc_tx_len = cdc_tx_len - char_to_send;
    	        
        pCDCDst = &cdc_data_tx[0]; // Set destination pointer
// RAM transmit mode only.
        i = char_to_send;
            while(char_to_send)
            {	locali = *pCDCSrc ;
                *pCDCDst = locali ;
                pCDCDst++;
                pCDCSrc++;
                char_to_send--;
            }

        if(cdc_tx_len == 0)
        {
            if(CDC_BULK_BD_IN.Cnt == sizeof(cdc_data_tx))
                cdc_trf_state = CDC_TX_BUSY_ZLP;
            else
                cdc_trf_state = CDC_TX_COMPLETING;
        }
            
    }
	CDC_BULK_BD_IN.Stat &= _DTSMASK;          /* Save only DTS bit */    
    CDC_BULK_BD_IN.Stat.DTS = !CDC_BULK_BD_IN.Stat.DTS; /* Toggle DTS bit    */ 
    CDC_BULK_BD_IN.Stat |= _USIE|_DTSEN;      /* Turn ownership to SIE */
}

/********************************************************************/
/********************************************************************/

/* ====================== >>>>>>>>>>>>>>>>>>>>> CHAP9   */

void USBStdGetDscHandler(void)
{
    if(SetupPkt.bmRequestType == 0x80)
    {
        switch(SetupPkt.wValue.high8)
        {
            case DSC_DEV:  //01
                ctrl_trf_session_owner = MUID_USB9;
       			pSrc_bRom = ofs_device_dsc;
	            wCount = tbl[pSrc_bRom]; 
                break;
            case DSC_CFG:   //02
                ctrl_trf_session_owner = MUID_USB9;
				pSrc_bRom = IdxCfg(SetupPkt.wValue.low8);
                wCount.low8 = (char) tbl[pSrc_bRom + 2];   	// Set data count 16b
				wCount.high8 = (char) tbl[pSrc_bRom + 3]; 
                break;
            case DSC_STR:   //03
                ctrl_trf_session_owner = MUID_USB9;
				pSrc_bRom = IdxStr (SetupPkt.wValue.low8);			
				wCount = tbl[pSrc_bRom];
                break;
        }
        usb_stat.ctrl_trf_mem = _ROM;                       // Set memory type
    }
}

void USBStdSetCfgHandler(void)
{
    ctrl_trf_session_owner = MUID_USB9;
    disable_endpt();          // See usbdrv.h
    ClearArray(&usb_alt_intf[0],MAX_NUM_INT);
    usb_active_cfg = SetupPkt.wValue.low8;	//bCfgValue;
    if(SetupPkt.wValue.low8 == 0)
        usb_device_state = ADDRESS_STATE;
    else
    {
        usb_device_state = CONFIGURED_STATE;
        /* Modifiable Section */
        CDCInitEP();
        /* End modifiable section */
    }
}


void USBStdGetStatusHandler(void)
{
    CtrlTrfData.0 = 0;                         // Initialize content
    CtrlTrfData.1 = 0;
        
    switch(SetupPkt.bmRequestType & 0b01011111)	//Recipient
    {
        case RCPT_DEV:
            ctrl_trf_session_owner = MUID_USB9;
#ifdef USB_PLUGGED_CHECK
            if(self_power == 1)  
#endif                   
                CtrlTrfData.0=1;    // Set bit0
            if(usb_stat.RemoteWakeup == 1)          
                CtrlTrfData.1=1;     // Set bit1
            break;
        case RCPT_INTF:
            ctrl_trf_session_owner = MUID_USB9;     // No data to update
            break;
        case RCPT_EP:
            ctrl_trf_session_owner = MUID_USB9;
 			calc1 = SetupPkt.wIndex.low8 & 0xf;
			calc1 = calc1 * 8;
			tp =SetupPkt.wIndex.low8;
			if (tp.7 != 0)
				{calc1 = calc1 + 4;}
            pDst_bRam = (char*)&ep0Bo+calc1;
            if(*pDst_bRam & _BSTALL)    // Use _BSTALL as a bit mask
                CtrlTrfData.0=0x01;// Set bit0
            break;
    }
    
    if(ctrl_trf_session_owner == MUID_USB9)
    {
        pSrc_bRam = &CtrlTrfData;		// Set Source
        usb_stat.ctrl_trf_mem = _RAM;	// Set memory type
        wCount.high8 = 2;				// Set data count
    }
}

void USBStdFeatureReqHandler(void)
{
    if((SetupPkt.wValue.low8 == DEVICE_REMOTE_WAKEUP)&&
       ((SetupPkt.bmRequestType & 0x1f) == RCPT_DEV))
    {
        ctrl_trf_session_owner = MUID_USB9;
        if(SetupPkt.wValue.low8 == SET_FEATURE)
            usb_stat.RemoteWakeup = 1;
        else
            usb_stat.RemoteWakeup = 0;
    }
    
    if((SetupPkt.wValue.low8 == ENDPOINT_HALT)&&
       ((SetupPkt.bmRequestType & 0x1f) == RCPT_EP)&&
       ((SetupPkt.wIndex.low8 & 0x0f) != 0))
    {
        ctrl_trf_session_owner = MUID_USB9;
        /* Must do address calculation here */
			calc1 = SetupPkt.wIndex.low8 & 0xf;	// 16 Endpoints max
			calc1 = calc1 * 8;
			tp =SetupPkt.wIndex.low8; 
			if (tp.7 != 0)
				{calc1 = calc1 + 4;}
        pDst_bRam = (char*)&ep0Bo+calc1;
        
        if(SetupPkt.bRequest == SET_FEATURE)
            *pDst_bRam = _USIE|_BSTALL;
        else
        {
            if((SetupPkt.wValue.high8 & 0x80) != 0) // IN
                *pDst_bRam = _UCPU;
            else
                *pDst_bRam = _USIE|_DAT0|_DTSEN;
        }
    }
}

void USBCheckStdRequest(void)
{
  	locali = SetupPkt.bmRequestType & 0x60;
	if(locali != 0) return;  // standart request
    switch(SetupPkt.bRequest)
    {
        case SET_ADR:
            ctrl_trf_session_owner = MUID_USB9;
            usb_device_state = ADR_PENDING_STATE;
			// Update state only
             break;
        case GET_DSC:
            USBStdGetDscHandler();
            break;
        case SET_CFG:
            USBStdSetCfgHandler();
            break;
        case GET_CFG:
            ctrl_trf_session_owner = MUID_USB9;
            pSrc_bRam = (char*)&usb_active_cfg;         // Set Source
            usb_stat.ctrl_trf_mem = _RAM;               // Set memory type
            wCount = 1;                            // Set data count
            break;
        case GET_STATUS:
            USBStdGetStatusHandler();
            break;
        case CLR_FEATURE:
        case SET_FEATURE:
            USBStdFeatureReqHandler();
            break;
        case GET_INTF:
            ctrl_trf_session_owner = MUID_USB9;
            pSrc_bRam = (char*)&usb_alt_intf[0]+SetupPkt.wIndex.low8;  // Set source
            usb_stat.ctrl_trf_mem = _RAM;               // Set memory type
            wCount = 1;                            // Set data count
            break;
        case SET_INTF:
            ctrl_trf_session_owner = MUID_USB9;
            usb_alt_intf[SetupPkt.wIndex.low8] = SetupPkt.wValue.low8;
            break;
        case SET_DSC:
        case SYNCH_FRAME:
        default:
            break;
    }
}

/*====== >>>>>>>>>>>>>>>> USB TOKEN ANALYSE, DATA TRANSFER (chap8)  */
void USBCtrlTrfTxService(void)
{
  
    if(wCount < EP0_BUFF_SIZE)
    {
        char_to_send = wCount ;
        if(short_pkt_status == SHORT_PKT_NOT_USED)
        {
            short_pkt_status = SHORT_PKT_PENDING;
        }
        else if(short_pkt_status == SHORT_PKT_PENDING)
        {
            short_pkt_status = SHORT_PKT_SENT;
    	}

    }
    else
    char_to_send = EP0_BUFF_SIZE;
    ep0Bi.Stat.1 = 0;
    ep0Bi.Stat.0 = 0;
    ep0Bi.Stat |= char_to_send.high8;
    ep0Bi.Cnt = char_to_send.low8;
    wCount = wCount - char_to_send;
    pDst_bRam = &CtrlTrfData;        // Set destination pointer
    if(usb_stat.ctrl_trf_mem == _ROM)       // Determine type of memory source
    {
     while(char_to_send)
        {

		tpvar = tbl[pSrc_bRom];
		*pDst_bRam = tpvar;
		pDst_bRam++;
		pSrc_bRom++;
		char_to_send--;
        }
    }
    else // RAM
    {
        while(char_to_send)
        {
	     	tpvar = *pSrc_bRam;
			*pDst_bRam = tpvar;
            pDst_bRam++;
            pSrc_bRam++;
            char_to_send--;
        }
    }

}

void USBCtrlEPServiceComplete(void)
{
    PKTDIS = 0;
	if(ctrl_trf_session_owner == MUID_NULL)
    {
        ep0Bo.Cnt = EP0_BUFF_SIZE;
        ep0Bo.USB_ADR = &SetupPkt.bmRequestType;

        ep0Bo.Stat  = _USIE|_BSTALL;
        ep0Bi.Stat  = _USIE|_BSTALL;
    }
    else    // A module has claimed ownership of the control transfer session.
    {
        if(SetupPkt.bmRequestType.7 == DEV_TO_HOST)
        {
            if(SetupPkt.wLength < wCount )
                wCount  = SetupPkt.wLength;
            USBCtrlTrfTxService();
            ctrl_trf_state = CTRL_TRF_TX;
             ep0Bo.Cnt = EP0_BUFF_SIZE;
            ep0Bo.USB_ADR = &SetupPkt.bmRequestType;
            ep0Bo.Stat  = _USIE;           // Note: DTSEN is 0!
            ep0Bi.USB_ADR = &CtrlTrfData;
            ep0Bi.Stat  = _USIE|_DAT1|_DTSEN;
        }
        else    // (SetupPkt.DataDir == HOST_TO_DEV)
        {
            ctrl_trf_state = CTRL_TRF_RX;
            ep0Bi.Cnt = 0;
            ep0Bi.Stat  = _USIE|_DAT1|_DTSEN;
            ep0Bo.Cnt = EP0_BUFF_SIZE;
            ep0Bo.USB_ADR = &CtrlTrfData;
            ep0Bo.Stat  = _USIE|_DAT1|_DTSEN;
        }
    }

}


void USBCtrlTrfSetupHandler(void)
{
    if(ep0Bi.Stat.UOWN != 0)
    ep0Bi.Stat = _UCPU;           // Compensate for after a STALL
    short_pkt_status = SHORT_PKT_NOT_USED;
    /* Stage 1 */
    ctrl_trf_state = WAIT_SETUP;
    ctrl_trf_session_owner = MUID_NULL;   
    wCount = 0;

    /* Stage 2 */
    USBCheckStdRequest();                   
    /* Modifiable Section */
        if(ctrl_trf_session_owner == MUID_NULL)
        USBCheckCDCRequest();  
    /* End Modifiable Section */

    /* Stage 3 */
    USBCtrlEPServiceComplete();

}

void USBCtrlTrfRxService(void)
{

	char_to_read.high8 = 0x03 & ep0Bo.Stat ;    // Filter out last 2 bits
	char_to_read.low8 = ep0Bo.Cnt;
	wCount  = wCount + char_to_read ;

	pSrc_bRam = (char*)&CtrlTrfData;
	
	while(char_to_read )
    	{
	    	
		tpvar = *pSrc_bRam;
	    	*pDst_bRam = tpvar;
	    	pDst_bRam++;
		pSrc_bRam++;
        	char_to_read --;
    	}
}

void USBPrepareForNextSetupTrf(void)
{
	locali = ep0Bo.Stat & 0b00111100;
	if((ctrl_trf_state == CTRL_TRF_RX) && (PKTDIS == 1) &&
	(ep0Bo.Cnt == 8) && (locali ==SETUP_TOKEN) && 
	(ep0Bo.Stat.UOWN == 0))
	{
		char setup_cnt;
        ep0Bo.USB_ADR = &SetupPkt.bmRequestType;
        for(setup_cnt = 0; setup_cnt < 8; setup_cnt++)
        {
			tfrcalc2 = &SetupPkt.bmRequestType + setup_cnt;
			tfrcalc3 = &CtrlTrfData + setup_cnt;
			tpvar = *tfrcalc3;
	    	*tfrcalc2 = tpvar;
        }
    }
    else
    {
        ctrl_trf_state = WAIT_SETUP;            // See usbctrltrf.h
        ep0Bo.Cnt = EP0_BUFF_SIZE;              // Defined in usbcfg.h
        ep0Bo.USB_ADR = &SetupPkt.bmRequestType;
        ep0Bo.Stat  = _USIE|_DAT0|_DTSEN|_BSTALL;  // Added #F1
        ep0Bi.Stat  = _UCPU;               // Should be removed
    }
}


void USBCtrlTrfOutHandler(void)
{
    if(ctrl_trf_state == CTRL_TRF_RX)
    {
        USBCtrlTrfRxService();
        if(ep0Bo.Stat.DTS == 0)
            ep0Bo.Stat = _USIE|_DAT1|_DTSEN;
        else
            ep0Bo.Stat = _USIE|_DAT0|_DTSEN;
    }
    else    // CTRL_TRF_TX
        USBPrepareForNextSetupTrf();

}


void USBCtrlTrfInHandler(void)
{
	if(usb_device_state==ADR_PENDING_STATE) 
    {                                      
        UADDR = SetupPkt.wValue.low8;     //SetupPkt.bDevADR
        if(UADDR > 0)
		{                
    	     usb_device_state=ADDRESS_STATE; 
		} 
    	else
		{
        	usb_device_state=DEFAULT_STATE;
		}
	}
    if(ctrl_trf_state == CTRL_TRF_TX)
    {
        USBCtrlTrfTxService();
		if(short_pkt_status == SHORT_PKT_SENT)
    	{
    		ep0Bi.Stat = _USIE|_BSTALL;
		}
    	else
    	{
			if(ep0Bi.Stat.DTS == 0)
        		ep0Bi.Stat = _USIE|_DAT1|_DTSEN;
			else
        		ep0Bi.Stat = _USIE|_DAT0|_DTSEN;
		}
    }
    else // CTRL_TRF_RX
        USBPrepareForNextSetupTrf();
}

char USBCtrlEPService(void)
{

    if(USTAT == EP00_OUT)
    {
        TRNIF = 0; 
		EPctrl = ep0Bo.Stat & 0b00111100;
        if(EPctrl == 0b00110100)           // EP0 SETUP token
            USBCtrlTrfSetupHandler();
        else                                        // EP0 OUT
            USBCtrlTrfOutHandler();
    }
    else if(USTAT == EP00_IN)            	        // EP0 IN
    {
        TRNIF = 0; 
        USBCtrlTrfInHandler();
    }
    else
    {
        return 0;           // Return '0', if not an EP0 transaction
    }
    return 1;               // Return '1', if TRNIF has been cleared

}


/* ======== >>>>>>>>>>>>>>>>>>>>> USB HARDWARE DRIVERS   */

/** V A R I A B L E S ***********/
char bTRNIFCount;               // Bug fix - Work around.

void USBModuleEnable(void)
{	
	UCON = 0b00000000;
    UIE = 0;                                // Mask all USB interrupts
    USBEN = 1;                     // Enable module & attach to bus
    usb_device_state = ATTACHED_STATE;      // Defined in usbmmap.c & .h
	USBIE = 1;
	FlgUSB = 1;
}

void USBModuleDisable(void)
{
    UCON = 0;                               // Disable module & detach from bus
    UIE = 0;                                // Mask all USB interrupts
    usb_device_state = DETACHED_STATE;      // Defined in usbmmap.c & .h
	USBIE = 0;
	FlgUSB = 0;
}

//void USBSoftDetach(void)
//{
//    USBModuleDisable();
//}


void USBRemoteWakeup(void)
{
	static uns16 delay_count;
    if(usb_stat.RemoteWakeup == 1)          // Check if RemoteWakeup function
    {                                       // has been enabled by the host.
        SUSPND = 0;                // Added
        RESUME = 1;                // Start RESUME signaling

        // Modifiable Section 

        delay_count = 1800U;                // Set RESUME line for 1-13 ms
        do
        {
            delay_count--;
        }while(delay_count);

        //   End Modifiable Section 

        RESUME = 0;
    }
}

void USBSuspend(void)
{
#if ((defined _18F25K50) || (defined _18F45K50))
	ACTVIE = 1;
#else
	ACTIVIE = 1;		// Enable bus activity interrupt
#endif

	IDLEIF = 0;
	SUSPND = 1;			// Put USB module in power conserve
	/* Modifiable Section */
	USBIF = 0;
#if ((defined _18F25K50) || (defined _18F45K50))
	IOCB = 0;
#else
	RBIF = 0;
#endif
	USBIE = 1;			// Set USB wakeup source
#if ((defined _18F25K50) || (defined _18F45K50))
	IOCB = 1;
#else
	RBIE = 1;
#endif
	sleep();			// Goto sleep
#if ((defined _18F25K50) || (defined _18F45K50))
	if (IOCIF == 1)
#else
	if (RBIF == 1)
#endif
    {
    	USBRemoteWakeup();                  // If yes, attempt RWU
	}
	USBIE = 1;
#if ((defined _18F25K50) || (defined _18F45K50))
	IOCIE = 0;;
#else
	RBIE = 0;
#endif
    /* End Modifiable Section */
}

void USBWakeFromSuspend(void)
{
    SUSPND = 0;
#if ((defined _18F25K50) || (defined _18F45K50))
	ACTVIE = 0;
#else
	ACTIVIE= 0;
#endif
#if ((defined _18F25K50) || (defined _18F45K50))
	while(ACTVIF){ACTVIF = 0;}  // Added
#else
	while(ACTIVIF){ACTIVIF = 0;}  // Added
#endif
    

}

void USB_SOF_Handler(void)
{
    /* Callback routine here */
    SOFIF = 0;
}

void USBStallHandler(void)
{
	if(UEP0.0 == 1)	//EPSTALL
    {
    if((ep0Bo.Stat  == _USIE) && (ep0Bi.Stat  == (_USIE|_BSTALL)))
    {
         ep0Bo.Stat  = _USIE|_DAT0|_DTSEN|_BSTALL;
    }
	UEP0.0 = 0;         	    // Clear STALL status
    }
    STALLIF = 0;
}

void USBErrorHandler(void)
{
    /* Callback routine here */
     UEIR = 0;
}

void USBProtocolResetHandler(void)
{
    UEIR = 0;                       // Clear all USB error flags
    UIR = 0;                        // Clears all USB interrupts
    UEIE = 0b10011111;              // Unmask all USB error interrupts
    UIE = 0b01111011;               // Enable all interrupts except ACTVIE
    UADDR = 0x00;   
                // Reset to default address
    disable_endpt();              // Reset all non-EP0 UEPn registers
    UEP0 = EP_CTRL|HSHK_EN;         // Init EP0 as a Ctrl EP, see usbdrv.h

    while(TRNIF == 1)       // Flush any pending transactions
    {
        TRNIF = 0;
        nop(); nop(); nop();
        nop(); nop(); nop();
    }
    PKTDIS = 0;            // Make sure packet processing is enabled
    USBPrepareForNextSetupTrf();    // Declared in usbctrltrf.c
    usb_stat.RemoteWakeup = 0;      // Default status flag to disable
    usb_active_cfg = 0;             // Clear active configuration
    usb_device_state = DEFAULT_STATE;

}


void USBCheckBusStatus(void)
{  

    #define USB_BUS_ATTACHED    1
    #define USB_BUS_DETACHED    0

#ifdef USB_PLUGGED_CHECK

    if(usb_bus_sense == USB_BUS_ATTACHED)       // Is USB bus attached?
    {
        if(USBEN == 0)                 // Is the module off?
        {
		   USBModuleEnable();
        }         // Is off, enable it
    }
    else
    {
        if(USBEN == 1)                 // Is the module on?
            USBModuleDisable();                 // Is on, disable it
    }
    
 #else
        if(USBEN == 0)                 // Is the module off?
        {
		   USBModuleEnable();
        }         // Is off, enable it

#endif

    if(usb_device_state == ATTACHED_STATE)
    {
        if(SE0 == 0)
        {   UIR = 0;                        // Clear all USB interrupts
            UIE = 0;                        // Mask all USB interrupts
            URSTIE = 1;             // Unmask RESET interrupt
		    IDLEIE = 1;             // Unmask IDLE interrupt
			USBIE = 1;			// start interrupts 
            usb_device_state = POWERED_STATE;
        }
    }

}

void USBDriverService(void)
{
   // Pointless to continue servicing if USB cable is not even attached.
    if(usb_device_state == DETACHED_STATE) return;
//      Task A: Service USB Activity Interrupt
#if ((defined _18F25K50) || (defined _18F45K50))
	if(ACTVIF	&& ACTVIE )    USBWakeFromSuspend();
#else
	if(ACTIVIF	&& ACTIVIE )    USBWakeFromSuspend();
#endif
// Pointless to continue servicing if the device is in suspend mode.
    if(SUSPND==1) return;
    if(URSTIF && URSTIE)    USBProtocolResetHandler();
    if(IDLEIF && IDLEIE)    USBSuspend();
    if(SOFIF && SOFIE)      USB_SOF_Handler();
    if(STALLIF && STALLIE)  USBStallHandler();
    if(UERRIF && UERRIE)    USBErrorHandler();
    if(usb_device_state < DEFAULT_STATE) return;
/* Bug Fix: May 14, 2007  */
    for(bTRNIFCount = 0; bTRNIFCount < 4; bTRNIFCount++)
    {
        if(TRNIF && TRNIE)
        {
               if(USBCtrlEPService() == 0) // If not an EP0 transaction, then clear TRNIF.
            {
  		     TRNIF = 0;
			
            }
        }//end if(UIRbits.TRNIF && UIEbits.TRNIE)
        else
            break;
    }
}
