#ifndef USB_H
#define USB_H

/*** USB CDC INCLUDES  ****/

/**********************NOTICE *************************
The 3 following files must be included in project directory :
DescrTblConst.h, USB_CDC_RTGS.c and this file USB_CDC.h

file USB_CDC_RTGS must be included before any call to the USB routines.

The following lines must be placed in an interrupt routine.
works fine in high or low priority.

//----------- cut here and paste -------------

uns16 sv_FSR0 = FSR0;
uns8 sv_PCLATH = PCLATH;
uns8 sv_PCLATU = PCLATU;
uns8 sv_PRODL = PRODL;
uns8 sv_PRODH = PRODH;
uns8 sv_TBLPTRH = TBLPTRH; uns8 sv_TBLPTRL = TBLPTRL;uns8 sv_TABLAT = TABLAT;
if (USBIF == 1)
{
	if (FlgUSB == 1)
	USBDriverService();
	USBIF = 0;
}
FSR0 = sv_FSR0;
PCLATH = sv_PCLATH;
PCLATU = sv_PCLATU;
PRODL = sv_PRODL;
PRODH = sv_PRODH;
TBLPTRH = sv_TBLPTRH;
TBLPTRL = sv_TBLPTRL;
TABLAT = sv_TABLAT;

//-----------------------------------------------
This h file must be included before this interrupt routine
or the variable FlgUSB is to be defined and a prototype 
for USBDriverService must be defined as well.

The following must be placed in main routine after the hardware
initialisation :
//----------- cut here and paste -----------------------
		USB_Hdwr_Init();
		USBCheckBusStatus();
		tempo(10,1);			// any king of tempo of around 10ms.
		USBCheckBusStatus();
//-------------------------------------------------------

and finaly the next is to be placed in the main infinite loop
//----------- cut here and paste -----------------------
			#ifdef USB_PLUGGED_CHECK
			USBCheckBusStatus();
			#endif
			// next line is the activation of transfer to USB in or out
			// of data to or from buffers.
			CDCTxService();		
// ------------------------------------------------------

To get acces to the USB intf :
// fill the data in a buffer (eg output_buffer) for sending, a call to 
// CDCTxService will activate the physical USB transfer.
			char *outpc;
			char output_buffer[32];	// size as needed.
			.......
			outpc = &output_buffer[0];
            putsUSBUSART(outpc);
// data are placed in buffer after received. 64 is example of buffer size.
// function parametres are address of buffer and max data of buffer. returns the
// number of datas actually received, 0 if nothing received. 
			
			char *inpc;
			char inp;
			char input_buffer[64];	//size as needed.
			..............
			inpc = &input_buffer[0];
			inp = getsUSBUSART(inpc, 64);
			
At Host level, the connection appears as a com port.

*******************************************************/

/** D E F I N I T I O N S *******************************************/
#define EP0_BUFF_SIZE           8   // 8, 16, 32, or 64

/* Parameter definitions are defined in usbdrv.h */
#define MODE_PP                 _PPBM0
#define UCFG_VAL                 0b00010100  //upuen1,utrdis0,fsen1,PPb00 (no ping pong)PP

// uncomment as needed the next defines if there is a hardware check of 
// 5v presence on the USB plug. 

/*************** Optional Hardware ******************/
//#define USB_PLUGGED_CHECK		// uncomment to use this check	
#ifdef USB_PLUGGED_CHECK
#define USE_SELF_POWER_SENSE_IO
#define USE_USB_BUS_SENSE_IO

#define tris_usb_bus_sense  	TRISB.2    // Input
#define usb_bus_sense       	PORTB.2
#define tris_self_power    		TRISB.2    // Input
#define self_power          	PORTB.2
#endif
/***************************************************/

/** D E V I C E  C L A S S  U S A G E *******************************/
#define USB_USE_CDC


/* CDC */
#define CDC_COMM_INTF_ID        0x00
#define CDC_COMM_UEP            UEP1
#define CDC_INT_BD_IN           ep1Bi
#define CDC_INT_EP_SIZE         8

#define CDC_DATA_INTF_ID        0x01
#define CDC_DATA_UEP            UEP2
#define CDC_BULK_BD_OUT         ep2Bo
#define CDC_BULK_OUT_EP_SIZE    64
#define CDC_BULK_BD_IN          ep2Bi
#define CDC_BULK_IN_EP_SIZE     64
#define LINE_CODING_LENGTH          0x07
#define dummy_length    0x08

#define MAX_EP_NUMBER           2         // UEP3


/********************************************************************
      D E F I N I T I O N S 
*********************************************************************/

// ********** SOFT FLAGS  ***************

// Control Transfer States
#define WAIT_SETUP          0
#define CTRL_TRF_TX         1
#define CTRL_TRF_RX         2

// Short Packet States - Used by Control Transfer Read  - CTRL_TRF_TX
#define SHORT_PKT_NOT_USED  0
#define SHORT_PKT_PENDING   1
#define SHORT_PKT_SENT      2


#define MUID_NULL           0
#define MUID_USB9           1
#define MUID_HID            2
#define MUID_CDC            3
#define MUID_MSD            4

#define INPUT_PIN           1
#define OUTPUT_PIN          0

// USB Device States - To be used with [char usb_device_state]
#define DETACHED_STATE					0
#define ATTACHED_STATE					1
#define POWERED_STATE       			2
#define DEFAULT_STATE       			3
#define ADR_PENDING_STATE   		4
#define ADDRESS_STATE       			5
#define CONFIGURED_STATE    		6
// Memory Types for Control Transfer - used in USB_DEVICE_STATUS
#define _RAM 0
#define _ROM 1
#define RemoteWakeup 0  // [0]Disabled [1]Enabled: See usbdrv.c,usb9.c
#define ctrl_trf_mem 1  // [0]RAM      [1]ROM      

// Buffer Descriptor Status Register Initialization Parameters
#define _BSTALL		0x04                //Buffer Stall enable
#define _DTSEN		0x08                //Data Toggle Synch enable
#define _INCDIS		0x10                //Address increment disable
#define _KEN			0x20                //SIE keeps buff descriptors enable
#define _DAT0			0x00                //DATA0 packet expected next
#define _DAT1			0x40                //DATA1 packet expected next
#define _DTSMASK		0x40                //DTS Mask
#define _USIE			0x80                //SIE owns buffer
#define _UCPU			0x00                //CPU owns buffer
#define DTS			6					// (RM) DTS bit pos
#define UOWN			7					// Buffer owner bit

/* UEPn Initialization Parameters */
#define EP_CTRL     0x06            // Cfg Control pipe for this ep
#define EP_OUT      0x0C            // Cfg OUT only pipe for this ep
#define EP_IN       0x0A            // Cfg IN only pipe for this ep
#define EP_OUT_IN   0x0E            // Cfg both OUT & IN pipes for this ep
#define HSHK_EN     0x10            // Enable handshake packet

#define PIC_EP_NUM_MASK 0b01111000
#define PIC_EP_DIR_MASK 0b00000100

#define EP00_OUT    0x00
#define EP00_IN     0x04
#define EP01_OUT    0x08;
#define EP01_IN     0x0C;
#define EP02_OUT    ((0x02<<3)|(OUT<<2))
#define EP02_IN     ((0x02<<3)|(IN<<2))
#define EP03_OUT    ((0x03<<3)|(OUT<<2))
#define EP03_IN     ((0x03<<3)|(IN<<2))
#define EP04_OUT    ((0x04<<3)|(OUT<<2))
#define EP04_IN     ((0x04<<3)|(IN<<2))
#define EP05_OUT    ((0x05<<3)|(OUT<<2))
#define EP05_IN     ((0x05<<3)|(IN<<2))
#define EP06_OUT    ((0x06<<3)|(OUT<<2))
#define EP06_IN     ((0x06<<3)|(IN<<2))
#define EP07_OUT    ((0x07<<3)|(OUT<<2))
#define EP07_IN     ((0x07<<3)|(IN<<2))
#define EP08_OUT    ((0x08<<3)|(OUT<<2))
#define EP08_IN     ((0x08<<3)|(IN<<2))
#define EP09_OUT    ((0x09<<3)|(OUT<<2))
#define EP09_IN     ((0x09<<3)|(IN<<2))
#define EP10_OUT    ((0x0A<<3)|(OUT<<2))
#define EP10_IN     ((0x0A<<3)|(IN<<2))
#define EP11_OUT    ((0x0B<<3)|(OUT<<2))
#define EP11_IN     ((0x0B<<3)|(IN<<2))
#define EP12_OUT    ((0x0C<<3)|(OUT<<2))
#define EP12_IN     ((0x0C<<3)|(IN<<2))
#define EP13_OUT    ((0x0D<<3)|(OUT<<2))
#define EP13_IN     ((0x0D<<3)|(IN<<2))
#define EP14_OUT    ((0x0E<<3)|(OUT<<2))
#define EP14_IN     ((0x0E<<3)|(IN<<2))
#define EP15_OUT    ((0x0F<<3)|(OUT<<2))
#define EP15_IN     ((0x0F<<3)|(IN<<2))

// **************** CHAP 8 & CHAP 9 constants ****************

//  Endpoint Transfer Type
#define _CTRL       0x00            //Control Transfer
#define _ISO        0x01            //Isochronous Transfer
#define _BULK       0x02            //Bulk Transfer
#define _INT        0x03            //Interrupt Transfer

// Descriptor Types
#define DSC_DEV     0x01
#define DSC_CFG     0x02
#define DSC_STR     0x03
#define DSC_INTF    0x04
#define DSC_EP      0x05

#define _EP01_OUT   0x01
#define _EP01_IN    0x81
#define _EP02_OUT   0x02
#define _EP02_IN    0x82
#define _EP03_OUT   0x03
#define _EP03_IN    0x83
#define _EP04_OUT   0x04
#define _EP04_IN    0x84
#define _EP05_OUT   0x05
#define _EP05_IN    0x85
#define _EP06_OUT   0x06
#define _EP06_IN    0x86
#define _EP07_OUT   0x07
#define _EP07_IN    0x87
#define _EP08_OUT   0x08
#define _EP08_IN    0x88
#define _EP09_OUT   0x09
#define _EP09_IN    0x89
#define _EP10_OUT   0x0A
#define _EP10_IN    0x8A
#define _EP11_OUT   0x0B
#define _EP11_IN    0x8B
#define _EP12_OUT   0x0C
#define _EP12_IN    0x8C
#define _EP13_OUT   0x0D
#define _EP13_IN    0x8D
#define _EP14_OUT   0x0E
#define _EP14_IN    0x8E
#define _EP15_OUT   0x0F
#define _EP15_IN    0x8F

// USB PID: Token Types - See chapter 8 in the USB specification 
#define SETUP_TOKEN         0b00110100
#define OUT_TOKEN           0b00000100
#define IN_TOKEN            0b00100100

// bmRequestType Definitions - chap 9
#define HOST_TO_DEV         0
#define DEV_TO_HOST         1

#define STANDARD            0x00
#define CLASS               0x20
#define VENDOR              0x40

#define RCPT_DEV            0
#define RCPT_INTF           1
#define RCPT_EP             2
#define RCPT_OTH            3

//bRequest def
#define GET_STATUS  0
#define CLR_FEATURE 1
#define SET_FEATURE 3
#define SET_ADR     5
#define GET_DSC     6
#define SET_DSC     7
#define GET_CFG     8
#define SET_CFG     9
#define GET_INTF    10
#define SET_INTF    11
#define SYNCH_FRAME 12

/* Standard Feature Selectors */
#define DEVICE_REMOTE_WAKEUP    0x01
#define ENDPOINT_HALT           0x00



/********************* CDC ******************/

/* Class-Specific Requests */
#define SEND_ENCAPSULATED_COMMAND   0x00
#define GET_ENCAPSULATED_RESPONSE   0x01
#define SET_COMM_FEATURE            0x02
#define GET_COMM_FEATURE            0x03
#define CLEAR_COMM_FEATURE          0x04
#define SET_LINE_CODING             0x20
#define GET_LINE_CODING             0x21
#define SET_CONTROL_LINE_STATE      0x22
#define SEND_BREAK                  0x23

/* Notifications *
 * Note: Notifications are polled over
 * Communication Interface (Interrupt Endpoint)
 */
#define NETWORK_CONNECTION          0x00
#define RESPONSE_AVAILABLE          0x01
#define SERIAL_STATE                0x20


/* Device Class Code */
#define CDC_DEVICE                  0x02

/* Communication Interface Class Code */
#define COMM_INTF                   0x02

/* Communication Interface Class SubClass Codes */
#define ABSTRACT_CONTROL_MODEL      0x02

/* Communication Interface Class Control Protocol Codes */
#define V25TER                      0x01    // Common AT commands ("Hayes(TM)")


/* Data Interface Class Codes */
#define DATA_INTF                   0x0A

/* Data Interface Class Protocol Codes */
#define NO_PROTOCOL                 0x00    // No class specific protocol required


/* Communication Feature Selector Codes */
#define ABSTRACT_STATE              0x01
#define COUNTRY_SETTING             0x02

/* Functional Descriptors */
/* Type Values for the bDscType Field */
#define CS_INTERFACE                0x24
#define CS_ENDPOINT                 0x25

/* bDscSubType in Functional Descriptors */

#define DSC_FN_HEADER               0x00
#define DSC_FN_CALL_MGT             0x01
#define DSC_FN_ACM                  0x02    // ACM - Abstract Control Management
#define DSC_FN_DLM                  0x03    // DLM - Direct Line Managment
#define DSC_FN_TELEPHONE_RINGER     0x04
#define DSC_FN_RPT_CAPABILITIES     0x05
#define DSC_FN_UNION                0x06
#define DSC_FN_COUNTRY_SELECTION    0x07
#define DSC_FN_TEL_OP_MODES         0x08
#define DSC_FN_USB_TERMINAL         0x09
/* more.... see Table 25 in USB CDC Specification 1.1 */

/* CDC Bulk IN transfer states */
#define CDC_TX_READY                0
#define CDC_TX_BUSY                 1
#define CDC_TX_BUSY_ZLP             2       // ZLP: Zero Length Packet
#define CDC_TX_COMPLETING           3

/********************************************************
            S T R U C T U R E S
*******************************************************/

// Setup packet
   typedef struct _CTRL_TRF_SETUP
    {
        char bmRequestType;
        char bRequest;    
        uns16 wValue;
        uns16 wIndex;
        uns16 wLength;
    }CTRL_TRF_SETUP;

//Buffer Descriptor Status Register
typedef struct _BDT
{
        char Stat;
        char Cnt;
        size2 char *USB_ADR;                    //Buffer Address High
}BDT;                                  //Buffer Descriptor Table

// CDC
typedef struct _LINE_CODING
{
        char 	dwDTERateH;			// trick used for free compiler
        uns24   dwDTERate;          // dwDTERate is a 32 bit uns
        char    bCharFormat;
        char    bParityType;
        char    bDataBits;
} LINE_CODING;

typedef struct _CONTROL_SIGNAL_BITMAP
{
        unsigned DTE_PRESENT;       // [0] Not Present  [1] Present
        unsigned CARRIER_CONTROL;   // [0] Deactivate   [1] Activate
   
} CONTROL_SIGNAL_BITMAP;


/******************************************************************
                   U S B  V A L I D A T I O N 
******************************************************************/

#if (EP0_BUFF_SIZE != 8) && (EP0_BUFF_SIZE != 16) && \
    (EP0_BUFF_SIZE != 32) && (EP0_BUFF_SIZE != 64)
	#error(Invalid buffer size for endpoint 0,check "autofiles\usbcfg.h")
#endif


#define MAX_NUM_INT 2
/**  G L O B A L  V A R I A B L E S ************************************/

#pragma rambank -

// USB 
char usb_device_state;          // Device States: DETACHED, ATTACHED, ...
char usb_stat;    				// Global USB flags
char usb_active_cfg;            // Value of current configuration
char usb_alt_intf[MAX_NUM_INT]; // Array to keep track of the current alternate
char tpvar;					// general purpose
char lpvar, StoreVar;
char ctrl_trf_state;            // Control Transfer State
char ctrl_trf_session_owner;    // Current transfer session owner
char short_pkt_status;          // Flag used by Control Transfer Read
uns16 wCount;
char pSrc_bRom;			// index to read constants data
size2 char *pSrc_bRam;
size2 char *pDst_bRam;

// CDC 
char cdc_rx_len;            // total rx length
char cdc_trf_state;         // States are defined cdc.h
char *pCDCSrc;            // Dedicated source pointer
char *pCDCDst;            // Dedicated destination pointer
char cdc_tx_len;            // total tx length
char cdc_mem_type;          // _ROM, _RAM
LINE_CODING line_coding;    // Buffer to store line coding information
CONTROL_SIGNAL_BITMAP control_signal_bitmap;
char dummy_encapsulated_cmd_response[dummy_length];

// USB local variables taken out from procedures for interrupt mode

uns16 suspendtmp;
char EPctrl;
char locali;
char calc1, tp;
uns16 char_to_send;
uns16 char_to_read;
char *tfrcalc2;
char *tfrcalc3;

/* ********* resreve end point buffer descriptors as needed *****/

#pragma rambank 4

// End Point 0 mandatory
BDT ep0Bo;         //Endpoint #0 BD Out
BDT ep0Bi;         //Endpoint #0 BD In

BDT ep1Bo;         //Endpoint #1 BD Out
BDT ep1Bi;         //Endpoint #1 BD In

#if(2 <= MAX_EP_NUMBER)
BDT ep2Bo;         //Endpoint #2 BD Out
BDT ep2Bi;         //Endpoint #2 BD In
#endif
#if(3 <= MAX_EP_NUMBER)
BDT ep3Bo;         //Endpoint #3 BD Out
BDT ep3Bi;         //Endpoint #3 BD In
#endif
#if(4 <= MAX_EP_NUMBER)
BDT ep4Bo;         //Endpoint #4 BD Out
BDT ep4Bi;         //Endpoint #4 BD In
#endif
#if(5 <= MAX_EP_NUMBER)
BDT ep5Bo;         //Endpoint #5 BD Out
BDT ep5Bi;         //Endpoint #5 BD In
#endif
#if(6 <= MAX_EP_NUMBER)
BDT ep6Bo;         //Endpoint #6 BD Out
BDT ep6Bi;         //Endpoint #6 BD In
#endif
#if(7 <= MAX_EP_NUMBER)
BDT ep7Bo;         //Endpoint #7 BD Out
BDT ep7Bi;         //Endpoint #7 BD In
#endif
#if(8 <= MAX_EP_NUMBER)
BDT ep8Bo;         //Endpoint #8 BD Out
BDT ep8Bi;         //Endpoint #8 BD In
#endif
#if(9 <= MAX_EP_NUMBER)
BDT ep9Bo;         //Endpoint #9 BD Out
BDT ep9Bi;         //Endpoint #9 BD In
#endif
#if(10 <= MAX_EP_NUMBER)
BDT ep10Bo;        //Endpoint #10 BD Out
BDT ep10Bi;        //Endpoint #10 BD In
#endif
#if(11 <= MAX_EP_NUMBER)
BDT ep11Bo;        //Endpoint #11 BD Out
BDT ep11Bi;        //Endpoint #11 BD In
#endif
#if(12 <= MAX_EP_NUMBER)
BDT ep12Bo;        //Endpoint #12 BD Out
BDT ep12Bi;        //Endpoint #12 BD In
#endif
#if(13 <= MAX_EP_NUMBER)
BDT ep13Bo;        //Endpoint #13 BD Out
BDT ep13Bi;        //Endpoint #13 BD In
#endif
#if(14 <= MAX_EP_NUMBER)
BDT ep14Bo;        //Endpoint #14 BD Out
BDT ep14Bi;        //Endpoint #14 BD In
#endif
#if(15 <= MAX_EP_NUMBER)
BDT ep15Bo;        //Endpoint #15 BD Out
BDT ep15Bi;        //Endpoint #15 BD In
#endif

/* ************** End points ram booking **********/
#pragma rambank 5

CTRL_TRF_SETUP SetupPkt;
char CtrlTrfData;

char cdc_notice[CDC_INT_EP_SIZE];
char cdc_data_rx[CDC_BULK_OUT_EP_SIZE];
char cdc_data_tx[CDC_BULK_IN_EP_SIZE];


#define CDC_INT_BD_IN           ep1Bi
#define CDC_BULK_BD_OUT         ep2Bo
#define CDC_BULK_BD_IN          ep2Bi

#pragma rambank 1

// User data

char input_buffer[32];
char output_buffer[32];

char tpbuf[20];
bit firstdata, charin;
#pragma rambank 0
/*********************************************************
			PROTOTYPES
************************************************************/



#endif
