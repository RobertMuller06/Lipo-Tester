#ifndef LCD128x64inc 
#define LCD128x64inc

/*********************************************************************
 *
 *                LCD Display 128x64 header file
 *
 *********************************************************************
 * FileName:        128x64_LCD.h
 * Processor:       PIC18F4550
  ********************************************************************/

#pragma rambank 0

#define	LCD_DataPort  PORTD 	// write data and toggle it in
#define LCD_TrisDataPort TRISD			

#define UPDATE_LCD       			TRUE
#define UPDATE_RAM					NULL

/*************** B I T   S T A T E   D E F I N I T I O N S *********/
#if defined LCD_Large
#define LCDK_CS1_ACTV				LCDKW_CS1 = 1      // PDATA L0
#define LCDK_CS1_INACT				LCDKW_CS1 = 0     // PDATA L0

#define LCDK_CS2_ACTV				LCDKW_CS2 = 1     // PDATA L1
#define LCDK_CS2_INACT				LCDKW_CS2 = 0     // PDATA L1
#else
#define LCDK_CS1_ACTV				LCDKW_CS1 = 0      // PDATA L0
#define LCDK_CS1_INACT				LCDKW_CS1 = 1     // PDATA L0

#define LCDK_CS2_ACTV				LCDKW_CS2 = 0     // PDATA L1
#define LCDK_CS2_INACT				LCDKW_CS2 = 1     // PDATA L1
#endif
#define LCDK_DI_HIGH                 LCDKW_DI = 1		// PDATA L4
#define LCDK_DI_LOW                  LCDKW_DI = 0     // PDATA L4

#define LCDK_E_HIGH                  LCDK_E = 1 //E_Pulse_Delay();      // keep equal times  - PDATA L2
#define LCDK_E_LOW                   LCDK_E = 0  // E_Pulse_Delay();      // keep equal times  - PDATA L2

#define LCDK_RW_READ                  LCDK_RW = 1;  //E_Pulse_Delay();      // keep equal times  - PDATA L2
#define LCDK_RW_WRITE                 LCDK_RW = 0;  //E_Pulse_Delay();      // keep equal times  - PDATA L2

// #define LCD_TOGGLE_E			nop();  LCD_E_HIGH; nop(); nop(); nop(); LCD_E_LOW; nop(); 	nop(); 

#define LCDK_BACKLIGHT_ON            1                  
#define LCDK_BACKLIGHT_OFF           0                 


/*************** L C D   F O N T   D E F I N E   S I Z E S ******/
#define STYLE5x8					5
#define STYLE6x8					6
#define STYLE8x8					8

#define LCD_LINE_1				0
#define LCD_LINE_2				1
#define LCD_LINE_3				2
#define LCD_LINE_4				3
#define LCD_LINE_5				4
#define LCD_LINE_6				5
#define LCD_LINE_7				6
#define LCD_LINE_8				7

//#define Font5x8		0
#define Font6x8		1
#define Font8x8		2

/************* VARIABLES ***************/
char LCDK_Status;

/*************** F U N C T I O N S   P R O T O T Y P E S ******/
void LCDK_ChkRdy(void);
void LCDK_CLK(void);
void LCDK_Initalize(void);
void LCDK_WriteCMD(char Command, char DispSide);
void LCDK_GetTrueY(char *vdata, char y);
void LCDK_GotoXY(char x, char y);
void LCDK_PixelPut(char x, char y);
void LCDK_PixelClr(char x, char y);
void LCDK_WriteChar(char x, char y, char dispdata);
void LCDK_WriteNextChar( char dispdata);
char LCDK_ReadData(char x, char y);
void LCDK_Cls(char vfill); 
//void LCDK_PrintLine(char pfont_tbl, char location_x, char LCDLine,bit reverse);

#endif




