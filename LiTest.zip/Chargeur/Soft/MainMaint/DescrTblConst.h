#ifndef _Const_Descr_Dev
#define _Const_Descr_Dev

#define ofs_device_dsc 0
#define ofs_CFG01 18
#define lencfg1 67
#define ofs_CFG02 85		//18+lencfg1 (18+67)
#define lencfg2 0
#define ofs_sd000 85		//18+lencfg1+lencfg2
#define ofs_sd001 89
#define ofs_sd002 116		// ofs_sd001+52

char IdxCfg (char depl2)
{skip(depl2);
#pragma return[] = ofs_CFG01 ofs_CFG02
}

char IdxStr (char depl3)
{skip(depl3);
#pragma return[] = ofs_sd000 ofs_sd001 ofs_sd002
}

const  char tbl[] = {
// device descriptor
18,
DSC_DEV,
0x00,0x02,
CDC_DEVICE,
0,
0,
EP0_BUFF_SIZE,
0xD8, 0x04,
0x0A,
0,
1,
0,
0x01,
0x02,
0,
0x01,
// Configuration Descriptor
9, DSC_CFG,67,0,2,1,0,0xc0,100,
// Interface Descriptor
9,DSC_INTF,0,0,1,COMM_INTF,ABSTRACT_CONTROL_MODEL,V25TER,0,
// Class-Specific Descriptor
5,CS_INTERFACE,DSC_FN_HEADER,0x10,0x01,
4,CS_INTERFACE,DSC_FN_ACM,0x02,
5,CS_INTERFACE,DSC_FN_UNION,CDC_COMM_INTF_ID,CDC_DATA_INTF_ID,
5,CS_INTERFACE,DSC_FN_CALL_MGT,0,CDC_DATA_INTF_ID,
// Endpoint Descriptor
7,DSC_EP,_EP01_IN,_INT,CDC_INT_EP_SIZE,0,0x02,
// Interface Descriptor
9,DSC_INTF,1,0,2,DATA_INTF,0,NO_PROTOCOL,0,
// Endpoint Descriptor
7,DSC_EP,_EP02_OUT,_BULK,CDC_BULK_OUT_EP_SIZE,0,0x00,
7,DSC_EP,_EP02_IN,_BULK,CDC_BULK_IN_EP_SIZE,0,0x00,
// Language ID
4,DSC_STR,0x09,0x04,
// Sring 001
27,DSC_STR,'M','i','c','r','o','c','h','i','p',' ',
'T','e','c','h','n','o','l','o','g','y',' ','I','n','c','.',
26,DSC_STR,'C','D','C','R','S','-','2','3','2',
'E','m','u','l','a','t','i','o','n',
'D','e','m','o'
};

#endif