/* Menus */
char MPg ;
char RevLn,OpsCode;
char Rotsv ;
bit refr;

void MnuPrtLn (char Msg, char len, char x, char y,bit rev)
{
	char i;
	i = GetText(Msg,0,len,0);
	if (len != 255) txt[len] = 0;
	LCDK_PrintLine(FONT6X8,x,y,rev);	
}
	
void MenuInit (void)
{
	LCDK_Cls(0);
	GetText(6,0,14,1);
	LCDK_PrintLine(FONT8X8,0,0,0);
	LCDK_DrawLine (0,11,127,11);
	GetText(7,0,9,0);
	LCDK_PrintLine(FONT6X8,0,2,0);
	LCDK_DrawLine (0,20,61,20);
	GetText(8,0,11,0);
	LCDK_PrintLine(FONT6X8,0,3,0);
	LCDK_DrawLine (0,28,75,28);
	GetText(9,0,13,0);
	LCDK_PrintLine(FONT6X8,0,4,0);
	LCDK_DrawLine (0,36,89,36);	
	GetText(10,0,11,0);
	LCDK_PrintLine(FONT6X8,0,5,1);
	MPg = 0;
	MPg.0 = 1;
	RevLn = 0;
	ReslSWup = 0;
	upcntr = 0;
	Rotsv = 0;
	LED3_Off;
}

void MnuMaintInit (void)
{
	MPg = 0;
	MPg.3 = 1;
	LCDK_Cls(0);
	GetText(10,0,11,1);
	LCDK_PrintLine(FONT8X8,0,0,0);
	MnuPrtLn(13,12,0,1,1);
	MnuPrtLn(14,13,0,2,0);
	MnuPrtLn(15,15,0,3,0);
	MnuPrtLn(16,17,0,4,0);
	MnuPrtLn(17,12,0,5,0);
	MnuPrtLn(18,14,0,6,0);
	MnuPrtLn(6,14,0,7,0);
	Rotsv = 0;
	RevLn = 0;
}
	
void Menu (void)
{
	refr = 0;
	upmoins = 0;
	if (Rotsv > upcntr)
	{
		Rotsv --;
		upcntr = Rotsv;
		refr = 1;
	}
	if (upcntr > Rotsv)
	{
		Rotsv++;
		upcntr = Rotsv;
		refr = 1;
	}		
	
	/* *****************************************************
			ROTATION PART
	****************************************************** */
	if (refr)
	{
		if (MPg.0)
		{
			upmoins = 3;
			upplus = 3;
			upcntr = 3;
			MnuPrtLn(10,11,0,5,1);
			RevLn = 3;
		}			
		else if (MPg.1)		//calibre I Menu
		{
			upmoins = 0;
			upplus = 2;	
			switch (upcntr)
			{
				case 0:
				{
					MnuPrtLn(72,16,0,2,1);
					MnuPrtLn(73,16,0,3,0);
					RevLn = 0;
					break;
				}	
		
				case 1:
				{
					MnuPrtLn(73,16,0,3,1);
					if (RevLn == 0)
					{
						MnuPrtLn(72,16,0,2,0);
					}
					else
					{
						MnuPrtLn(6,14,0,4,0);
					}
					RevLn = 1;
					break;		
				}
				case 2:
				{
					MnuPrtLn(6,14,0,4,1);
					MnuPrtLn(73,16,0,3,0);	
					RevLn = 2;
					break;
				}
			}		

			
		}
		else if (MPg.2)
		{
			
		}			
		else if (MPg.3)		//maintenance page
		{
			upplus = 6;
			switch (upcntr)
			{
				case 0:
				{
					MnuPrtLn(13,12,0,1,1);
					MnuPrtLn(14,13,0,2,0);
					RevLn = 0;
					break;
				}	
		
				case 1:
				{
					MnuPrtLn(14,13,0,2,1);
					if (RevLn == 0)
					{
						MnuPrtLn(13,12,0,1,0);
					}
					else
					{
						MnuPrtLn(15,15,0,3,0);
					}
					RevLn = 1;
					break;		
				}
		
				case 2:
				{
					MnuPrtLn(15,15,0,3,1);
					if (RevLn == 1)
					{
						MnuPrtLn(14,13,0,2,0);
					}
					else
					{
						MnuPrtLn(16,17,0,4,0);
					}
					RevLn = 2;
					break;		
				}
				case 3:
				{
					MnuPrtLn(16,17,0,4,1);
					if (RevLn == 2)
					{
						MnuPrtLn(15,15,0,3,0);
					}
					else
					{
						MnuPrtLn(17,12,0,5,0);
					}
					RevLn = 3;
					break;		
				}
				case 4:
				{
					MnuPrtLn(17,12,0,5,1);
					if (RevLn == 3)
					{
						MnuPrtLn(16,17,0,4,0);
					}
					else
					{
						MnuPrtLn(18,14,0,6,0);
					}
					RevLn = 4;
					break;		
				}
				case 5:
				{
					MnuPrtLn(18,14,0,6,1);
					if (RevLn == 4)
					{
						MnuPrtLn(17,12,0,5,0);
					}
					else
					{
						MnuPrtLn(6,14,0,7,0);
					}
					RevLn = 5;
					break;						
				}	
				case 6:
				{
					MnuPrtLn(6,14,0,7,1);
					MnuPrtLn(18,14,0,6,0);
					RevLn = 6;
					break;		
				}
			}	
			
		}
		else if (MPg.4)		//Hardware tests
		{
			upplus = 5;
			switch (upcntr)
			{
				case 0:
				{
					MnuPrtLn(19,11,0,2,1);
					MnuPrtLn(20,15,0,3,0);
					RevLn = 0;
					break;
				}	
		
				case 1:
				{
					MnuPrtLn(20,15,0,3,1);
					if (RevLn == 0)
					{
						MnuPrtLn(19,11,0,2,0);
					}
					else
					{
						MnuPrtLn(21,16,0,4,0);
					}
					RevLn = 1;
					break;		
				}
				case 2:
				{
					MnuPrtLn(21,16,0,4,1);
					if (RevLn == 1)
					{
						MnuPrtLn(20,15,0,3,0);
					}
					else
					{
						MnuPrtLn(22,11,0,5,0);
					}
					RevLn = 2;
					break;		
				}
				case 3:
				{
					MnuPrtLn(22,11,0,5,1);
					if (RevLn == 2)
					{
						MnuPrtLn(21,16,0,4,0);
					}
					else
					{
						MnuPrtLn(23,6,0,6,0);
					}
					RevLn = 3;
					break;		
				}
				case 4:
				{
					MnuPrtLn(23,6,0,6,1);
					if (RevLn == 3)
					{
						MnuPrtLn(22,11,0,5,0);
					}
					else
					{
						MnuPrtLn(6,14,0,7,0);
					}
					RevLn = 4;
					break;
				}	
				case 5:
				{
					MnuPrtLn(6,14,0,7,1);
					MnuPrtLn(23,6,0,6,0);
					RevLn = 6;
					break;		
				}
			}		
		}	
		else if (MPg.5)		//Voltage calibration
		{
			upplus = 4;
			switch (upcntr)
			{
				case 0:
				{
					MnuPrtLn(37,16,0,2,1);
					MnuPrtLn(38,12,0,3,0);
					RevLn = 0;
					break;
				}	
		
				case 1:
				{
					MnuPrtLn(38,12,0,3,1);
					if (RevLn == 0)
					{
						MnuPrtLn(37,16,0,2,0);
					}
					else
					{
						MnuPrtLn(39,16,0,4,0);
					}
					RevLn = 1;
					break;		
				}
		
				case 2:
				{
					MnuPrtLn(39,16,0,4,1);
					if (RevLn == 1)
					{
						MnuPrtLn(38,12,0,3,0);
					}
					else
					{
						MnuPrtLn(40,18,0,5,0);
					}
					RevLn = 2;
					break;		
				}

				case 3:
				{
					MnuPrtLn(40,18,0,5,1);
					if (RevLn == 2)
					{
						MnuPrtLn(39,16,0,4,0);
					}
					else
					{
						MnuPrtLn(6,14,0,6,0);
					}
					RevLn = 3;
					break;
				}	
				case 4:
				{
					MnuPrtLn(6,14,0,6,1);
					MnuPrtLn(40,18,0,5,0);
					RevLn = 4;
					break;		
				}
			}					
			
		}
	}
	/* **************************************************
	   PRESS BUTTON PART
	************************************************** */
	if (ReslSWup)
	{
		ReslSWup = 0;
		if (MPg.0)
		{
			MnuMaintInit();
			upcntr = 0;
		}
		else if (MPg.1)		//Menu Calibre I
		{
			switch (upcntr)
			{
				case 0:		//Calibre I Charge
				{
					OpsCode = 11;
					break;
				}
				case 1:		//Calibre I Decharge
				{
					OpsCode = 12;
					break;
				}
				case 2:
				{
					OpsCode = 0;
					MenuInit();
					break;	
				}	
			}	
		}
/*		else if (MPg.2)
		{	
			
		}
*/			
		else if (MPg.3)	
		{
			switch (upcntr)
			{
				case 0:		//chargement texte
				{
					OpsCode = 30;
					break;
				}
				case 1:		//contraste
				{
					OpsCode = 31;
					break;
				}
				case 2:		//calibre v
				{
					MPg = 0;
					MPg.5 = 1;
					LCDK_Cls(0);
					GetText(41,0,12,1);
					LCDK_PrintLine(FONT8X8,0,0,0);
					MnuPrtLn(37,16,0,2,1);
					MnuPrtLn(38,12,0,3,0);
					MnuPrtLn(39,16,0,4,0);
					MnuPrtLn(40,18,0,5,0);
					MnuPrtLn(6,14,0,6,0);
					upcntr = 0;
					Rotsv = 0;
					RevLn = 0;
					break;
				}
				case 3:		//calibre i
				{
					MPg = 0;
					MPg.1 = 1;
					LCDK_Cls(0);
					GetText(74,0,12,1);
					LCDK_PrintLine(FONT8X8,0,0,0);
					MnuPrtLn(72,16,0,2,1);
					MnuPrtLn(73,16,0,3,0);
					MnuPrtLn(6,14,0,4,0);
					upcntr = 0;
					Rotsv = 0;
					RevLn = 0;	
					break;
				}
				case 4:		//Controle adc
				{
					OpsCode = 34;
					break;
				}	
				case 5:		//test hard
				{
					MPg = 0;
					MPg.4 = 1;
					LCDK_Cls(0);
					GetText(18,0,14,1);
					LCDK_PrintLine(FONT8X8,0,0,0);
					MnuPrtLn(19,11,0,2,1);
					MnuPrtLn(20,15,0,3,0);
					MnuPrtLn(21,16,0,4,0);
					MnuPrtLn(22,11,0,5,0);
					MnuPrtLn(23,6,0,6,0);
					MnuPrtLn(6,14,0,7,0);
					upcntr = 0;
					Rotsv = 0;
					RevLn = 0;
					break;
				}				
				case 6:		//retour
				{
					OpsCode = 0;
					MenuInit();
					break;
				}		
					
			}	
		}
		else if (MPg.4)		//tests hardware
		{
			switch (upcntr)
			{
				case 0:		//Test alim boost
				{
					OpsCode = 40;
					break;
				}
				case 1:		//Test I Charge
				{
					OpsCode = 41;
					break;
				}
				case 2:		//Test I Dischrg
				{
					OpsCode = 42;
					break;
				}
				case 3:		//Test Balancer
				{
					OpsCode = 43;
					break;
				}
				case 4:
				{
					OpsCode = 44;	//test beeper
					break;
				}	
				case 5:		//return
				{
					OpsCode = 0;
					MenuInit();
					break;
				}	
			}		
		}	
		else if (MPg.5)
		{
			switch (upcntr)
			{
				case 0:		//Calibr balancer
				{
					OpsCode = 51;
					break;
				}
				case 1:		//Calibre Alim
				{
					OpsCode = 52;
					break;
				}
				case 2:		//Calibre V Charge
				{
					OpsCode = 53;
					break;
				}
				case 3:		//Calibre Vbattery
				{
					OpsCode = 54;
					break;
				}
				case 4:		//return main
				{
					OpsCode = 0;
					MenuInit();
					break;
				}	

			}						
		}
	}
	ReslSWup = 0;	
}

