﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LipoCompute
{
    public partial class ABase : Form
    {
        public ABase()
        {
            InitializeComponent();
            Demarrer();
        }

        private void quitterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Quitter();
        }

        private void chargerFichierToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GetRecord();
            Upload();
            Format();
            FichierCh = true;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void replayToolStripMenuItem_Click(object sender, EventArgs e)
        {
           textBox1.Visible= false;
            groupBox1.Visible = true;
            Replay();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            groupBox1.Visible = false;
            textBox1.Visible= true;
            scan = false;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timeout = true;
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged_1(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            bool vld = false;

            vld = int.TryParse(textBox2.Text, out PosLgn);
            if (!vld)
            {
                MessageBox.Show("CARACTERES NULMERIQUES UNIQUEMENT", "Re-ESSAYER", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);

            }
            else
            {
                if ((PosLgn < NbrLines) && (PosLgn > 0))
                {
                    scan = false;
 //                   while (!Fscan)
 //                    { 
 //                        Refr();
 //                    }
                    DispP(PosLgn-1);
                }
                else
                   MessageBox.Show("DEBORDEMENT", "Re-ESSAYER", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (scanlgn == (NbrLines-1))
            Replay();
        }

        private void analyserToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form f2  = new DatAnalyze();  
            f2.ShowDialog();
        }
    }
}
