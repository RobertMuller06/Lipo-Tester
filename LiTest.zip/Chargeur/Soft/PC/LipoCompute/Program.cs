﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Drawing.Imaging;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LipoCompute
{
    internal static class Program
    {
        /// <summary>
        /// Point d'entrée principal de l'application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new ABase());
        }
    }
    public partial class ABase : Form
    {

        const int MaxEch = 1000;
        public string Filename;
        public string[] Dati = new string[MaxEch];
        public static int NbrLines;
        public static string[] Token = new string[MaxEch];
        public int[] Serial = new int[MaxEch];
        public static int[] Ech = new int[MaxEch];
        public static int NbrElem;
        public static int[] LocMin = new int[MaxEch];
        public static int[] sec = new int[MaxEch];
        public static int[] BatV = new int[MaxEch];
        public static int[] cumul = new int[MaxEch];
        public static int[] Ich = new int[MaxEch];
        public static int[] Idc = new int[MaxEch];
        public static int[,] BalV = new int[6, MaxEch];
        public static int[] Temper = new int[MaxEch];
        public static int[] Vchrg = new int[MaxEch];
        public int PosLgn;
        bool timeout,scan,scompl,FichierCh,Fscan;
        public int scanlgn; 

        void Refr()
        {
            Application.DoEvents(); 
        }
        void Demarrer()
        {
            groupBox1.Visible = false;

            label4.Text = "0000";
            label6.Text = "0000";
            label7.Text = "";
            label11.Text = "";
            label13.Text = "";
            FichierCh = false;
        }
        void Quitter()
        {
            System.Environment.Exit(0);
        }
        private void GetRecord()
        {
            openFileDialog1.Filter = "All Files|*.*";
            openFileDialog1.Title = "Fichier Source";
            //openFileDialog1.InitialDirectory = filePath;
            openFileDialog1.FileName = "";
            openFileDialog1.ShowDialog();
            Filename = openFileDialog1.FileName;
            openFileDialog1.Dispose();

        }
        public void Upload()
        {
            bool Abort;
            int i=0;

            NbrLines = 0;
            Abort = !File.Exists(Filename);
            if (Abort == true)
            {
                var a = MessageBox.Show("FICHER INCONNU", "ABANDONNER", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);
            }
            else
            {
              
                foreach (string rdline in System.IO.File.ReadLines(Filename))
                {
                    if (rdline.Length > 10)
                    {
                        Dati[NbrLines] = rdline + Environment.NewLine;
                        
                        NbrLines++;
                    }
                }
            }
            for (i = 0; i != NbrLines; i++)
            {
                textBox1.Text += Dati[i];
                label1.Text = "Nbr Lignes : " + NbrLines.ToString();
            }
        }
        private void DispP(int i)
        {
            int j;
            int mode;

            mode = 0;
 
            if (Token[i] == "M")
            {
                label2.Text = "MESURE";
            }
            if (Token[i] == "C")
            {
                label2.Text = "LIPO CHARGE";
                mode = 0;
            }
            if (Token[i] == "D")
            {
                label2.Text = "LIPO DECHARGE";
                mode = 1;
            }
            if (mode == 0)
            {
                label4.Text = Ich[1].ToString("00,000") + " A";
            }
            label6.Text = BatV[1].ToString("00,000") + " V";
            label7.Text = "";
            for (j = 0; j != 3; j++)
            {
                label7.Text += BalV[j, i].ToString("0,000") + "V   ";
            }
            label8.Text = "";
            for (j = 3; j != 6; j++)
            {
                label8.Text += BalV[j, i].ToString("0,000") + "V   ";
            }
            label13.Text = Serial[i].ToString();
            label11.Text = Vchrg[i].ToString("00,000") + "V";
            label14.Text = LocMin[i].ToString("000")+":" +sec[i].ToString("00");
            label1.Text = "No de ligne : " + (i + 1).ToString();
        }
        private void Format()
        {
            string tps;
            int i,j,k;
            //char tk;
            tps = Dati[1].Substring(8, 1);
            NbrElem = int.Parse(tps);
            for (i = 0; i != NbrLines; i++)
            {
                Token[i] = Dati[i].Substring(0, 1);
                tps = Dati[i].Substring(2, 5);
                Serial[i] = int.Parse(tps);
                tps = Dati[i].Substring(8, 1);
                NbrElem = int.Parse(tps);
                tps = Dati[i].Substring(10, 3);
                LocMin[i] = int.Parse(tps);
                tps = Dati[i].Substring(14, 3);
                sec[i] = int.Parse(tps);
                tps = Dati[i].Substring(20, 5);
                BatV[i] = int.Parse(tps);
                tps = Dati[i].Substring(26, 9);
                cumul[i] = int.Parse(tps);
                tps = Dati[i].Substring(36, 5);
                Ich[i] = int.Parse(tps);
                tps = Dati[i].Substring(42, 5);
                Idc[i] = int.Parse(tps);
                k = 48;
                for (j = 0; j != 6; j++)
                {
                    tps = Dati[i].Substring(k, 4);
                    BalV[j, i] = int.Parse(tps);
                    k += 5;
                }
                tps = Dati[i].Substring(78, 3);
                Temper[i] = int.Parse(tps);
                tps = Dati[i].Substring(82, 5);
                Vchrg[i] = int.Parse(tps);
            }
        }
        void Replay()
        {
            int i,j;
        
            scan = true;
            Fscan = false;
 
            for (i=0;i!=NbrLines;i++)
            {
                scanlgn = i;
                scompl = false; 
                timeout = false;
                timer1.Interval = 1000;
                timer1.Enabled = true;
                while (timeout == false)
                {
                    Refr();
                }
                timer1.Enabled=false;  
                DispP(i);
                if (scan == false) 
                {
                    break;
                }
                if (scanlgn != i) i = scanlgn;
                {
                    scompl = true;
                }   
            }
            Fscan = true;
        }
    }
}
