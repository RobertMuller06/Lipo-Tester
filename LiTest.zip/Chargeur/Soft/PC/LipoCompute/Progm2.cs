﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Drawing.Imaging;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using System.Windows.Forms.DataVisualization.Charting;

namespace LipoCompute
{

    public partial class DatAnalyze : Form
    {

        const int MaxEch = 1000;
        public string Filename;
        public int NbrElem;
        public string[] Token = new string[MaxEch];
        public int[] LocMin = new int[MaxEch];
        public int[] sec = new int[MaxEch];
        public int[] MBatV = new int[MaxEch];
        public int[] CBatV = new int[MaxEch];
        public int[] cumul = new int[MaxEch];
        public int[] MIch = new int[MaxEch];
        public int[] MIdc = new int[MaxEch];
        public int[,] MBalV = new int[6, MaxEch];
        public int[] CIch = new int[MaxEch];
        public int[] CIdc = new int[MaxEch];
        public int[,] CBalV = new int[6, MaxEch];
        public int[] Temper = new int[MaxEch];
        public int[] Vchrg = new int[MaxEch];
        public int j;

        private void   ShowVolt ()
        {
             int inf,i,tp;
            int calc;
            string wrline;

  
            inf = ABase.NbrLines;
            label1.Text = "TENSION EQUILIBREUR EN mV";
            chartA.Series.Clear();
            Series series1 = chartA.Series.Add("E1");
            Series series2 = chartA.Series.Add("E2");
            Series series3 = chartA.Series.Add("E3");
            Series series4 = chartA.Series.Add("E4");
            Series series5 = chartA.Series.Add("E5");
            Series series6 = chartA.Series.Add("E6");
            //series1.Color = Color.Blue;
            //series2.Color = Color.LimeGreen;
            series1.ChartType = SeriesChartType.Spline;
            series2.ChartType = SeriesChartType.Spline;
            series3.ChartType = SeriesChartType.Spline;
            series4.ChartType = SeriesChartType.Spline;
            series5.ChartType = SeriesChartType.Spline;
            series6.ChartType = SeriesChartType.Spline;
            for (i = 0; i < inf ; i+=2)
            {
                tp = ABase.LocMin[i] * 60 + ABase.sec[i];
                wrline = tp.ToString() ;
                //fcalc = ICharger.tbl[6, i] + ICharger.tbl[5, i] * 60 + ICharger.tbl[4, i] * 3600;
                //fcalc1 = fcalc;
                calc = ABase.BalV[0, i];
                series1.Points.AddXY(wrline,calc);
                calc = ABase.BalV[1, i];
                //val = calc / 1000;
                series2.Points.AddXY(wrline,calc);
                calc = ABase.BalV[2, i];
                //val = calc / 1000;
                series3.Points.AddXY(wrline, calc);
            }
        }
        private void ShowRes()
        {
            int inf, i, tp;
            float calc1,calc2,cur;
            string wrline;

            inf = ABase.NbrLines;
            label1.Text = "RESISTANCE ELEMENTS en mOhms";
            chartA.Series.Clear();
            Series series1 = chartA.Series.Add("E1");
            Series series2 = chartA.Series.Add("E2");
            Series series3 = chartA.Series.Add("E3");
            Series series4 = chartA.Series.Add("E4");
            Series series5 = chartA.Series.Add("E5");
            Series series6 = chartA.Series.Add("E6");
            //series1.Color = Color.Blue;
            //series2.Color = Color.LimeGreen;
            series1.ChartType = SeriesChartType.Spline;
            series2.ChartType = SeriesChartType.Spline;
            series3.ChartType = SeriesChartType.Spline;
            series4.ChartType = SeriesChartType.Spline;
            series5.ChartType = SeriesChartType.Spline;
            series6.ChartType = SeriesChartType.Spline;
            for (i = 0; i < inf; i += 2)
            {
                tp = ABase.LocMin[i] * 60 + ABase.sec[i];
                wrline = tp.ToString();
                //fcalc = ICharger.tbl[6, i] + ICharger.tbl[5, i] * 60 + ICharger.tbl[4, i] * 3600;
                cur = ABase.Ich[i + 1];
                calc1 = ABase.BalV[0, i];
                calc2 = ABase.BalV[0, i + 1];
                calc1 = ((calc2 - calc1) / cur) * 1000;
                series1.Points.AddXY(wrline, calc1);
                if (ABase.NbrElem > 1)
                {
                    calc1 = ABase.BalV[1, i];
                    calc2 = ABase.BalV[1, i + 1];
                    calc1 = ((calc2 - calc1)*1000) / cur;
                    series2.Points.AddXY(wrline, calc1);
                }
                if (ABase.NbrElem > 2)
                {  
                calc1 = ABase.BalV[2, i];
                calc2 = ABase.BalV[2, i + 1];
                calc1 = ((calc2 - calc1)*1000) / cur;
                series3.Points.AddXY(wrline, calc1);
                }
                if (ABase.NbrElem > 3)
                {
                    calc1 = ABase.BalV[3, i];
                    calc2 = ABase.BalV[3, i + 1];
                    calc1 = ((calc2 - calc1) * 1000) / cur;
                    series4.Points.AddXY(wrline, calc1);
                }
                if (ABase.NbrElem > 4)
                {
                    calc1 = ABase.BalV[4, i];
                    calc2 = ABase.BalV[4, i + 1];
                    calc1 = ((calc2 - calc1)*1000) / cur;
                    series5.Points.AddXY(wrline, calc1);
                }
                if (ABase.NbrElem > 5)
                {
                    calc1 = ABase.BalV[5, i];
                    calc2 = ABase.BalV[5, i + 1];
                    calc1 = ((calc2 - calc1)*1000) / cur;
                    series6.Points.AddXY(wrline, calc1);
                }

            }
        }
    }

}