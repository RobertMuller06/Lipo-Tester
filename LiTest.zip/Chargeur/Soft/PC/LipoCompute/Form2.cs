﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LipoCompute
{
    public partial class DatAnalyze : Form
    {
        public DatAnalyze()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ShowVolt();
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ShowRes();
        }
    }
}
