﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Net;
using System.Diagnostics;
//using static System.Net.WebRequestMethods;

namespace LipoAnalyzer
{
    public partial class LipoAnalyser : Form
    {
        public LipoAnalyser()
        {
            InitializeComponent();
            Demarrer();
        }

        private void quitterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Quitter();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1flg++;
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            timer2flg++;
        }

        private void selectionComToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox1.Visible = false;
            listBox1.Show();
            refr();
            initport();
            initdialog();
            textBox1.Visible=true;
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            Closeserial();
            listBox1.Visible = false;
            PortCom = (string)listBox1.SelectedItem;
            ioinit();
            label1.Text = "Pas de connection" + Environment.NewLine + PortCom+"... Attente";
     
        }

        private void connectionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ok = 0;
            recon();
            StopSerial = false;
            Getdatas();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ok = 0;
            recon();
            StopSerial = false;
            Getdatas();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ok = 1;
            Closeserial();
            StopSerial = true;
            
        }

        private void toolStripStatusLabel3_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Visible = false;
            listBox1.Show();
            refr();
            initport();
            initdialog();
            textBox1.Visible = true;
        }

        private void chargerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bool Abort;
         
            GetRecord();
            this.Text = "Lipo Analyser : " + File_NameG;
            string fileWExt = Path.GetFileNameWithoutExtension(File_NameG);
            toolStripStatusLabel1.Text = fileWExt;
            Abort = !File.Exists(File_NameG);
            if (Abort == true)
            {
                var a = MessageBox.Show("FICHER INCONNU", "ABANDONNER", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);
            }
            else Upload();
        }

        private void sauverToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveRecord();
            System.IO.StreamWriter fr1 = new System.IO.StreamWriter(File_NameS);
            fr1.WriteLine(textBox1.Text);
            fr1.Flush();
            fr1.Close();
            fr1.Dispose();
            this.Text= "Lipo Analyser : "+File_NameS;
            fileWExt = Path.GetFileNameWithoutExtension(File_NameS);
            filePath = Path.GetDirectoryName(File_NameS);
            toolStripStatusLabel1.Text = fileWExt;
        }

        private void FLipoAnalyser_Load(object sender, EventArgs e)
        {

        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }

        private void analyserToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start(new ProcessStartInfo("notepad.exe"));
        }
    }
}
