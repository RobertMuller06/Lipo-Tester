﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing.Imaging;
using System.IO;
using System.IO.Ports;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.LinkLabel;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace LipoAnalyzer
{
    internal static class Program
    {
        /// <summary>
        /// Point d'entrée principal de l'application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new LipoAnalyser());
        }
    }
    public partial class LipoAnalyser
    {
        public static byte ComP;
        public static string Proc;
        public static byte[] tx = new byte[66];
        public static byte comport;
        public static string PortCom, SPortCom;
        public static int waitdat;
        public static string Start_Path;
        public static string File_NameG, File_NameS,File_NameIS,File_NameIL;
        public static string File_Path;
        public static string File_Complete;
        public static uint File_handle;
        public static string fileWExt;
        public static string filePath;
        public static byte[] indata = new byte[65536 + 4];
        public static UInt16[] inofs = new UInt16[65536 + 4];
        public static byte[] errdump = new byte[6];
        public static int Maxi;
        public static byte Datasent;
        public static byte Errcount;
        public static byte timer1flg = 0;
        public static byte timer2flg = 0;
        public static byte Etatsrl;
        public static bool Offline = true;
        public static bool errinit = false;
        public static byte MDebug;
        public static byte IdxComPort;
        public static string[] Nport = new string[21];
        public static byte vp;
        public static bool FileLoaded = false, nodataflg = true;
        public static int FCap;
        public static bool Verif;
        public static int scount = 1;
        public static Boolean ComisInit;
        public static Boolean HBaud;
        public static byte rx;
        byte ok = 0;
        public bool StopSerial, SaveOk, exttype;


        private static void refr()
        {
            Application.DoEvents();
        }

        private void Quitter()
        {
            Closeserial();
            File_NameIS = Start_Path + "LipoIn.ini";
            System.IO.StreamWriter fr1 = new System.IO.StreamWriter(File_NameIS);
            if (filePath == "") filePath = Start_Path;
            File_NameS += Environment.NewLine;
            fr1.WriteLine(filePath);
            fr1.Flush();
            fr1.Close();
            fr1.Dispose();
            System.Environment.Exit(0);
        }

        private void Demarrer()
        {
            bool Abort;

            listBox1.Visible = false;
            Start_Path = Application.StartupPath + "\\";
            toolStripStatusLabel2.Text = "Sélection Com ?";
            toolStripStatusLabel3.Text = "";
            textBox1.Text = "";
            File_NameIL = Start_Path + "LipoIn.ini";
            Abort = !File.Exists(File_NameIL);
            if (Abort == true)
            {
                File_Path=Start_Path;
            }
            else
            {
                foreach (string rdline in System.IO.File.ReadLines(File_NameIL))
                {
                    filePath = rdline;
                }
            }
        }
        private void initport()
        {
            IdxComPort = 0;
            string por = null;
            string[] prt = SerialPort.GetPortNames();
            foreach (string prt_lp in prt)
            {
                por = prt_lp;
                Nport[IdxComPort] = por;
                IdxComPort += 1;
            }

        }
        private void initdialog()
        {
            int i1 = 0;
            int[] tx = new int[2];
            string tp = null;

            toolStripStatusLabel3.Text = "Pas de  Connexion";
            timer1.Enabled = false;
            timer2flg = 0;
            listBox1.Items.Clear();
            if (IdxComPort != 0)
            {
                for (i1 = 0; i1 <= IdxComPort - 1; i1++)
                {
                    tp = Nport[i1];
                    listBox1.Items.Add(tp);
                }
            }
            else
            {
                listBox1.Items.Add("No Srl");
            }
        }
        private void GetRecord()
        {
            openFileDialog1.Filter = "All Files|*.*";
            openFileDialog1.Title = "Fichier Source";
            openFileDialog1.InitialDirectory = filePath;
            openFileDialog1.FileName = "";
            openFileDialog1.ShowDialog();
            File_NameG = openFileDialog1.FileName;
            openFileDialog1.Dispose();
            

        }
        private void SaveRecord()
        {
            SaveOk = false;
            saveFileDialog1.Filter = "Save File |*.*";
            saveFileDialog1.DefaultExt = "capt";
            saveFileDialog1.Title = "Fichier Destination";
            saveFileDialog1.InitialDirectory = filePath;
            saveFileDialog1.FileName = "";
            File_NameS = saveFileDialog1.FileName;
            File_Path = File_NameS;
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                SaveOk = true;
                File_NameS = saveFileDialog1.FileName;
            }
            else SaveOk = false;
            saveFileDialog1.Dispose();
        }
        public void Upload()
        {
            bool Abort;

            textBox1.Text = "";
            Abort = !File.Exists(File_NameG);
            if (Abort == true)
            {
                var a = MessageBox.Show("FICHER INCONNU", "ABANDONNER", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);
            }
            else
            {
                exttype = false;
                foreach (string rdline in System.IO.File.ReadLines(File_NameG))
                {
                    textBox1.Text += rdline + Environment.NewLine; ;
                }
            }

        }
        public void ioinit()
        {
            try
            {
                serialPort1.Dispose();
            }
            catch
            {

            }
            serialPort1 = new SerialPort(PortCom);
            // next is srl config is
            //    serialPort1.BaudRate = 19200;
            //serialPort1.Parity = Parity.None;
            //serialPort1.DataBits = 8;
            //serialPort1.Handshake = Handshake.None;
            // Set the read/write timeouts
            serialPort1.ReadTimeout = 40;
            serialPort1.WriteTimeout = 40;
            try
            {
                serialPort1.Open();
            }
            catch (IOException e)
            {
                MessageBox.Show("Problème Connexion " + PortCom, "ERREUR MATERIEL", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                serialPort1.Dispose();
                //Quitter();
            }
            Read();
        }
        private void Closeserial()
        {
            try
            {
                if (serialPort1.IsOpen == true)
                {
                    serialPort1.Close();
                    serialPort1.Dispose();
                }
            }
            catch (IOException)
            {
                MessageBox.Show("Problème Connexion " + PortCom, "ERREUR MATERIEL", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

            toolStripStatusLabel3.Text = "Deconnecté";
            toolStripStatusLabel3.BackColor = System.Drawing.Color.Blue;
            toolStripStatusLabel3.ForeColor = System.Drawing.Color.Yellow;

        }
        public void Read()
        {
            if ((IdxComPort != 0) && (serialPort1 != null))
            {
                try
                {
                    nodataflg = false;
                    rx = (byte)serialPort1.ReadByte();
                }
                catch (Exception)
                {
                    nodataflg = true;
                }
            }
        }
        public void wrt()
        {
            if (!(serialPort1.IsOpen))
            {
                serialPort1.Open();
            }
            try

            {
                serialPort1.Write(tx, 0, scount);
            }
            catch (Exception)
            { }

        }
        private void recon()
        {
            int I1;
            //int i;
            I1 = 1;

            FCap = 0;
            //for debug

            if (IdxComPort != 0)
            {
                toolStripStatusLabel3.Text = "Essai Connexion";
                toolStripStatusLabel3.BackColor = System.Drawing.Color.Yellow;
                while (ok == 0)
                {
                    timer2flg = 0;
                    this.label1.Text = "Essais de Connection" + Environment.NewLine + I1.ToString();
                    Etatsrl = 2;

                    scount = 4;
                    tx[0] = (byte)'R';           // "R" ascii  // RM ident this project output data
                    tx[1] = (byte)'M';           // "M"
                    tx[2] = (byte)'a';           // "a" ascii   // ident analyze
                    tx[3] = (byte)'n';           // "n"
                    wrt();                //output data

                    Etatsrl = 0;
                    rx = 0;
                    timer2flg = 0;
                    timer2.Interval = 1000;
                    timer2.Enabled = true;
                    timer1flg = 0;
                    timer1.Interval = 50;   // timeout to wait rcv data
                    timer1.Enabled = true;
                    while (timer1flg == 0)
                    {
                        refr();
                    }
                    timer1.Enabled = false;
                    //Read(); // first byte is nbr of bytes
                    Read();
                    if (rx == (byte)'a')   // "a+n" ascii confirms handskake
                    {

                        Read();
                        if (rx == (byte)'n')
                        {
                            Etatsrl = 1;
                            ok = 1;
                            toolStripStatusLabel3.Text = "En Dialogue";
                            toolStripStatusLabel3.BackColor = System.Drawing.Color.Green;

                            this.label1.Text = "CONNECTE";
                            timer2.Enabled = false;
                            Read();
                        }
                    }
                    if (ok == 0)
                    {
                        while (timer2flg == 0)
                        {
                            refr();
                        }
                        timer2.Enabled = false;
                        I1 += 1;
                    }
                }

                toolStripStatusLabel2.Text = PortCom;
            }
            else
            {
                toolStripStatusLabel2.Text = "Err Com Port";
                MessageBox.Show("Pas de Port Serie", "ERREUR MATERIEL", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }
        private void Getdatas()
        {
            bool flg;
            char token;
            string rline;
            int i,calc1,calc2;

            label1.Text = "Collecte Données";
            textBox1.Text = "";
            tx[0] = (byte)10;
            tx[1] = (byte)20;
            scount = 2;
            //wrt();
            flg = false;
            rline = "";
            while (StopSerial == false)
            {
                calc2 = 0;
                calc1 = 0;
                while ((rx != 0x0A) && (StopSerial == false))
                {
                    Read();
                    refr();
                }
                flg = false;
                for (i = 1; i != 34; i++)
                {
                    Read();
                    refr();
                    if (i == 1)
                    {
                        token = (char)rx;
                        rline = token.ToString();
                        label2.Text = rline;
                        rline += ";";
                        if (token == 'T')
                        {
                            StopSerial = true;
                            break;
                        }
                    }
                    if (i == 33) flg = true;
  
                    if (i == 2)     // nb sample
                    {
                        flg = false;
                        calc1 = rx * 256;
                    }
                    if (i == 3)
                    {
                        flg = true;
                        calc2 = rx;
                        calc1 += calc2;
                        rline += calc1.ToString("d5");
                        rline += ";";
                    }
                    if (i == 4)     //nb elements
                    {
                        rline += rx.ToString("d1");
                        rline += ";";
                    }
                    if (i == 5)        //time, mins
                    {
                        flg = false;
                        calc2 = rx * 256;
                    }
                    if (i == 6)
                    {
                        flg = false;
                        calc1 = rx;
                        calc1 += calc2;
                        rline += calc1.ToString("d3");
                        rline += ";";
                    }
                    if (i==7)       //time seconds
                    {
                        rline += rx.ToString("d3");
                        rline += ";";
                    }
                    if (i == 8)     //= sign
                    {
                        token = (char)rx;
                        rline += token.ToString();
                        rline += ";";
                    }
                    if (i == 9)     //bat voltage
                    {
                        calc2 = rx * 256;
                    }
                    if (i == 10)
                    {
                        calc1 = rx + calc2;
                        rline += calc1.ToString("d5");
                        rline += ";";
                    }
                    if (i == 11)        //current total in mA
                    {
                        calc2 = rx * 16777216; ;
                    }
                    if (i == 12)
                    {
                        calc1 = rx * 65536;
                        calc2 += calc1;
                    }
                    if (i == 13)
                    {
                        calc1 = rx * 256;
                        calc2 += calc1;
                    }
                    if (i == 14)
                    {
                        calc1 = rx;
                        calc1 += calc2;
                        rline += calc1.ToString("d9");
                        rline += ";";
                    }    
                    if (i == 15)        //i charge
                    {
                        calc2 = rx * 256;
                    }
                    if (i == 16)
                    {

                        calc1 = rx +calc2;
                        rline += calc1.ToString("d5");
                        rline += ";";
                    }
                    if (i == 17)        //i dischrg
                    {
                        calc2 = rx * 256;
                    }
                    if (i == 18)
                    {

                        calc1 = rx + calc2;
                        rline += calc1.ToString("d5");
                        rline += ";";
                    }
                    if (i == 19)        //V bal 1
                    {
                        calc2 = rx * 256;
                    }
                    if (i == 20)
                    {

                        calc1 = rx + calc2;
                        rline += calc1.ToString("d4");
                        rline += ";";
                    }
                    if (i == 21)        //V bal 2
                    {
                        calc2 = rx * 256;
                    }
                    if (i == 22)
                    {

                        calc1 = rx + calc2;
                        rline += calc1.ToString("d4");
                        rline += ";";
                    }
                    if (i == 23)        //V bal 3
                    {
                        calc2 = rx * 256;
                    }
                    if (i == 24)
                    {
                        calc1 = rx + calc2;
                        rline += calc1.ToString("d4");
                        rline += ";";
                    }
                    if (i == 25)        //V bal 4
                    {
                        calc2 = rx * 256;
                    }
                    if (i == 26)
                    {

                        calc1 = rx + calc2;
                        rline += calc1.ToString("d4");
                        rline += ";";
                    }
                    if (i == 27)        //V bal 5
                    {
                        calc2 = rx * 256;
                    }
                    if (i == 28)
                    {

                        calc1 = rx + calc2;
                        rline += calc1.ToString("d4");
                        rline += ";";
                    }
                    if (i == 29)        //V bal 6
                    {
                        calc2 = rx * 256;
                    }
                    if (i == 30)
                    {

                        calc1 = rx + calc2;
                        rline += calc1.ToString("d4");
                        rline += ";";
                    }
                    if (i == 31)        //Temperature
                    {
                        rline += rx.ToString("d3");
                        rline += ";";
                    }
                    if (i == 32)        //V alim charge
                    {
                        calc2 = rx * 256;
                    }
                    if (i == 33)
                    {

                        calc1 = rx + calc2;
                        rline += calc1.ToString("d4");
                    }
                }
                if (flg == true)
                {
                    textBox1.Text += rline + Environment.NewLine;
                    rline = "";
                }  
            }
            label1.Text = "Repos";
            Closeserial();
        }
    }
}
