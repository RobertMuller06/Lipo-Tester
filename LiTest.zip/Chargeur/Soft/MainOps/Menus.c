/* Menus */
char MPg ;
char RevLn,OpsCode;
char Rotsv ;
bit refr;

void MnuPrtLn (char Msg, char len, char x, char y,bit rev)
{
	char i;
	i = GetText(Msg,0,len,0);
	if (len != 255) txt[len] = 0;
	LCDK_PrintLine(FONT6X8,x,y,rev);	
}
	
void MenuInit (void)
{
	InitRotary ();
	LCDK_Cls(0);
	GetText(6,0,14,1);
	LCDK_PrintLine(FONT8X8,0,0,0);
	LCDK_DrawLine (0,11,127,11);
	GetText(7,0,9,0);
	LCDK_PrintLine(FONT6X8,0,2,1);
	GetText(8,0,11,0);
	LCDK_PrintLine(FONT6X8,0,3,0);
	GetText(9,0,13,0);
	LCDK_PrintLine(FONT6X8,0,4,0);
	MnuPrtLn(14,13,0,5,0);
	//if (FullMenu)		//uncomment for prod
	MnuPrtLn(13,12,0,6,0);
	MPg = 0;
	MPg.0 = 1;
	RevLn = 0;
	ReslSWup = 0;
	upcntr = 0;
	upmoins = 0;
	Rotsv = 0;
	LED3_Off;
}

void DischrgInit(void)
{
	upplus = 4;
	upcntr = 0;
	RevLn = 0;
	MPg = 0;
	MPg.3 = 1;
	LCDK_Cls(0);
	GetText(9,0,11,1);
	LCDK_PrintLine(FONT8X8,0,0,0);
	MnuPrtLn(77,12,0,2,1);
	MnuPrtLn(78,11,0,3,0);
	MnuPrtLn(79,15,0,4,0);
	MnuPrtLn(80,18,0,5,0);
	MnuPrtLn(6,14,0,6,0);
	OpsCode = 3;	
}
 	
void Menu (void)
{
	refr = 0;
	upmoins = 0;
	if (Rotsv > upcntr)
	{
		Rotsv --;
		upcntr = Rotsv;
		refr = 1;
	}
	if (upcntr > Rotsv)
	{
		Rotsv++;
		upcntr = Rotsv;
		refr = 1;
	}		
	
	/* *****************************************************
			ROTATION PART
	****************************************************** */
	if (refr)
	{
		if (MPg.0)
		{
			upmoins = 0;
			upplus = 4;		//change to 3 for production soft
			if (FullMenu) upplus = 4;
			
			switch (upcntr)
			{
				case 0:
				{
					MnuPrtLn(7,9,0,2,1);	//test
					MnuPrtLn(8,11,0,3,0);	//chrg
					RevLn = 0;
					break;
				}
				case 1:
				{
					MnuPrtLn(8,11,0,3,1);	
					if (RevLn == 0)
					{
						MnuPrtLn(7,9,0,2,0);
					}
					else
					{
						MnuPrtLn(9,13,0,4,0);
					}
					RevLn = 1;
					break;		
				}
				case 2:		//disch
				{
					MnuPrtLn(9,13,0,4,1);	
					if (RevLn == 1)
					{
						MnuPrtLn(8,11,0,3,0);
					}
					else
					{
						MnuPrtLn(14,13,0,5,0);
					}
					RevLn = 2;
					break;		
				}
				case 3:		//Contrast
				{
	
					MnuPrtLn(14,13,0,5,1);	
					if (RevLn == 2)
					{
						MnuPrtLn(9,13,0,4,0);
					}
					else
					{
						MnuPrtLn(13,12,0,6,0);
					}
					RevLn = 3;
					break;		
				}
				case 4:		//Charge txt
				{
					MnuPrtLn(13,12,0,6,1);
					MnuPrtLn(14,13,0,5,0);
					RevLn = 4;
					break;		
				}	

			}	
		}			
		else if (MPg.1)		//Lipo test
		{
					
		}
		else if (MPg.2)		//Lipo Charge
		{
			
		}			
		else if (MPg.3)		//Lipo Discharge
		{
			upplus = 4;
			switch (upcntr)
			{
				case 0:
				{
					MnuPrtLn(77,12,0,2,1);
					MnuPrtLn(78,11,0,3,0);
					RevLn = 0;
					break;
				}	
				case 1:
				{
					MnuPrtLn(78,11,0,3,1);
					if (RevLn == 0)
					{
						MnuPrtLn(77,12,0,2,0);
					}
					else
					{
						MnuPrtLn(79,15,0,4,0);
					}
					RevLn = 1;
					break;		
				}
				case 2:
				{
					MnuPrtLn(79,15,0,4,1);
					if (RevLn == 1)
					{
						MnuPrtLn(78,11,0,3,0);
					}
					else
					{
						MnuPrtLn(80,18,0,5,0);
					}
					RevLn = 2;
					break;		
				}
				case 3:
				{
					MnuPrtLn(80,18,0,5,1);
					if (RevLn == 2)
					{
						MnuPrtLn(79,15,0,4,0);
					}
					else
					{
						MnuPrtLn(6,14,0,6,0);
					}
					RevLn = 3;
					break;		
				}
				case 4:
				{
					MnuPrtLn(6,14,0,6,1);
					MnuPrtLn(80,18,0,5,0);
					RevLn = 4;
					break;		
				}
			}		
		}
		else if (MPg.4)		//Selection Nbr elems / charging current
		{
			upplus = 4;
			switch (upcntr)
			{
				
			}		
		}	
		else if (MPg.5)		//
		{
			upplus = 4;
			switch (upcntr)
			{
				
			}
		}
	}
	/* **************************************************
	   PRESS BUTTON PART
	************************************************** */
	if (ReslSWup)
	{
		ReslSWup = 0;
		if (MPg.0)
		{
			switch (upcntr)
			{
				case 0:		//test
				{
					
					OpsCode = 1;
					break;
				}
				case 1:		//chrg
				{
					
					OpsCode = 2;
					break;
				}
				case 2:		//dischrg
				{
				
					DischrgInit();
					break;	
				}
				case 3:
				{
					OpsCode = 4;	//contrast
					break;	
				}
				case 4:
				{
					OpsCode = 5;	//chrgtxt
					break;
				}			
			}
		}
		else if (MPg.1)		//Menu Calibre I
		{
			switch (upcntr)
			{
				case 0:		//Calibre I Charge
				{
					OpsCode = 11;
					break;
				}
				case 1:		//Calibre I Decharge
				{
	
					OpsCode = 12;
					break;
				}
				case 2:
				{
					OpsCode = 0;
					MenuInit();
					break;	
				}	
			}	
		}
/*		else if (MPg.2)
		{	
			
		}
*/			
		else if (MPg.3)	
		{
			switch (upcntr)
			{
				case 0:		//Stokage 50%
				{
					ParamSel(2);	
					OpsCode = 30;
					break;
				}
				case 1:		//Decharrge 3V
				{
					ParamSel(2);
					OpsCode = 31;
					break;
				}
				case 2:		//Decharge Totale
				{
					ParamSel(2);
;					OpsCode = 32;
					break;
				}
				case 3:		//Decharge Selective
				{
					ParamSel(3);
					OpsCode = 33;
					break;
				}
				case 4:		//return
				{
					OpsCode = 0;
					MenuInit();
					break;
				}	

					
			}	
		}
		else if (MPg.4)		//chrg/decrg parametres
		{
			switch (upcntr)
			{
				case 0:		//
				{				
					OpsCode = 40;
					break;
				}
				case 1:		//
				{
					OpsCode = 41;
					break;
				}
				case 2:		//
				{
					OpsCode = 42;
					break;
				}
				case 3:		//
				{
					OpsCode = 43;
					break;
				}
				case 4:
				{
					OpsCode = 44;	//
					break;
				}	
				case 5:		//return
				{
					OpsCode = 0;
					MenuInit();
					break;
				}	
			}		
		}	
		else if (MPg.5)
		{
			switch (upcntr)
			{
				case 0:		//Calibr balancer
				{
					OpsCode = 51;
					break;
				}
				case 1:		//Calibre Alim
				{
					OpsCode = 52;
					break;
				}
				case 2:		//Calibre V Charge
				{
					OpsCode = 53;
					break;
				}
				case 3:		//Calibre Vbattery
				{
					OpsCode = 54;
					break;
				}
				case 4:		//return main
				{
					OpsCode = 0;
					MenuInit();
					break;
				}	

			}						
		}
	}
	ReslSWup = 0;	
}

