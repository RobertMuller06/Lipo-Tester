/* Lipo Tester defines and var */
#define Version "V:2.00 "
// ver 0.0 : first try
// ver 1.0 : tests for hardw v 1
// ver 2.0 : New hard, compativble hardw v 2 and v 3
#define Date __DATE2__
#define Hardware "HARD:V3.0"

/****************************************************
           CONFIG (If needed, may be commented)
*****************************************************/

//  CONFIG bits  >> clock intr 16mhz pll x 3

#pragma config [0]  = 0x23	//LS48MHZ=1(48mhz sys clk), CPUDIV =00 (no),CFGPLLEN=0 (oscillator direct),PLLSEL=1(pll x 3)
#pragma config [1]  = 0x08	//IESO=0(no osc switchover),FCMEN=0(no clk failsafe),PCLKEN=0(primary clk can be dis),FOSC=1000(internal)
#pragma config [2]  = 0x0A	//LPBOR=0(BRO rst enab),BORV=01(2.5v),BOREN=01(bro crtrld by soft),PWRTEN=0(pwr up tmr ena)
#pragma config [3]  = 0x3E	//WDTPS=1111(max32768),WDTEN=10(soft ctrld)
#pragma config [4]  = 0		//NU
#pragma config [5]  = 0x91	//MCLRE=1(ext reset),SDOMX=0(SDO on RC7),T3CM=1(T3CKI on RC0),PBADEN=0(ANSELB),CCP2MX=1(CCP2 on RC1)
#pragma config [6]  = 0x81	//DEBUG=1(disable),XINST=0(extended instr dis),ICPRT=0(ICPORT dis),LPV=0(low volt ICSP dis),STRVEN=1(stack ovflow reset)
#pragma config [7]  = 0		//NU
// next part is code protection. No protection used.
#pragma config [8]  = 0x0F	//
#pragma config [9]  = 0xC0	//
#pragma config [10] = 0x0F	//
#pragma config [11] = 0xE0	//
#pragma config [12] = 0x0F	//
#pragma config [13] = 0x40	//

// BootLoader mode
//  ********* uncomment one and only one of the 3 following lines.
#define ResetVector 0x1000
#define HIntVector ResetVector + 0x8
#define LIntVector ResetVector + 0x18

/*******************************************************
              P A R A M E T E R S
***************************************************** */
#define CPUCLK					48		// 48 MHz
#define CYCLK					CPUCLK / 4	// Instruction cycle (only valid if cpu div by 4)	

/*******************************************************
              M A C R O S
***************************************************** */
//soft
#define LCD_Large
#define RotDebounceTmr 5
#define I2CMastInt
#define MaxTones	4
//hard
#define OfsFact 160
//#define LCD_PortInput()		TRISD = 0xFF;
#define LCDKW_CS1				LATA.6	
#define LCDK_RW					LATE.2		
#define LCDKW_CS2				LATA.7	
#define LCDKR_CS1				PORTA.6		
#define LCDKR_CS2				PORTA.7			
#define LCDK_E					LATE.1		 
#define LCDKW_DI				LATE.0
#define LCDKR_DI				PORTE.0	
#define SDOUT					LATB.3
#define SCKL					LATB.2
#define CSPOT1					LATB.6
#define CSPOT2					LATA.5
#define RELAY					LATA.4
#define SW1						PORTC.6
#define LED						LATC.2
#define LED2					LATA.2
#define BLOKIDC					LATB.5
#define BLOKICH					LATB.4
#define SW2						PORTC.7
#define SW3						PORTA.3
#define LED3_On	while (I2C_State !=1);I2Cbufout[0]=3;I2Cbufout[1]=2;I2Cbufout[2]=0;iadr = 6;I2Cout (3,0)
#define LED3_Off while (I2C_State !=1);I2Cbufout[0]=3;I2Cbufout[1]=2;I2Cbufout[2]=1;iadr = 6;I2Cout (3,0)
#define FAN_1 while (I2C_State !=1);I2Cbufout[0]=3;I2Cbufout[1]=4;I2Cbufout[2]=1;iadr = 6;I2Cout (3,0)
#define FAN_0 while (I2C_State !=1);I2Cbufout[0]=3;I2Cbufout[1]=4;I2Cbufout[2]=0;iadr = 6;I2Cout (3,0)
/*******************************************************
              G L O B A L   V A R I A B L E S
***************************************************** */
// real time clock
#pragma rambank -
uns16 ms;
bit timer1,timer2;
uns16 tempoms,tempoms2;
char loctmr;
bit MSFlg,SecFlg;
char sec,min,hour;
char RotaryDebounce;
bit KeyTgl;
char CpyPB,CpyPC;
bit SELA,SELB,SELSW,rochg;
char ioci;
#pragma rambank 1
bit OpsMs,OpsSec;
char un,dix,cent,mil,dmil,dmillion,million,cmil;
char txt[20];
char TxBuf[6];
char RxBuf[6];
char Roldsel,newsel;
char upcntr,dwncntr;
char upplus;
char upmoins;
char lclcnt;
bit oldselA,oldselB,Rselchg,oldselSW,RselSWchg,ReslSWup;
bit I2CLenCtrl;
bit con_up,endtfr,FullMenu;
bit FlgUSB,USBup;
uns16 INVBAT,MESVIN,ADRes;
uns16 VIN;
char NextANP,AdcCalc;

#pragma rambank 2
char NbrElem;
char VPot[4];
uns16 ChrgI,DechrgI;
uns16 EndVolt;
char VContrast;
float32 CoefA[11]; //0..5 = bal,6= idecrg,7= vbat, 8=vchrg,9=ichrg,10=vin
int CoefB[12];
//char DgtPos:
uns16 ADC[10];
// adc 0..5 vbal, 6=idchrg, 7 = vbat, 8= vchrg, 9=ichrg
uns16 BalV[6];
uns16 MaxBal,MinBal;
uns16 BatV,Vchrg,Ich,Idc;
char ADCctr;
char Temper;
uns32 cumul,total;
uns16 LocMin;
//uns16 FreezeVal[10];
char TemperCtr;
bit USBReport,UseUSB,MesFg,NoBalfg;
uns16 Ech,CurOfset;
char ttp,b;
#pragma rambank 1
/*******************************************************
              P R O T O T Y P E S
***************************************************** */
void main (void);
void High_Int (void);
void HandelRotary (void);
void tempo (uns16 durationms,bit locked);
void I2CInt (void);
void USBDriverService(void);
void ADCModule (void);
char readflash (uns16 rfaddr, char nbrdata);
void Panic (char Origin);
void ParamSel(char mode);

/* ***************************************************
			E E P R O M
**************************************************** */

#define CDATA_START 0xF00000
#pragma cdata[CDATA_START]

/*
ofs 0 = contrast;
ofs 1,2,3,4 = CoefA[0], ofs 5,6 = CoefB[0]
repeated for all 6 coef, modulo 6.
ofs 37
*/

#pragma cdata[] = 0		//contrast
#pragma cdata[0xF000B0]
// ofs 176
#pragma cdata[] = "(c)Robert ","MULLER"," 2023 "//22 car
#pragma cdata[] = "LI TESTER " 	// 10 car
// ofs 208
#pragma cdata[] = Version	// 8 car
#pragma cdata[] = Hardware	// 8 car
#pragma cdata[] = Date		// 12 car


