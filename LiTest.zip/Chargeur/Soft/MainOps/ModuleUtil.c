/* ******************************************************
      utilities for modules
 ******************************************************* */
#ifndef MdUt 
#define MdUt

void Help (char IdxMsg, char NbrLn)
{
	char i;
	

	LCDK_Cls(0);
	for (i=0;i!=NbrLn;i++)
	{
		MnuPrtLn(IdxMsg+i,255,0,i,0);
	}
	MnuPrtLn(53,16,0,7,0);
	while (SW1 == 1);
	tempo(10,1);
	LED = 1;
	while (SW1 == 0);
	tempo(50,1);
	LED = 0;
	LCDK_Cls(0);
}	
// restore all calibration from external flash eprom
// this eeprom can only be populated from othe pgm mainmaint 
void Restore (void)
{
	uns16 BaseAdr,calc16;
	char i,j,dati,er,PromAdr;
	
	i = 0;
	j = 0;
	PromAdr = 0;
	BaseAdr =0x3f00;
	while (i < 176)		//no restore of version infos
	{	
		calc16 = BaseAdr + i;
		er = readflash (calc16,16);
		if (er == 0)
		{
			for (j=0;j!= 16;j++)
			{
				dati = I2Cbufin[j];
				writeprom(PromAdr,dati);
				PromAdr++;
			}
			i += 16;	
		}	
		else i = 176;	
	}
}		

//major error routine
void Panic (char Origin)
{
	//first disable hardwr
	BLOKICH = 1;
	BLOKIDC = 1;
	VPot[0] = 255;
	LoadPot(0);
	VPot[2] = 0;
	LoadPot(2);
	VPot[3] = 0;
	LoadPot(3);
	RELAY = 0;
	// display reason 
	LCDK_Cls(0);
	MnuPrtLn(85,6,6,2,0);
	switch (Origin)
	{
		case 0:		//low/kigh power voltage
		{
			MnuPrtLn(86,12,4,3,0);
			MnuPrtLn(87,12,4,4,0);
			break;
		}
		case 1:		//high temperature
		{
			MnuPrtLn(93,10,4,3,0);
			break;
		}
		case 2:		//battery polarity inversion
		{
			MnuPrtLn(102,18,0,3,0);
			MnuPrtLn(103,8,5,4,0);
			break;
		}			
	}
	MnuPrtLn(29,17,0,7,0);
	while (SW1 == 1);
	tempo (50,1);
	while (SW1 == 0);
	MenuInit();
}
// initiate operational display, put in place all fixed text
void DisplayOps (char mode)
{
	MnuPrtLn(99,17,0,2,0);
	MnuPrtLn(100,17,0,3,0);
	MnuPrtLn(100,17,0,4,0);
	MnuPrtLn(98,14,0,6,0);
	GetText(101,0,18,0);
	LCDK_PrintLine(FONT5X8,0,7,0);
	txt[0] = NbrElem + 0x30;
	txt[1] = 0;
	LCDK_PrintLine(FONT5X8,1,7,0);	
}		

// display title on first line in big font
void Title(char mode)
{
	char tmsg;
	
	if (mode == 1) tmsg = 94;	//lipo chrg
	if (mode == 2) tmsg = 95;	//lipo dechrg
	if (mode == 3) tmsg = 96;	//measures
	if (mode == 4) tmsg = 97;	//balancing
	GetText(tmsg,0,11,1);
	LCDK_PrintLine(FONT8X8,0,0,0);
}

// Change parametres before chrg/dech, nbr elel, current .. 
// mode 0=test, mode 1=chrg, mode 2=dechrg,mode 3=chng val V stop
// mode not in use yet
void ParamSel(char mode)
{
	char lctr,oldup,dati;
	bit ctrchg;
	uns16 calc;
	
	LCDK_Cls(0);
	MnuPrtLn(89,13,0,2,1);
	MnuPrtLn(90,13,0,3,0);
	MnuPrtLn(91,13,0,4,0);
	MnuPrtLn(105,13,0,6,0);
	lctr = 0;
	ctrchg = 1;
	upplus = 6;
	upmoins = 1;
	upcntr = NbrElem;
	cvhexbcd(ChrgI);
	dispval(13,3,4,1,Font6x8);
	cvhexbcd(DechrgI);
	dispval(13,4,4,1,Font6x8);
	upcntr = NbrElem;
	MnuPrtLn(92,13,0,5,0);
	cvhexbcd(NbrElem);
	dispval(13,2,1,0,Font6x8);
	while (SW1 == 1)
	{
		if ((SW2 == 0) || (SELSW == 0))
		{
			tempo (50,1);
			if (SW2 == 0) while (SW2 == 0);
			if (SELSW == 0) while (SELSW == 0);
			tempo (50,1);
			lctr++;
			ctrchg = 1;
			if (lctr == 5) lctr = 0;
//			if (mode == 3)
//			{
//				
//			}	 
		}
		if (ctrchg == 1)
		{
			oldup = 0;
			upmoins = 1;
			ctrchg = 0;
			switch (lctr)
			{
				case 0:
				{
					MnuPrtLn(89,13,0,2,1);
					MnuPrtLn(90,13,0,3,0);
					MnuPrtLn(82,14,0,5,0);
					MnuPrtLn(105,13,0,6,0);
					upcntr = NbrElem;
					upplus = 6;
					break;
				}
				case 1:
				{
					MnuPrtLn(89,13,0,2,0);
					MnuPrtLn(90,13,0,3,1);
					MnuPrtLn(91,13,0,4,0);
					upcntr = ChrgI/100;
					upplus = 50;
					break;
				}	
				case 2:
				{
					MnuPrtLn(90,13,0,3,0);
					MnuPrtLn(91,13,0,4,1);
					MnuPrtLn(92,13,0,5,0);
					upplus = 50; 
					upcntr = DechrgI/100;
					break;
				}
				case 3:
				{
					MnuPrtLn(91,13,0,4,0);
					MnuPrtLn(105,14,0,6,0);
					MnuPrtLn(92,13,0,5,1);
					upplus = 50; 
					upcntr = DechrgI/100;
					break;
				}
				case 4:
				{
					MnuPrtLn(92,13,0,5,0);
					MnuPrtLn(105,14,0,6,1);	
					upplus = 2;
					if (USBReport == 1) upcntr = 2;
					else upcntr = 1;
				}				
			}
			
		}

		if (oldup != upcntr)
		{
			oldup = upcntr;
			switch (lctr)
			{
				case 0:
				{
					cvhexbcd(upcntr);
					dispval(13,2,1,0,Font6x8);
					NbrElem = upcntr;
					break;
				}
				case 1:
				{
					calc = (uns16)upcntr*100;
					cvhexbcd(calc);
					dispval(13,3,4,1,Font6x8);
					ChrgI = calc;
					break;
				}	
				case 2:
				{
					calc = (uns16)upcntr*100;
					cvhexbcd(calc);
					dispval(13,4,4,1,Font6x8);
					DechrgI = calc;
					break;
				}
				case 4:
				{
					if (upcntr == 1)
					{
						txt[0] = 'N';
						UseUSB = 0;
						USBReport = 0;
					}	 
					else
					{
						txt[0] = 'O';
						UseUSB = 1;
						USBReport = 1;
					}
					txt[1] = 0;
					LCDK_PrintLine(FONT6X8,13,6,0);
					break;	
				}	
			}
		}					
	}
	tempo(20,1);
	while (SW1 == 0);
	tempo(300,1);
	upmoins = 0;	
}

// calculate all elements voltage, each measure is value to gnd
// so individual value is diffence with previous measure 
void CalcBal ()
{
	char i;
	uns16 calc16_1,calc16_2;
	uns24 c2;
	
	// calc ofset due to resistance 0.1ohm used for current measure
	c2 = (uns24)Ich * OfsFact;	//ofset factor in defines, measured once
	c2 = c2 / 1000;				//in mV
	CurOfset = (uns16)c2; 
	// calc abolute val of each bal pin
	calc16_1 = BalV[0] - OfsFact;
	if (MesFg == 0) BalV[0] = calc16_1;
	for (i=0;i!=NbrElem;i++)
	{	
		calc16_2 = CoefB[i];
		calc16_1 = ADC[i];
		calc16_1 = ConvertV(calc16_1,CoefA[i],calc16_2);
		BalV[i] = (uns16)calc16_1 - CurOfset;
			
	}
	// calc difference between each bal pin, value of each cell
	for (i = NbrElem-1;i!=0;i--)
	{
		calc16_2 = BalV[i];
		calc16_1 = BalV[i-1];
		calc16_1 = calc16_2 - calc16_1;
		BalV[i] = calc16_1 + CurOfset;
	}
	//BalV[0] -= CurOfset;
	// search max and min cell value
	calc16_1=50000;
	calc16_2 = 0;
	for (i=0;i!=NbrElem;i++)
	{
		if (BalV[i] < calc16_1) calc16_1 = BalV[i];
		if (calc16_2 < BalV[i]) calc16_2 = BalV[i];
	}
	MinBal = calc16_1;
	MaxBal = calc16_2;	
}

// calc voltages 
void CalcBat(void)
{
	uns16 calc16,calc;
	
		
	calc16 = ADC[7];		//v battery
	calc = CoefB[7];
	BatV = ConvertV(calc16,CoefA[7],calc);
	
	calc16 = ADC[8];		//v charge
	calc = CoefB[8];
	Vchrg = ConvertV(calc16,CoefA[8],calc);	
}

// calc currents
void CalcI(void)
{
	uns16 calc16,calc;
	
	calc16 = ADC[9];		//Icharge
	calc = CoefB[9];
	Ich = ConvertV(calc16,CoefA[9],calc);
//	Ich = 3000;		//for debug

	calc16 = ADC[6];		//IDecharge
	calc = CoefB[6];
	Idc = ConvertV(calc16,CoefA[6],calc);	
}			

// update operational diplay with live datas
// Phase 0 if charging
// Phase 1 if decharging 
void OpsLive (char Phase)
{
	uns16 calc16_1,calc;
	char i,x,y,sv1,sv10;
	
	if(Phase == 0)
	{ 	
		cvhexbcd(Ich);		// disp i chrg
	}
	else 
	{
		cvhexbcd(Idc);
	}	
	dispval(2,2,4,1,FONT6X8);
// **** next 2 lines for any debug info,normally as comment
//	cvhexbcd(CurOfset);
//	dispval(0,1,5,0,1);

	cvhexbcd(BatV);		//disp V bat
	dispval(10,2,5,2,FONT6X8);	
	calc16_1 = VIN/100;	//disp v Alim		
	cvhexbcd(calc16_1);
	dispval(5,6,3,2,FONT6X8);
	if (Phase == 0)	
	{			
		calc16_1 = Vchrg/100 ;	//disp v chrg		
		cvhexbcd(calc16_1);
		dispval(14,6,3,2,FONT6X8);
	}	
	cvhexbcd (total);		//disp capacity so far
	dispval(5,5,5,2,1);
	cvhexbcd(Temper);		//disp temperature
	dispval(6,7,2,0,FONT5X8);
	LocMin = (uns16)hour*60;	//disp time min:sec
	LocMin += min;
	cvhexbcd(LocMin);
	dispval(12,7,3,0,FONT5X8);
	cvhexbcd(sec);
	dispval(16,7,2,0,FONT5X8);
	//display balancers values, if bal plug not connx replace with - 
	for (i=0;i!=NbrElem;i++)
	{
		mil = '-';
		cent = '-';
		dix = '-';
		un = '-';
		if (MesFg == 0)	//outside measure phases
		{
			if (NoBalfg == 0)
			{
				calc = BalV[i] / 10;
				cvhexbcd(calc);
			}	
		}
		else
		{
			calc = BalV[i] / 10;
			cvhexbcd(calc);		//display anytime even if no bal plug in
		}
		sv1 = mil;	
		sv10 = cent;
		txt[0] = ' ';
		txt[1] = 0;
		//put a * if balancer active		
		switch (i)
		{
			case 0:
			{
				x=0;
				y=3;
				if (b.0 == 1) txt[0] = '*';
				break;
			}
			case 1:
			{
				x=6;
				y=3;
				if (b.1 == 1) txt[0] = '*';
				break;
			}
			case 2:
			{
				x=12;
				y=3;
				if (b.2 == 1) txt[0] = '*';
				break;
			}
			case 3:
			{
				x=0;
				y=4;
				if (b.3 == 1) txt[0] = '*';
				break;
			}
			case 4:
			{
				x=6;
				y=4;
				if (b.4 == 1) txt[0] = '*';
				break;
			}
			case 5:
			{
				x=12;
				y=4;
				if (b.5 == 1) txt[0] = '*';
				break;
			}		
		}
		LCDK_PrintLine(FONT6X8,x+4,y,0);
		txt[0] = sv1;
		txt[1] = sv10;
		dispval(x,y,3,1,FONT6X8);
		
	}
}		

// send report to PC via USB connx
void PcReport (char token)
{
	uns16 c16;
	uns32 c32;
	
	char *outpc;

	if (USBReport == 1)
	{
		LED2 = !LED2;
	Ech++;
	output_buffer[0] = 0x0A;
	output_buffer[1] = token;
	output_buffer[2] = Ech.high8;
	output_buffer[3] = Ech.low8;
	output_buffer[4] = NbrElem;
	output_buffer[5] = LocMin.high8;
	output_buffer[6] = LocMin.low8;
	output_buffer[7] = sec;
	output_buffer[8] = '=';
	output_buffer[9] = BatV.high8;
	output_buffer[10] = BatV.low8;
	output_buffer[11] = cumul.high8;
	output_buffer[12] = cumul.midH8;
	output_buffer[13] = cumul.midL8;
	output_buffer[14] = cumul.low8;
	output_buffer[15] = Ich.high8;
	output_buffer[16] = Ich.low8;
	output_buffer[17] = Idc.high8;
	output_buffer[18] = Idc.low8;
	output_buffer[19] = BalV[0].high8;
	output_buffer[20] = BalV[0].low8;
	output_buffer[21] = BalV[1].high8;
	output_buffer[22] = BalV[1].low8;
	output_buffer[23] = BalV[2].high8;
	output_buffer[24] = BalV[2].low8;
	output_buffer[25] = BalV[3].high8;
	output_buffer[26] = BalV[3].low8;
	output_buffer[27] = BalV[4].high8;
	output_buffer[28] = BalV[4].low8;
	output_buffer[29] = BalV[5].high8;
	output_buffer[30] = BalV[5].low8;
	output_buffer[31] = Temper;
	output_buffer[32] = Vchrg.high8;
	output_buffer[33] = Vchrg.low8;
	output_buffer[34] = 0;
	outpc = &output_buffer[0];
    putBinUSBUSART(outpc, 34);
    //tempo2(2000,0);
    //while ((cdc_trf_state != CDC_TX_READY) || (timer2 == 1))
    while (cdc_trf_state != CDC_TX_READY)
	{
		CDCTxService();
	}
//	if (timer2 == 0) USBReport = 0;
    }
}

//looks for pc connx, wait up to 30 sec then abort
void TryTfr ()
{
	uns16 ttemp;
	bit fg;
	
	tempo2(30000,0);	//30sec
	fg = 0;
	USBStart();
	USBReport = 0;
	while (timer2 == 1)
	{
		USBget(1);
		if (USBup == 1)
		{
			MnuPrtLn(104,14,0,7,1);
			USBReport = 1;
		}
		else
		{
			if (fg == 0)
			{
				MnuPrtLn(106,14,0,7,0);
				fg = 1;
			}	
			ttemp = tempoms2 / 1000;
			cvhexbcd (ttemp);
			dispval(16,7,2,0,Font6x8);
		}
		if (USBup == 1) break;	//got answer get out
	}
	CDCTxService();		//clears 		
}
			
#endif