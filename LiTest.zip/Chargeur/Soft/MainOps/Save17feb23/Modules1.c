
void UpdateEEprom (void)
{
	LED = 1;
	LCDK_Cls(0);
	MnuPrtLn(28,13,0,2,0);
	MnuPrtLn(29,17,0,6,0);
	con_up = 0;
	endtfr = 0;
	USBStart();
	while (endtfr == 0)
	{
		if (!con_up)
		{
			USBget(0);	// handshake with pc 
			if (SW1 == 0)
			{
				endtfr = 1;
			}
		}	
		else
		{
			LCDK_Cls(0);
			MnuPrtLn(30,12,0,2,0);
			tempo(50,1);
			if (endtfr == 0)USBTfr();	//transfer datas in eeprom
			endtfr  = 1;
		}
	}
	USBModuleDisable();

	
}

void Contrast (void)
{
	char i,oldup;
	
	LCDK_Cls(0);
	for (i=0;i!=18;i++)
	{
		txt[i] = 'A';
	}
	txt[18] = 0;
	LCDK_PrintLine(FONT6X8,0,1,0);
	LCDK_PrintLine(Font6x8,0,3,1);
	upcntr = 207;
	upplus = 255;
	upmoins = 0;
	MnuPrtLn(42,17,0,7,0);	
	while (SW1 == 1)
	{

 		if (oldup != upcntr)	
		{
			VPot [1] = upcntr;
			LoadPot(1);
			cvhexbcd (upcntr);
			dispval (0,6,3,0,FONT6X8);	
		}
		if (SW2 == 0)
		{
			tempo(10,1); 
			LED2 = 0;
			while (SW2 == 0);
			tempo (10,1);
			LED2 = 1;
			writeprom(0,upcntr);
		}		
	}
	upcntr = 1;		
}



void TestLipo ()
{
	char TimeCk;
	
	LCDK_Cls(0);
	while (SW1==1)
	{
		if (MSFlg == 1)
		{
			TimeCk ++;
			MSFlg = 0;
			if (TimeCk == 80)
			{
				TimeCk = 0;
				ComputeVal();
			}
		}		
	}	
}

void ChargeLipo ()
{
	char i,x,b,oldb;
	char TimeCk,DispClk,OpsClk,FreezeClk,AdjClk;
	char t60sec,treport;
	uns16 calc16_1,calc16_2,EndChrg;
	uns32 calc32_1,calc32_2;
	char Hidetemper;
	bit MFg,BalFg,FanMd,HighTemp,CloseCh,FirstRun;

	if (UseUSB == 1) TryTfr();
	tempo(1500,1);
	LCDK_Cls(0);
	Title(1);
	DisplayOps(0);	//display background
	sec = 0;
	min = 0;
	Ech = 0;
	MesFg = 0;
	cumul = 0;
	total = 0;
	BalFg = 0;
	CloseCh = 0;
	HighTemp = 0;
	Hidetemper = 0;
	t60sec = 26;
	EndChrg = 4200 * NbrElem;
	Temper = 20;
	NoBalfg = 0;
	FirstRun = 1;
	oldb = 0;
	BatV = 0;
	calc32_2 = (uns32)EndChrg + 3000;	//vcharg, bat+2v
	if (INVBAT > 100) 
	{
		RELAY = 1;
//	 calcul vchrg r=(1.26*r1)/(Vout - 1.26) 
//  vref = 1.26v  r1 = 27k
		calc32_1 = (uns32)1260 * (uns32)27000;
		calc32_2 -= (uns32)1260;
		calc32_1 = calc32_1 / calc32_2;
		calc32_1 -= 1000;	//res in seri
		calc32_2 = calc32_1/39;		//39ohm per digit
		x = calc32_2.low8;
		VPot[0] = x;
		LoadPot(0);
		//calcul Ichrg
		x = ChrgI / 23;
		VPot[2] = x;
		LoadPot(2);
		BLOKICH = 0;
	}	
		
	// init chrg bat
	
	// loop
	while ((SW1==1) && (CloseCh == 0))
	{
		if (MSFlg == 1)
		{
			TimeCk ++;
			DispClk++;
			AdjClk++;
			MSFlg = 0;
			if (TimeCk == 80)
			{
				TimeCk++;
				ComputeVal();
			}
			if (TimeCk == 110)
			{
				TimeCk = 0;
				CalcBal();
				CalcBat();
				CalcI();
			}	
			if (DispClk == 200)
			{
				DispClk = 0;
				OpsLive(0);	//display all datas
			}
			if (AdjClk == 510)	//correct i val, Vchrge, fan
			{
				calc16_1 = ChrgI+1;
				if (Ich > calc16_1)
				{
					VPot[2]--;
					LoadPot(2);
				}
				calc16_1 = ChrgI - 1;
				if (Ich < calc16_1)
				{
					VPot[2]++;
					LoadPot(2);
				}

				if ((Temper > 40) && (FanMd == 0))
				{
					FAN_1;
					FanMd = 1;
				}
				if ((Temper < 35) && (FanMd == 1))
				{
					FAN_0;
					FanMd = 0;
				}
				if (Hidetemper < 10)
				{
					Hidetemper ++;
				}
				else
				{	
					if (Temper >= 90)
					{
						BLOKICH = 1;
						HighTemp = 1;
					}
				}			
			}

		}
		if (SecFlg == 1)
		{
			SecFlg = 0;

			if (HighTemp == 1)
			{
				BLOKICH = 1; 
				if (Temper < 80)
				{
					if (MesFg == 0) BLOKICH = 0;	//*****comment until ich ok
					HighTemp = 0;
				}
			}		
			//check for end voltage 
			if ((BatV >= EndChrg) && (FirstRun == 0))
			{
				if (NoBalfg == 1)
				{
					if (VPot[2] > 2)	//2 is stop chrg
					{
						VPot[2]--;
						LoadPot(2);
					}
					else CloseCh = 1;
				}
				else
				{
					BalFg = 1;	
					VPot[2] = 11;	//keep charg just below i balance
					LoadPot(2);
				}		
			}
			// balance during charge
			if (NoBalfg == 0)
			{
				b = 0;				
				if ((BalFg == 0) && (MesFg == 0))
				{
					calc16_1 = MinBal+1;
					for (i = 0;i!=NbrElem;i++)
					{
						if (BalV[i] > calc16_1) Carry = 1;
						else Carry = 0;
						#asm
						RRCF b
						#endasm
					}	
				}
			// balance after charge	
				if ((BalFg == 1) && (FirstRun == 0))		//balance mode
				{
					CloseCh = 1;
					for (i=0;i!=NbrElem;i++)
						{
							if (BalV[i] > 4200)
							{
								CloseCh = 0;	//still over ch, no end
								Carry = 1;
							}
							else Carry = 0;	
							#asm
							RRCF b
							#endasm			
						}
					}	
				for (i=0;i!=8-NbrElem;i++)
				{
					Carry = 0;
					#asm
					RRCF b
					#endasm	
				}
				if (oldb != b)
				{
					while (I2C_State !=1);
					oldb = b;	
					iadr = 4;	//update balancers
					I2Cbufout[0] = 3;
					I2Cbufout[1] = 1;
					I2Cbufout[2] = b;	//****replace = b when hard ok
					I2Cout(3,0);
				}

			}
			
			if (treport == 10)	//measure + 10sec later
			{
				if (BalFg == 1) PcReport('H');	
				else PcReport('C');
			}
			treport++;	
			if (MesFg == 0)
			{
				cumul += Ich;
				total = cumul / 3600;
			}	
			//each half minute 
			t60sec++;
			if (t60sec == 27)	//measure mode
			{
				iadr = 4;
				I2Cbufout[0] = 3;
				I2Cbufout[1] = 1;
				I2Cbufout[2] = 0;	
				I2Cout(3,0);
				b = 0;
				Title(3);
				t60sec = 0;
				BLOKICH = 1;
				OpsClk = 0;
				MesFg = 1;
			}
			if (MesFg == 1)
			{
				OpsClk++;
				treport=0;
				if (OpsClk == 4)  //restart normal or stop
				{
					PcReport('M');
	// check all status of voltages
		// End of charge if needed
					Title(1);
					MesFg = 0;
					BLOKICH = 0;		//*****comment until ich ok
					treport = 0;
			//look if 1 element is over charged
			// switch to balance only mode
	/*				if (NoBalfg == 0)
					{
						for (i=0;i!=6;i++)
						{
							if (BalV[i] > 4200)
							{
								BalFg = 1;
								VPot[2] = 11;
								LoadPot(2);
							}
						}
					}
				*/
					if (FirstRun == 1)
					{
						FirstRun = 0;
					}
					if ((BalV[0] < 2800) || (BalV[0] > 4400)) NoBalfg = 1;
					else NoBalfg = 0;
	
				}
			}		
		ttp = total;
		}
	}
	// close charge
	RELAY = 0;
	while (I2C_State !=1);
	iadr = 0x02*2;
	I2Cbufout[0] = 2;
	I2Cbufout[1] = 1;
	I2Cbufout[2] = 0b00111111;	
	I2Cout(3,0);
	FAN_0;
	tempo(5,1);
	BLOKICH = 1;
	VPot[0] = 255;
	LoadPot(0);	
	VPot[2] = 0;
	LoadPot(2);
	PcReport('T');
	tempo(200,1);
	if (USBReport == 1)USBModuleDisable();
}

void DechargeLipo ()
{
	char TimeCk,DispClk,OpsClk;
	
	LCDK_Cls(0);
	while (SW1==1)
	{
		if (MSFlg == 1)
		{
			TimeCk ++;
			DispClk++;
			MSFlg = 0;
			if (TimeCk == 80)
			{
				TimeCk = 0;
				ComputeVal();
			}
			if (DispClk == 200)
			{
				DispClk = 0;
				cvhexbcd(Temper);
				dispval(7,7,2,0,Font6x8);
				LCDK_PrintLine(FONT8X8,0,0,0);	
			}
		}
		if (SecFlg == 1)
		{
			SecFlg = 0;
			OpsClk ++;
		}	
		
	}	
}				