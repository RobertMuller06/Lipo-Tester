/*			// src 0 = Vin, src 1 = Vchrg, src 2 = VBat, src 3=Ichrg, Src 4 = Idechrg
			if (Src == 0) Idx = 10;	//vin
			if (Src == 1) Idx = 8;	//vchrg
			if (Src == 2) Idx = 7;	//vbat
			if (Src == 3) Idx = 9;	//ichrg
			if (Src == 4) Idx = 6;	//idechrg
			
*/