// Modules part 2

#ifndef modl2
#define modl2

void CalBal (void)
{
	char i,DgtPos,oldrot,DispTmr,oldelem;
	bit TmrTik,Rev,DispVFlg;
	uns16 VAdc,calc16,calc16_2,tp1,tp2;
	char mode;
	uns16 sval,sval2,adc1,adc2;
	int tp3;
	float32 calc32,flt1,flt2;

	Help (47,6);
	GetText(43,0,13,1);
	LCDK_PrintLine(FONT8X8,0,0,0);
	MnuPrtLn(44,12,0,1,0);
	MnuPrtLn(45,18,0,4,0);
	MnuPrtLn(46,18,0,5,0);
	DispVFlg = 0;
	elem = 0;
	oldelem = 0;
	TmrTik = 0;
	DispTmr = 100;
	mode = 0;
	Rev = 0;
	sval = 0;
	sval2 = 0;
	upcntr = 0;
	oldrot = upcntr;
	I2Cbufout[0] = 3;
	I2Cbufout[1] = 1;
	I2Cbufout[2] = 0b111111; 	//balancer shutdown
	iadr = 4;
	I2Cout(3,0);
	while (SW1 == 1)
	{
		if (MSFlg)
		{
			TmrTik = 1;
			MSFlg = 0;
		}
		if (TmrTik) DispTmr++;
		if (DispTmr == 200)
		{
			DispTmr = 0;
			VAdc = ReadADC (elem);	//read result of previous reqst
			tempo(2,1);
			SetADC(elem);			//strat new adc
			cvhexbcd(VAdc);
			dispval(4,2,5,0,Font6x8);
			if (mode == 0)
			{
				txt[0] = elem + 0x31;
				txt[1] = 0;
				LCDK_PrintLine(FONT6X8,0,2,1);
			}
			else
			{
				txt[0] = elem + 0x31;
				txt[1] = 0;
				LCDK_PrintLine(FONT6X8,0,2,0);
			}
		if (DispVFlg)
			{
				calc16 = VAdc;
				tp3 = CoefB[elem];
				calc16 = ConvertV (calc16,CoefA[elem],tp3);
				cvhexbcd (calc16);
				dispval (8,2,5,2,Font8x8);
			}
			else
			{
				txt[0] = '-';
				txt[1] = '-';
				txt[2] = ',';
				txt[3] = '-';
				txt[4] = '-';
				txt[5] = '-';
				txt[6] = 0;
				LCDK_PrintLine(Font8x8,8,2,0);
			}		
			if (mode == 1)
			{
				calc16 = sval;
				i = 4;
			}
			if (mode == 2)
			{
				calc16 = sval2;
				i = 5;
			}
			cvhexbcd (calc16);
			if (mode != 0) dispval(12,i,5,2,Font6x8);		
			switch (DgtPos)
			{
				case 0:
				{
					txt[0] = un;
					txt[1] = 0;
					LCDK_PrintLine(Font6x8,17,i,1);
					break;
				}
				case 1:
				{
					txt[0] = dix;
					txt[1] = 0;
					LCDK_PrintLine(Font6x8,16,i,1);
					break;
				}
				case 2:
				{
					txt[0] = cent;
					txt[1] = 0;
					LCDK_PrintLine(Font6x8,15,i,1);
					break;
				}
				case 3:
				{
					txt[0] = mil;
					txt[1] = 0;
					LCDK_PrintLine(Font6x8,13,i,1);
					break;
				}	
				case 4:
				{
					txt[0] = dmil;
					txt[1] = 0;
					LCDK_PrintLine(Font6x8,12,i,1);
					break;
				}	
			}	
		}
		
		if (SW2 == 0)	//change selection type (element, v1,v2)
		{
			ResetRot();
			tempo(10,1);
			LED2 = 0;	
			while (SW2 ==  0);
			tempo (10,1);
			LED2 = 1;
			ReslSWup = 0;
			if (mode == 1)
			{
				adc1 = VAdc;	//keep track of adc for calculation
			}	
			if (mode == 2)
			{
				adc2 = VAdc;
			}	
			mode++; 
			if (mode == 3) mode = 0;
			if (mode == 0) 
			{
				upplus = 5;
				upcntr = elem;
				oldrot = elem;
			}
			if (mode == 1)
			{
				upplus = 255;
				upcntr = 30;
				oldrot = 30;
			}
			else
			{ 	
				cvhexbcd(sval);
				dispval(12,4,5,2,Font6x8);
			} 
			if (mode == 2)
			{
				upplus = 255;
				upcntr = 30;
				oldrot = 30;
			}
			else
			{ 	
				cvhexbcd(sval2);
				dispval(12,5,5,2,Font6x8);
			}			
			DgtPos = 0;
		}
		if (SW3 == 0)		//validate/save values for element
		{
			tempo(10,1);
			LED3_On;	
			while (SW2 ==  0);
			tempo (10,1);
			LED3_Off;	
			DispVFlg = 1;		//from now shows calculated v
			Rev = 1;
			if (adc1 > adc2) Rev = 0;
			if (!Rev)
			{
				calc16 = adc1-adc2;
				calc16_2 = sval - sval2;
			}	
			else 
			{
				calc16 = adc2-adc1;
				calc16_2 = sval2 - sval;
			}
			tp1 = calc16;
			tp2 = calc16_2;
			flt1 = (float32)calc16;
			flt2 = (float32)calc16_2;
			calc32 = flt2; 
			calc32 = calc32 / flt1;
			calc16 = (uns16)calc32;
			CoefA[elem] = calc32;	//a=delta(volt) / delta(adc)
			flt1 = (float32)sval;	
			flt2 = (float32)adc1;
			calc32 = calc32 * flt2;
			calc32 = flt1 - calc32;
			tp3 = (int) calc32;
			CoefB[elem] = tp3;	//b=volt-a*adc
			cvhexbcd(CoefA[elem]*100000);
			txt[0] = '0';
			txt[1] = ',';
			txt[2] = 0;
			LCDK_PrintLine(Font6x8,0,6,0);
			dispval(2,6,5,0,Font6x8);
			if (tp3 < 0)
			{
				txt[0]= '-';
				tp3 = 0-tp3;
			}
			else txt[0] = '+';
			txt[1] = 0;
			LCDK_PrintLine(Font6x8,0,7,0);
			cvhexbcd(tp3);
			dispval(1,7,5,0,Font6x8);
			// save values in eeprom
			i = elem * 6;
			i++;
			calc32 = CoefA[elem];
			writeprom(i,calc32.high8);
			i++;
			writeprom(i,calc32.midH8);
			i++;
			writeprom(i,calc32.midL8);
			i++;
			writeprom(i,calc32.low8);
			calc16 = CoefB[elem];
			i++;
			writeprom(i,calc16.high8);
			i++;
			writeprom(i,calc16.low8);
			Backup();
		}
		if (mode == 0)
		{
			if (oldelem != upcntr)
			{
				upplus = 5;
				oldelem = upcntr;
				elem = upcntr;
				sval = 0;
				sval2 = 0;
			}
		}

		if (mode == 1)
		{
			if (ReslSWup == 1)
			{
				ReslSWup = 0;
				DgtPos++;
				if (DgtPos == 5) DgtPos = 0;
				//adjdgt(sval);
				upcntr = 30;
				oldrot = upcntr;
			}
			if (oldrot != upcntr)
			{
				Rev = 1;
				if (oldrot > upcntr) Rev = 0;
				oldrot = upcntr;
				sval = moddgt(DgtPos,sval,Rev);
			}
		}
		if (mode == 2)
		{
			if (ReslSWup == 1)
			{
				ReslSWup = 0;
				DgtPos++;
				if (DgtPos == 5) DgtPos = 0;
				//adjdgt(sval2);
				upcntr = 30;
				oldrot = upcntr;
			}
			if (oldrot != upcntr)
			{
				Rev = 1;
				if (oldrot > upcntr) Rev = 0;
				oldrot = upcntr;
				sval2 = moddgt(DgtPos,sval2,Rev);
			}
		}					
	TmrTik = 0;				
	}		
}

// src 0 = Vin, src 1 = Vchrg, src 2 = VBat, src 3=Ichrg, Src 4 = Idechrg
void CalV (char Src)
{
	char i,DgtPos,oldrot,DispTmr,Idx;
	bit TmrTik,Rev,DispVFlg,FMes;
	uns16 VAdc,calc16,calc16_2;
	char mode;
	uns16 sval,sval2,adc1,adc2;
	int tp3;
	float32 calc32,flt1,flt2;
	
	Help (65,6);
	upmoins = 0;
	if (Src == 0)
	{
		GetText(60,0,13,1);
		LCDK_PrintLine(FONT8X8,0,0,0);
		MnuPrtLn(59,13,0,1,0);
		MnuPrtLn(56,7,0,2,0);
		upcntr = 30;
		upplus = 255;
	}
	if (Src == 1)
	{
		GetText(54,0,13,1);
		LCDK_PrintLine(FONT8X8,0,0,0);
		MnuPrtLn(55,15,0,1,0);
		MnuPrtLn(63,7,0,2,0);
		upcntr = 130;
		upplus = 130;
		VPot[0] = 130;
		LoadPot(0);
	}
	if (Src == 2)
	{
		GetText(61,0,13,1);
		LCDK_PrintLine(FONT8X8,0,0,0);
		MnuPrtLn(59,13,0,1,0);
		MnuPrtLn(64,7,0,2,0);
		upcntr = 30;
		upplus = 255;
	}		
	MnuPrtLn(45,18,0,4,0);
	MnuPrtLn(46,18,0,5,0);
	MnuPrtLn(62,16,0,6,0);	
	TmrTik = 0;
	DispTmr = 200;
	if ((Src == 1 ) || (Src == 3) || (Src == 4)) mode = 0;
	else mode = 1;
	Rev = 0;
	sval = 0;
	sval2 = 0;
	oldrot = upcntr;
	calc32 = 0;
	upmoins = 0;
	FMes = 0;
	while (SW1 == 1)
	{
		if (MSFlg)
		{
			TmrTik = 1;
			MSFlg = 0;
		}
		if (TmrTik) DispTmr++;
		if (DispTmr == 200)
		{
			DispTmr = 0;
			if (Src == 0)
			{
				VAdc = MESVIN;
			}
			if (Src == 1)
			{
				I2Cbufout[0] = 3;
				I2Cbufout[1] = 1;
				I2Cbufout[2] = 2;
				iadr = 6;
				I2Cout(3,3);
				VAdc.high8 = I2Cbufin[1];
				VAdc.low8 = I2Cbufin[2];
			}
			if (Src == 2)
			{
				VAdc = ReadADC (7);	//read result of previous reqst
				tempo(2,1);
				SetADC(7);			//start new adc process
			}	
			cvhexbcd(VAdc);
			dispval(4,1,4,0,Font6x8);
			calc16 = VAdc;
			if (Src == 0)
			{
				calc32 = CoefA[7];
				tp3 = CoefB[7];
			}	
			if (Src == 1)
			{
				calc32 = CoefA[6];
				tp3 = CoefB[6];
			}
			if (Src == 2)
			{
				calc32 = CoefA[8];
				tp3 = CoefB[8];
			}		
			calc16 = ConvertV (calc16,calc32,tp3);
			cvhexbcd (calc16);
			dispval (6,2,5,2,Font8x8);
			if (Src == 1)
			{
				cvhexbcd (VPot[0]);
				txt[0] = cent;
				txt[1] = dix;
				txt[2] = un;
				txt[3] = 0;
				if (mode == 0) LCDK_PrintLine(Font6x8,13,1,1);
				else LCDK_PrintLine(Font6x8,13,1,0);
			}
			cvhexbcd (sval);
			dispval(12,4,5,2,Font6x8);
			cvhexbcd (sval2);
			dispval(12,5,5,2,Font6x8);
			if (mode == 1)
			{
				calc16 = sval;
				i = 4;
				cvhexbcd (sval);
			}
			if (mode == 2)
			{
				calc16 = sval2;
				i = 5;
			}
			if (mode != 0)
			{
				switch (DgtPos)
				{
					case 0:
					{
						txt[0] = un;
						txt[1] = 0;
						LCDK_PrintLine(Font6x8,17,i,1);
						break;
					}
					case 1:	
					{
						txt[0] = dix;
						txt[1] = 0;
						LCDK_PrintLine(Font6x8,16,i,1);
						break;
					}	
					case 2:
					{
						txt[0] = cent;
						txt[1] = 0;
						LCDK_PrintLine(Font6x8,15,i,1);
						break;
					}
					case 3:
					{
						txt[0] = mil;
						txt[1] = 0;
						LCDK_PrintLine(Font6x8,13,i,1);
						break;
					}	
					case 4:
					{
						txt[0] = dmil;
						txt[1] = 0;
						LCDK_PrintLine(Font6x8,12,i,1);
						break;
					}	
				}
			}
			if (Src == 0)
			{
				calc32 = CoefA[7];
				tp3 = CoefB[7];
			}	
			if (Src == 1)
			{
				calc32 = CoefA[6];
				tp3 = CoefB[6];
			}
			if (Src == 2)
			{
				calc32 = CoefA[8];
				tp3 = CoefB[8];
			}	
			cvhexbcd(calc32*100000);
			txt[0] = '0';
			txt[1] = ',';
			txt[2] = 0;
			LCDK_PrintLine(Font6x8,0,7,0);
			dispval(2,7,5,0,Font6x8);
			if (tp3 < 0)
			{
				txt[0]= '-';
				tp3 = 0-tp3;
			}
			else txt[0] = '+';
			txt[1] = 0;
			LCDK_PrintLine(Font6x8,10,7,0);
			cvhexbcd(tp3);
			dispval(11,7,5,0,Font6x8);
		}	//end disp rtg
		if (SW2 == 0)	//change selection type (pot,v1,v2)
		{
			tempo(10,1);
			LED2 = 0;	
			while (SW2 ==  0);
			tempo (10,1);
			LED2 = 1;
			ReslSWup = 0;
			if (mode == 1)
			{
				if ((FMes == 0) && (Src == 1))
				{
					adc1 = VAdc;	//keep track of adc for calculation
					FMes = 1;
				}	
			}
			if (mode == 2)
			{
				adc2 = VAdc;
				
			}	
			mode++; 
			if (mode == 3) mode = 0;
			if (mode == 0)
			{
				if (Src == 1)
				{
					upcntr = VPot[0];
					oldrot = upcntr;
					upplus = 130;
				}
				else mode = 1;
			}
			if (mode == 1)
			{
				upcntr = 30;
				oldrot = 30;
			}	
			if (mode == 2)
			{
				upcntr = 30;
				oldrot = 30;
			}			
			DgtPos = 0;
		}
		if (SW3 == 0)		//validate/save values for element
		{
			tempo(10,1);
			LED3_On;	
			while (SW2 ==  0);
			tempo (10,1);
			LED3_Off;	
			Rev = 1;
			if (adc1 > adc2) Rev = 0;
			if (!Rev)
			{
				calc16 = adc1-adc2;
				calc16_2 = sval - sval2;
			}	
			else 
			{
				calc16 = adc2-adc1;
				calc16_2 = sval2 - sval;
			}
			if (Src == 0) Idx = 7;
			if (Src == 1) Idx = 6;
			if (Src == 2) Idx = 8;
			flt1 = (float32)calc16;
			flt2 = (float32)calc16_2;
			calc32 = flt2; 
			calc32 = calc32 / flt1;
			CoefA[Idx] = calc32;	//a=delta(volt) / delta(adc)
			flt1 = (float32)sval;	
			flt2 = (float32)adc1;
			calc32 = calc32 * flt2;		// a*x
			calc32 = flt1 - calc32;		// b = y - ax
			tp3 = (int) calc32;			//sgn needed most of time b<0
			CoefB[Idx] = tp3;			//b=volt-a*adc
			// save values in eeprom
			calc32 = CoefA[Idx];
			calc16 = CoefB[Idx];
			Idx *= 6;
			Idx++;
			writeprom(Idx,calc32.high8);
			Idx++;
			writeprom(Idx,calc32.midH8);
			Idx++;
			writeprom(Idx,calc32.midL8);
			Idx++;
			writeprom(Idx,calc32.low8);
			Idx++;
			writeprom(Idx,calc16.high8);
			Idx++;
			writeprom(Idx,calc16.low8);
			tempo(30,1);
			Backup();
		}  
		if (mode == 0)		//only for src 1
		{
			if (oldrot != upcntr)
			{
				oldrot = upcntr;
				VPot[0]  = upcntr;
				LoadPot(0);
			}	
		}
		if (mode == 1)
		{
			if (ReslSWup == 1)
			{
				ReslSWup = 0;
				DgtPos++;
				if (DgtPos == 5) DgtPos = 0;
				//adjdgt(sval);
				upcntr = 30;
				oldrot = upcntr;
			}
			if (oldrot != upcntr)
			{
				Rev = 1;
				if (oldrot > upcntr) Rev = 0;
				oldrot = upcntr;
				sval = moddgt(DgtPos,sval,Rev);
			}
		}
		if (mode == 2)
		{
			if (ReslSWup == 1)
			{
				ReslSWup = 0;
				DgtPos++;
				if (DgtPos == 5) DgtPos = 0;
				//adjdgt(sval2);
				upcntr = 30;
				oldrot = upcntr;
			}
			if (oldrot != upcntr)
			{
				Rev = 1;
				if (oldrot > upcntr) Rev = 0;
				oldrot = upcntr;
				sval2 = moddgt(DgtPos,sval2,Rev);
			}
		}
	TmrTik = 0;				
	}			

	
}


#endif
